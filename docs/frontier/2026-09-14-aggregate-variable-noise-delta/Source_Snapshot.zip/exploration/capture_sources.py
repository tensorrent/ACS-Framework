from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
base=Path(__file__).absolute().parent;mathlib=base.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip();assert revision=='be865aa50cc0364be66c3941a6dc0c845a2c2ceb'
records=[]
for relative in ['Mathlib/Algebra/Order/Group/Abs.lean','Mathlib/Analysis/Normed/Group/Basic.lean']:
 raw=(mathlib/relative).read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+relative],cwd=mathlib)
 records.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'matches_pinned_git_object':True})
r={'status':'passed','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mathlib_revision':revision,'pinned_sources':records,
 'retrieved_primary_documentation':{'url':'https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/Order/Group/Abs.html','retrieval':'Successfully opened with the web tool on 14 September 2026.','relevant_results':['abs_le','abs_sub_le'],'scope':'Primary reference for absolute-value inequalities used in the midpoint and common-report budget arguments. Current documentation is not asserted to match the pinned runtime revision.'},
 'runtime_change':'No package acquisition, version change or new source roots. Existing Python/FLINT and Lean/mathlib runtimes are reused.',
 'scope':'The midpoint and scaling arguments are explicit algebraic derivations, with generic Lean lemmas compiled separately. Exact local reference sources match pinned Git objects and are archived with the mathlib license.'}
(base/'Source_Acquisition.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
