"""Numerical proposals only: finite Gaussian features of preserved22-entry prefixes."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
import hashlib,json,time
import numpy as np
import scipy
from scipy.optimize import least_squares
BASE=Path(__file__).absolute().parent;SOURCE=BASE.parent/'aggregate-equal-population-audit/inputs'
paths=[SOURCE/('E'+str(i)+'_224.json') for i in [1,2]]
raw=[json.loads(p.read_text()) for p in paths]
centers=np.array([[float((F(r['lo'])+F(r['hi']))/2) for r in d['positive_root_intervals']] for d in raw])
assert centers.shape==(2,22) and all(d['top']=='39/2' for d in raw)
indices=np.array([2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31]);u=np.log(indices);alpha=1/25
def features(x):return 2*(np.exp(-alpha*x[None,:]**2)*np.cos(u[:,None]*x[None,:])).sum(axis=1)
def derivative(x):return 2*np.exp(-alpha*x[None,:]**2)*(-2*alpha*x[None,:]*np.cos(u[:,None]*x[None,:])-u[:,None]*np.sin(u[:,None]*x[None,:]))
def residual(v):return features(v[:22])-features(v[22:])
def jac(v):return np.concatenate([derivative(v[:22]),-derivative(v[22:])],axis=1)
baseline=centers.ravel();previous=np.tile(centers.mean(axis=0),2);cases=[]
assert np.max(np.abs(residual(previous)))==0
for radius in [.57,.5,.4,.3,.2,.1,.05]:
    lower=baseline-radius;upper=baseline+radius;initial=np.clip(previous,lower+1e-10,upper-1e-10);started=time.monotonic()
    fitted=least_squares(residual,initial,jac=jac,bounds=(lower,upper),max_nfev=600,ftol=1e-12,gtol=1e-12,xtol=1e-12)
    previous=fitted.x;res=residual(previous);sv=np.linalg.svd(jac(previous),compute_uv=False)
    c={'radius':radius,'scipy_status':int(fitted.status),'scipy_message':str(fitted.message),'evaluations':int(fitted.nfev),'elapsed_seconds':time.monotonic()-started,'maximum_feature_residual':float(np.max(np.abs(res))),
       'feature_residuals':res.tolist(),'observed_coordinates':previous.reshape(2,22).tolist(),'maximum_coordinate_shift':float(np.max(np.abs(previous-baseline))),
       'bound_margin':float(np.min(np.minimum(previous-lower,upper-previous))),'jacobian_singular_values':sv.tolist(),'scope':'Binary64 optimization of midpoint surrogate source roots. A small residual is not an existence certificate for true-root data or exact feature equality.'}
    cases.append(c);print(json.dumps({k:c[k] for k in ['radius','maximum_feature_residual','evaluations','bound_margin']}),flush=True)
out={'status':'numerical_proposals_not_certified','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'numpy':np.__version__,'scipy':scipy.__version__,
     'proposed_observable':'Only17finite sums F_m(y)=2sum_i exp(-y_i^2/25)cos(log(m)y_i), for the listed centers. Complete22entry sources are selected below19.5 before perturbation; all entries retained. No raw roots, cumulative counts, moment statistic or unknown-tail contribution is included in the released vector.',
     'centers':indices.tolist(),'source_midpoints_binary64':centers.tolist(),'source_feature_difference':residual(baseline).tolist(),'cases':cases,
     'required_next_gate':'Fix a precise physical/mathematical acquisition contract and obtain a uniform true-root interval existence certificate, e.g. an invertible17-variable slice with rigorous interval Newton/Krawczyk bounds. Small numerical residuals and solver status alone never certify actual collisions; omitted moments and infinite tails require separate models.'}
(BASE/'Feature_Collision_Proposals.json').write_text(json.dumps(out,indent=2)+'\n')
