from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-optimized-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-shared-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_optimized_delta import summarize
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)

for name in ['Proposals.json','Noise_Audit.json','Adversary_Audit.json']:(OUT/name).write_bytes((BASE/name).read_bytes())
(OUT/'Exploratory_Probe.json').write_bytes((BASE/'Proposal_Probe.json').read_bytes())
archive('Noise_Certificates.zip',[(BASE/f'Certificate{b}.json',f'Certificate{b}.json') for b in [224,320]])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==6 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(read(BASE/'Certificate224.json'),read(BASE/'Certificate320.json'),read(BASE/'Noise_Audit.json'))
write('Noise_Summary.json',{'recorded_utc':now,
    'result':'Noise-adapted rational multipliers and one-sided continuum error bounds recover coefficient seven through tested radii 0.06 and 0.13 in the two aggregate spectra.',
    'input_contract':['degree four','signature (0,2)','discriminant 576','complete aggregate finite critical-line root intervals through 20','generic coefficient boxes 0..4'],
    'not_optimizer_inputs':['local models','Galois group','field candidate catalogue','defining polynomial','subfields','conductor-parity assignment','held-out arithmetic'],
    'coefficient_target':7,'measurement_rows':17,'generic_coefficients':604,'new_roots_computed':0,
    'derived_results':summary,'sampled_proposals':48,'exploratory_proposals':36,'stored_midpoints_checked':158400,'fresh_quadratic_interval_leaves':126720,
    'exact_objective_bounds':192,'independent_displaced_controls':192,'certified_off_grid_counterexamples':2,'actual_component_mutations_rejected':8,
    'scope':'Only coefficient seven is studied under these widened inputs. Same-grid frozen radii are 0.002 and 0.07; the preceding B grid had no 0.07 sample. Derivative ablations retain subdivision differences and independent improvements. The optional unramified-prime supplement uses separately declared local information. Surviving candidates do not prove actual ambiguity or optimal radii.',
    'full_proof_formalized':False,
    'next_gate':'Combine finite Gaussian changes with the known-moment change of the same displaced roots before maximizing separate budgets; extend noisy recovery beyond coefficient seven and investigate constructive/global ambiguity.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':6,'successful_commands':6,'failed_commands':0,
    'recording_scope':'One exploratory probe, one final proposal run, two certificate runs, one independent audit and one adversarial audit. Packaging and the final recursive verifier are separate. Previous failed attempts remain unchanged in inherited checkpoints.',
    'freeze_boundary':'The 48 rational proposals were frozen before both certificate runs. Both producers completed before the independent audit. Held-out arithmetic enters only that downstream audit. No executed instrument was revised during this pass.',
    'proposal_scope':'The 33-point-per-root floating LP is a proposal generator. The sampled score is neither a rigorous continuum bound nor a certified optimum. The proof uses rounded nonnegative rational multipliers, full residual support and complete interval covers.',
    'error_enclosure':'The real producer uses first-derivative midpoint Taylor enclosures of nonlinear changes. The independent complex route uses second derivatives and quadratic interval remainders. Both preserve the original bracket, every widened interval, multiplicity and finite cutoff.',
    'precision_comparison':'Direct candidate sets agree at both producer precisions. One A symmetric-derivative domain at radius 0.14 narrows with the finer partition. The independent audit additionally strengthens two B derivative domains. All differences are preserved in the summary and audit; precision and subdivision effects are not conflated.',
    'fair_baseline':'Both old frozen and adapted multipliers are checked on the same twelve-point grid with both error methods. Frozen B recovery at 0.07 extends the earlier grid, rather than being credited to multiplier adaptation.',
    'counterexample_scope':'Two interval-certified off-grid root changes exceed all 33 sampled errors. They invalidate sampled maxima as continuum certificates, but do not establish that a sampled LP score would change a recovered integer. These same witnesses are reused by two of the eight mutations.',
    'independence':'Real first-order and complex second-order interval routes share FLINT. Exact integer objectives and 85-digit mpmath displaced controls are additional routes. The retained global analytic argument is not formalized.',
    'unresolved':'Larger-radius surviving candidates do not prove feasible spectra or number fields. Wider-noise recovery of all seventeen targets is not established. The original full-support and wider ACS questions remain open.',
    'history_policy':'Preserve all 117 branches and the 393-event byte prefix; append five events. The ongoing goal remains active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Inherited Python 3.12.14 and pinned libraries. SciPy 1.17.0/HiGHS floating proposals; exact multiplier grid 10^-9. Producer bounds at 224/320 bits with 64/96 leaves; independent complex quadratic covers at 384 bits with 128 leaves; 192-bit outward integer objectives and 85-digit mpmath controls. No new packages, zeros, or Lean modules.'
write('Runtime.json',runtime)
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str((INPUTS/n).relative_to(ROOT)):sha((INPUTS/n).read_bytes()) for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json']},
    'scope':'Reuses the immutable aggregate measurements, spectra, frozen c7 duals and held-out arithmetic. The arithmetic vector is read only by independent verification.'})
write('Primary_Sources.json',{'recorded_utc':now,'new_downloads':0,'inherited_record':str((INPUTS/'Primary_Sources.json').relative_to(ROOT)),
    'inherited_record_sha256':sha((INPUTS/'Primary_Sources.json').read_bytes()),'sources':read(INPUTS/'Primary_Sources.json')['sources'],
    'scope':'The previously verified primary explicit-formula, moment and coefficient references are reused. No new download or visual inspection is claimed. New finite-error bounds follow the displayed mean-value and quadratic Taylor derivations.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Aggregate noise-adapted continuum-certificate delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],
    advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Sampled proposals with exact rational multiplier validation, one-sided continuum root-error covers, same-grid frozen ablations, complex quadratic and integer replay, and certified off-grid controls.',
    next_priority=['R12/R13: couple finite-root changes and known-moment tail variation before taking separate maxima',
      'R13/R14: extend noisy recovery beyond c7 and distinguish feasible inequality relaxations from actual spectral and global-field ambiguity',
      'R15: test additional verified fields with matched metadata, completeness and uncertainty contracts',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('noise_adapted_one_sided_continuum_bounds',
   'Noise-adapted exact rational duals and complete one-sided root-error covers retain c7=4 and c7=0 through tested radii 0.06 and 0.13. Same-grid frozen bounds reach 0.002 and 0.07; the latter extends the prior B grid. Independent complex quadratic covers confirm every exclusion and strengthen two derivative ablations.',
   'Couple finite Gaussian changes with the known-moment change of the same displaced roots before maximizing their separate conservative budgets; retain unconditional unknown-zero and omitted-prime bounds.'),
 'R13':('coefficient_seven_recovery_with_adapted_uncertainty_objectives',
   'Forty-eight sampled-error LP proposals are converted to nonnegative rational multipliers and validated over all 604 generic coefficient boxes. Both direct producer runs agree. Integer objective replay and nonlinear continuum covers validate the wider-noise c7 claims without local models or field templates.',
   'Extend the noisy calculation to the remaining sixteen targets and unresolved support coefficients, and require constructive feasibility before interpreting surviving candidates as ambiguity.'),
 'R14':('generic_unramified_supplement_to_adapted_noise_domains',
   'Applying the independently enumerated unramified degree-four coefficient set {0,1,2,4} to adapted direct domains extends A singleton recovery through tested radius 0.14; B remains at 0.13. This is a separately declared local supplement, while the generic-box radii remain 0.06 and 0.13.',
   'Combine more generic local relations with noisy spectral deductions and distinguish local compatibility from a globally realizable field or a certified ambiguity witness.'),
 'R15':('off_grid_counterexamples_enforce_continuum_certificate_boundary',
   'Two interval-certified root displacements between the 33 optimizer samples produce errors exceeding every sampled value, with strict gaps above 5.20e-9 and 2.48e-9. They disprove treating the sampled error maximum as a continuum bound. Eight semantic mutations, including those two witnesses, are rejected.',
   'Preserve the separation between numerical proposals, sufficient continuum certificates and identification limits when testing additional fields and observation models.'),
 'K04':('ongoing_delta_with_adapted_noise_and_off_grid_audits',
   'Preserve 117 branches and 393 events; append five events. Six scientific command receipts succeed. Fresh audits check 158400 stored midpoints, 126720 independent quadratic interval leaves, 192 exact objective bounds, 192 displaced sums and two certified off-grid witnesses. One producer subdivision difference and two stronger independent derivative results remain explicit.',
   'Continue useful deltas across the complete ACS queue, preserving assumptions, originals, failures, independent checks and exact continuation conditions without global completion or exhaustion.')}
prefix='docs/frontier/2026-09-13-aggregate-optimized-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_noise_adapted_continuum_audit')
        b['new_evidence']=[prefix+n for n in ['Noise_Summary.json','Proposals.json','Noise_Certificates.zip','Noise_Audit.json','Adversary_Audit.json','Inherited_Inputs.json']]
        b['verification_routes']+=['Same-grid frozen and noise-adapted duals with two finite-error enclosures','Fresh complex quadratic interval cover and exact integer objective replay',
            '85-digit displaced controls and interval-certified off-grid counterexamples','Eight semantic proof-component mutations','Explicit producer subdivision differences and stronger independent bounds']
        b['shared_assumptions_and_scope']='Inherited degree four, signature (0,2), discriminant 576 and complete finite critical-line spectra through 20. Generic 0..4 coefficient boxes in inference; the unramified-prime supplement is separate. Common displacements preserve root indices, multiplicities and cutoff. Unknown-zero tails remain unconditional. Only c7 receives the new wide-noise claims; sampled scores are not proofs or optimality bounds, and surviving domains need not be globally realizable.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=393
for bid in q['advanced_existing_branches']:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'noise_adapted_continuum_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Aggregate noise-adapted continuum certificates — 13 September 2026

Noise-adapted multipliers and one-sided interval bounds recover coefficient seven through tested ordinate radii 0.06 and 0.13 in the two shared-invariant spectra. On the identical grid, the frozen multipliers reach 0.002 and 0.07. The calculation preserves full coefficient residuals, omitted-prime bounds, unknown-zero budgets and finite-population assumptions.

This pass concerns coefficient seven. It does not establish wider-noise recovery of all seventeen targets from the preceding checkpoint. It computes no new zeros, uses no candidate-field catalogue or Galois group, and does not claim optimal radii or global field realizability of surviving candidates. The [derivation and reproduction guide](../../../code/frontier_verification/AGGREGATE_OPTIMIZED_README.md) explains the input contract, optimization surrogate, complete interval covers and limitations.

The evidence separates multiplier adaptation from error geometry. After including the stronger independent audit, adapted symmetric derivative bounds reach 0.02 and 0.1, while adapted one-sided bounds reach 0.06 and 0.13. The new frozen B point 0.07 extends the previous grid and is not credited to optimization. Applying a separately declared generic unramified-prime rule extends A's tested radius to 0.14; B remains at 0.13.

Both direct producer runs agree. One derivative-only domain narrows under finer subdivision, and the independent quadratic audit strengthens two further derivative domains. All differences are retained. Two certified off-grid points exceed every one of the optimizer's 33 sample errors, proving that sampled maxima alone cannot certify continuous uncertainty.

- [Results and all ablations](Noise_Summary.json), including producer differences, independently stronger domains and the optional local supplement.
- [Forty-eight rational multiplier proposals](Proposals.json) and the separately preserved [exploratory probe](Exploratory_Probe.json). Floating proposal scores are not mathematical bounds.
- [Both complete certificate runs](Noise_Certificates.zip), with every exact interval leaf and residual/tail budget.
- [Independent audit](Noise_Audit.json): 158,400 midpoint checks, 126,720 fresh complex quadratic interval leaves, 192 exact integer objective bounds, 192 high-precision displaced sums, and two interval-certified off-grid counterexamples.
- [Eight semantic mutations](Adversary_Audit.json); two use the same off-grid witnesses already counted in the independent audit.
- [Six successful scientific execution receipts](Execution_Receipts.json), [full command outputs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json), and [reused primary sources](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json), and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [398-event ledger](Branch_Events.jsonl), preserving the preceding 393 events byte for byte.

The interval routes share FLINT, while exact integer arithmetic and mpmath provide complementary checks. The full analytic and number-field proof remains unformalized. All prior failures and dated evidence remain intact in the [preceding checkpoint](../2026-09-13-aggregate-shared-delta/README.md) and its history.

The next gate is to combine finite Gaussian changes with the known-moment change of the same displaced roots before taking separate maxima, then extend noisy recovery to additional coefficients and fields. The wider ACS investigation remains active.
''')
names=['dedekind_aggregate_noise_proposals.py','dedekind_aggregate_noise_certificate.py','dedekind_aggregate_noise_audit.py','dedekind_aggregate_noise_adversary.py','verify_aggregate_optimized_delta.py','AGGREGATE_OPTIMIZED_README.md']
deps=['dedekind_aggregate_shared.py','dedekind_aggregate_shared_audit.py','dedekind_aggregate_integer_audit.py','dedekind_aggregate_local_audit.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','verify_aggregate_shared_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New noise-adapted proposal/certificate/audit instruments and their direct dependencies. The exploratory probe is preserved in the packaging snapshot. Earlier checkpoints and dependency hashes are verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py','proposal_probe.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder for the report produced by the fresh recursive verifier; not a success claim.'})
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; the preceding checkpoint is verified recursively.'})
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
