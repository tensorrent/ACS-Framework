from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-nested-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-adaptive-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_nested_delta import summarize
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)

for n in ['Nested_Audit.json','Nested_Closure.json','Adversary_Audit.json','Lean_Check.json']:(OUT/n).write_bytes((BASE/n).read_bytes())
archive('Nested_Feedback.zip',[(BASE/'Nested_Feedback.json','Nested_Feedback.json')])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean']]+[(CODE/'proofs/NoiseBoxTransfer.lean','NoiseBoxTransfer.lean')])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==5 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(*[read(BASE/n) for n in ['Nested_Feedback.json','Nested_Audit.json','Nested_Closure.json']])
write('Nested_Summary.json',{'recorded_utc':now,
    'result':'All seventeen aggregate-spectrum targets are certified at radius 0.08 for A and 0.05 for B under both local profiles, with exact wider-to-narrower premise transfer and four kernel-checked geometric theorems.',
    'input_contract':['degree four','signature (0,2)','discriminant 576','complete aggregate finite critical-line spectra through 20','same fixed original root intervals and measurement family','generic coefficient boxes 0..4','validated radius-0.1 domains under the same local profile'],
    'local_deduction_profiles':['degree-only local models','degree plus ramification from the supplied discriminant'],
    'not_inference_inputs':['Galois group','candidate field catalogue','defining polynomials','subfields','conductor-parity assignment','held-out arithmetic coefficients','smaller-radius successes used to seed larger radii'],
    'new_roots_computed':0,'measurement_rows':17,'target_count':17,'generic_coefficients':604,'derived_results':summary,
    'transported_root_intervals':540,'stored_midpoints_checked':110832,'fresh_quadratic_interval_leaves':221664,'exact_domain_objectives':470,'independent_displaced_controls':412,
    'actual_component_mutations_rejected':10,'kernel_checked_transfer_theorems':4,
    'scope':'Certificates at a given radius also apply to contained smaller boxes under the unchanged input contract. The next tested nonclosure points, 0.1 for A and 0.06 for B, are method outcomes and not impossibility bounds. Re-optimizing from the stronger radius-0.1 audit domains adds no exclusions there. Four stronger interim audit findings do not change final domains.',
    'full_proof_formalized':False,'next_gate':'Refine the tested success/nonclosure ranges, improve optimization or propagation, compare noisy standalone-row inference, and investigate constructive/global feasibility of surviving domains.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':5,'successful_commands':5,'failed_commands':0,
    'recording_scope':'Nested-radius adaptive feedback, independent continuum/domain audit, Lean compilation, unchanged exact closure and transfer adversary. Packaging and recursive verification are separate. Earlier failures remain intact.',
    'freeze_boundary':'Each new scientific instrument and the Lean source were frozen before their recorded executions. The prior adaptive helpers, interval kernels and supplemental closure instrument are reused unchanged. The independent audit was written before its run and consumes frozen producer output.',
    'new_derivation':'For fixed source intervals, both endpoint margins between outer radius R and inner radius r equal R-r. Exact inclusion transfers all universally valid coefficient exclusions for the outer box to the inner box when metadata, root correspondence and local profile remain unchanged.',
    'independence':'Producer interval membership inequalities are checked by exact rational endpoint differences; scalar, coordinatewise and predicate transport are kernel checked. Real first-derivative covers are audited by complex quadratic covers with rational moments and exact integer support. Transcendental intervals share FLINT; 412 mpmath controls are samples.',
    'input_boundary':'Every run starts from the same independently strengthened radius-0.1 domains for its observation/profile. No newly computed smaller-radius success is reused as a wider-radius premise. Arithmetic vectors remain downstream checks; formal software noninterference is not claimed.',
    'audit_delta':'Four stronger interim exclusions are all eventually made by the producer. Exact closure adds zero dual or local exclusions. The repeated radius-0.1 calculation stabilizes in one round with no further removal.',
    'kernel_scope':'Four Lean theorems concern interval geometry, arbitrary coordinatewise boxes, universal predicate transport and failure of reverse inclusion. They do not formalize the numerical, explicit-formula, arithmetic or file-lineage premises.',
    'counterexample_scope':'One interval endpoint disproves reverse transport by a margin of 0.02; a second display explains the counted binary64 rounding mutation with an exact outward increase of 1e-21. Neither constructs another field or proves a noise impossibility threshold.',
    'history_policy':'Preserve all 117 branches and the 408-event byte prefix; append five events. The full ACS investigation remains active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Inherited Python 3.12.14 and pinned libraries; 224-bit real/48-leaf certificates, 384-bit complex/96-leaf audits, rational moments, integer/Fraction supports and 85-digit mpmath controls. Lean 4.34.0-rc2 with inherited pinned mathlib compiles four new geometric transfer theorems. No new packages or downloads.'
write('Runtime.json',runtime)
input_paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json']]+[PRIOR/n for n in ['Audit_Closure.json','Manifest.json','Verification.json']]
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in input_paths},
    'scope':'Fixed spectra and measurements, plus exact radius-0.1 seed domains whose prior numerical and local proofs are recursively verified. Manifest and Verification in scientific input maps refer to the preceding checkpoint, not this output package.'})
write('Primary_Sources.json',{'recorded_utc':now,'new_downloads':0,'inherited_record':str((INPUTS/'Primary_Sources.json').relative_to(ROOT)),
    'inherited_record_sha256':sha((INPUTS/'Primary_Sources.json').read_bytes()),'sources':read(INPUTS/'Primary_Sources.json')['sources'],
    'scope':'Previously verified explicit-formula, coefficient and moment references remain inherited. Interval containment and universal-predicate transfer are derived directly and checked in Lean. No new page inspection or download is claimed.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Nested uncertainty and kernel-transfer delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Exact nested noise-box transfer, twenty-four adaptive recoveries, new continuum and integer audits, unchanged supplemental closure, four Lean theorems and ten premise-transfer mutations.',
    next_priority=['R12/R13: refine the A (0.08,0.1) and B (0.05,0.06) tested success/nonclosure ranges without interpreting stalled updates as impossibility',
      'R13/R14: improve optimization or propagation, compare noisy standalone-row inference, and investigate constructive/global feasibility',
      'R15: extend actual-field benchmarks with matched metadata, completeness and uncertainty contracts',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('nested_noise_box_transfer_with_kernel_checks',
   'Exact interval inclusion transfers previously validated radius-0.1 coefficient domains to contained noise boxes with fixed root correspondence, metadata and local profile. Four Lean theorems check scalar/coordinatewise inclusion, predicate transfer and a reverse-inclusion counterexample. The independent audit checks 540 transported root intervals.',
   'Use certified inclusion when refining noise tests or retaining valid measurements, while keeping full analytic and arithmetic premises separate from the geometric kernel theorem.'),
 'R13':('all_target_recovery_at_radii_008_and_005',
   'Across twenty-four cases and 470 new vectors, both local profiles recover all seventeen targets for A at radius 0.08 and B at radius 0.05. Certificates transfer to contained smaller boxes. At radius 0.1, re-optimization from the audit-strengthened domains adds no exclusions and retains 15/11 or 14/11 targets by profile.',
   'Refine the A success/nonclosure test range (0.08,0.1) and B range (0.05,0.06). Improve the deduction method before interpreting stalled updates; these upper endpoints are not impossibility or optimality bounds.'),
 'R14':('nested_adaptive_exclusions_and_fixed_point_limits',
   'Independent exact replay validates 132 dual exclusions and 100 consequent local exclusions. Four stricter intermediate audit findings are all later obtained by the producer; supplemental closure adds zero exclusions. All 604 held-out coefficients survive each round. Full coefficient domains and local-model identities are retained.',
   'Compare noisy standalone-row propagation and investigate constructive feasibility or global-field obstructions for surviving coefficient assignments; preserve stronger earlier exact-input support results.'),
 'R15':('transfer_direction_population_and_exact_order_audited',
   'Ten mutations test radius direction, an outward increase hidden by binary64 rounding, negative noise, missing/permuted roots, shifted source intervals, escaping endpoints, wrong-observation seeds, narrow-radius singletons and future-domain premises. Exact endpoint witnesses expose reverse transport and a 1e-21 outward radius error.',
   'Preserve exact observation, profile, root population and interval contracts when transferring evidence; distinguish geometric counterexamples from alternate spectra or fields.'),
 'K04':('ongoing_delta_with_nested_certificates_and_lean_transport',
   'Preserve 117 branches and 408 events; append five. Five scientific commands succeed. New checks cover 540 interval transfers, 110832 stored midpoints, 221664 fresh quadratic leaves, 470 exact objectives, 412 displaced controls, four Lean theorems and ten mutations. The full queue and prior failures remain intact.',
   'Continue evidence-backed deltas across the queue without global completion, retaining exact assumptions, source versions, negative outcomes and actionable gates.')}
prefix='docs/frontier/2026-09-13-aggregate-nested-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_nested_uncertainty_and_kernel_transfer_audit')
        b['new_evidence']=[prefix+n for n in ['Nested_Summary.json','Nested_Feedback.zip','Nested_Audit.json','Nested_Closure.json','Lean_Check.json','Adversary_Audit.json']]
        b['verification_routes']+=['Exact rational interval inclusion for inherited coefficient domains','Four Lean geometric transport theorems and fresh compilation','Adaptive vectors with newly certified real error budgets','Independent complex quadratic, rational moment and integer domain replay','Ten transfer-contract mutations with exact endpoint witnesses']
        b['shared_assumptions_and_scope']='Degree four, signature (0,2), discriminant 576 and complete finite critical-line spectra through 20. The same original root intervals, population, cutoff, measurement family and local profile are retained during transfer. Wider-radius domains may seed contained smaller boxes; the reverse direction is not assumed. No field catalogue, Galois group or arithmetic seed is supplied. Stalled updates do not prove optimality or global ambiguity; the Lean module formalizes only box geometry and predicate transport.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=408
for bid in q['advanced_existing_branches']:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'nested_uncertainty_and_kernel_transfer_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Nested uncertainty and kernel-transfer delta — 13 September 2026

All seventeen benchmark targets are certified for A at ordinate radius 0.08 and B at radius 0.05 under both generic local profiles. The certificates also apply to contained smaller noise boxes with the same input contract. Each case starts from the preceding independently strengthened radius-0.1 domains and transfers them by exact interval inclusion, then re-optimizes and freshly certifies measurement combinations. No new roots, measurements, field templates or arithmetic seeds are supplied.

The [derivation and reproduction guide](../../../code/frontier_verification/AGGREGATE_NESTED_README.md) connects the numerical calculation with the kernel-checked transfer rule. At radius 0.1, re-optimizing from the stronger audit domains makes no further exclusions. The next tested nonclosure radii are 0.1 for A and 0.06 for B; these locate useful next experiments, not proved impossibility or optimality thresholds.

- [Results, domains and next test ranges](Nested_Summary.json).
- [All twenty-four nested recoveries and 470 continuum certificates](Nested_Feedback.zip), including exact premise intervals, local models, proposals and every round.
- [Independent numerical audit](Nested_Audit.json): 540 root-interval transfers, 110,832 stored midpoint checks, 221,664 fresh complex quadratic leaves, 470 exact objectives, 412 displaced controls, 132 dual exclusions and 100 local exclusions. All 604 held-out true coefficients remain after every round.
- [Supplemental exact closure](Nested_Closure.json): four stronger intermediate audit findings are already obtained by the producer later; no additional exclusions result.
- [Four Lean theorem checks](Lean_Check.json) and [compiled/source artifacts](Lean_Artifacts.zip), proving scalar and coordinatewise inclusion, universal-predicate transfer, and failure of the reverse inclusion. The full numerical and arithmetic argument is not formalized by these geometric theorems.
- [Ten transfer mutations and exact endpoint witnesses](Adversary_Audit.json), including an outward radius increase of 1e-21 that has the same binary64 representation as 0.1. The exact check rejects it.
- [Five scientific execution receipts](Execution_Receipts.json), [full outputs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json) and [reused sources](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [413-event ledger](Branch_Events.jsonl), preserving the prior 408 events byte for byte.

Exact rational differences check both sides of every transferred interval. The same observation, local profile, root indexing, population and global inputs are retained. The transcendental interval methods share FLINT; rational, integer and Lean checks have their stated scopes. No surviving domain is asserted to describe an actual field. Earlier failures and stronger exact-input support results remain in the [preceding checkpoint](../2026-09-13-aggregate-adaptive-delta/README.md) and its history.

Next, refine the A (0.08,0.1) and B (0.05,0.06) success/nonclosure test ranges, improve the optimization or propagation method, compare noisy standalone-row inference and investigate constructive/global feasibility. The wider ACS investigation remains active.
''')
names=['dedekind_aggregate_nested.py','dedekind_aggregate_nested_audit.py','dedekind_aggregate_nested_adversary.py','check_noise_box_lean.py','proofs/NoiseBoxTransfer.lean','verify_aggregate_nested_delta.py','AGGREGATE_NESTED_README.md']
deps=['dedekind_aggregate_adaptive.py','dedekind_aggregate_adaptive_audit.py','dedekind_aggregate_adaptive_closure.py','dedekind_aggregate_moment_certificate.py','dedekind_aggregate_moment_audit.py','dedekind_aggregate_moment_local_audit.py','dedekind_aggregate_shared.py','dedekind_aggregate_shared_audit.py','dedekind_aggregate_noise_certificate.py','dedekind_aggregate_noise_audit.py','dedekind_aggregate_integer_audit.py','dedekind_aggregate_local_audit.py','dedekind_coefficient_recovery.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','verify_aggregate_adaptive_delta.py','verify_aggregate_moment_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New nested-domain, Lean and adversarial instruments plus unchanged direct dependencies. All executed versions are retained; prior packages verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder for the fresh recursive verifier output; not a success claim.'})
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoint verified recursively.'})
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
