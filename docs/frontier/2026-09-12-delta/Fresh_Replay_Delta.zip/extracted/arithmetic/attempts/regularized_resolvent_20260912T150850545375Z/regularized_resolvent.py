"""Trace-class subtraction, differentiated tails, determinant and blind-spot tests."""
import json
import mpmath as mp
import sympy as sp
mp.mp.dps=50

g,z,w=sp.symbols('g z w',nonzero=True)
assert sp.factor((1/(g-z)-1/g)-z/(g*(g-z)))==0
assert sp.factor(1/(g-z)+1/(-g-z)-2*z/(g*g-z*z))==0
assert sp.factor(-sp.diff(sp.log(1-z*z/g**2),z)-2*z/(g*g-z*z))==0

a=mp.mpf('.10076');b=mp.mpf('.24460');c=mp.mpf('8.08344')
def H(T):
    T=mp.mpf(T)
    return (mp.log(T/(2*mp.pi))+1)/(2*mp.pi*T)+(a*(2*mp.log(T)+mp.mpf('.5'))+b*(2*mp.log(mp.log(T))+1/(2*mp.log(T)))+2*c)/T**2
constants=[]
for T in [100,1000,1000000]:
    K=mp.mpf(10);T=mp.mpf(T);hh=H(T)
    constants.append({'T':int(T),'K':10,'inverse_square_tail_H':str(hh),'subtracted_resolvent_trace_norm_tail_bound':str(2*K/(1-K/T)*hh),'first_derivative_trace_norm_tail_bound':str(2/(1-K/T)**2*hh),'relative_product_error_bound':str(mp.expm1(K*K/(1-(K/T)**2)*hh))})

# Route independent of any zeta-zero generation: exact integer spectrum.
# Product identity is sin(pi*z)/(pi*z); trace uses the cotangent identity.
instrument=[]
for zz in [mp.mpc('.3','.4'),mp.mpc('1.2','.2')]:
    exactD=mp.sin(mp.pi*zz)/(mp.pi*zz)
    exactS=1/zz-mp.pi*mp.cot(mp.pi*zz)
    exactDerivative=-1/zz**2+mp.pi**2/mp.sin(mp.pi*zz)**2
    for N in [20,80,320]:
        T=mp.mpf(N);K=abs(zz);tail=1/T
        D=mp.fprod(1-zz**2/n**2 for n in range(1,N+1))
        paired=sum(2*zz/(n*n-zz*zz) for n in range(1,N+1))
        derivative=sum(1/(n-zz)**2+1/(-n-zz)**2 for n in range(1,N+1))
        det_bound=mp.expm1(K*K/(1-K*K/T**2)*tail)
        scalar_bound=2*K/(1-K*K/T**2)*tail
        derivative_bound=2/(1-K/T)**2*tail
        assert abs(exactD/D-1)<=det_bound
        assert abs(exactS-paired)<=scalar_bound
        assert abs(exactDerivative-derivative)<=derivative_bound
        direct_regularized=sum((1/(sgn*n-zz)-1/(sgn*n)) for n in range(1,N+1) for sgn in [-1,1])
        assert abs(direct_regularized-paired)<mp.mpf('1e-45')
        instrument.append({'N':N,'z':[str(zz.real),str(zz.imag)],'determinant_relative_error':str(abs(exactD/D-1)),'determinant_error_bound':str(det_bound),'paired_trace_error':str(abs(exactS-paired)),'derivative_error':str(abs(exactDerivative-derivative))})

# Two symmetry-compatible zero multisets with identical ordinate data:
# central zeros repeated twice vs a reflected off-line quartet.
gg,alpha=sp.symbols('gamma alpha',positive=True,real=True)
off=(1-z*z/(gg+sp.I*alpha)**2)*(1-z*z/(gg-sp.I*alpha)**2)
central=(1-z*z/gg**2)**2
coefficient=sp.factor(sp.expand(off-central).coeff(z,2))
expected=2*alpha**2*(3*gg**2+alpha**2)/(gg**2*(gg**2+alpha**2)**2)
assert sp.simplify(coefficient-expected)==0

print(json.dumps({'status':'passed','external_input':'Bellotti-Wong Theorem 1.1, https://arxiv.org/html/2412.15470v2; same H(T) as retained R10, not a new zero count theorem.','new_operator_statement':'For the declared diagonal +/-gamma operator, R(z)-H^{-1} is trace class and has trace equal to the paired scalar sum. H^{-1} is bounded because gamma_1>0, but is not trace class.','new_bounds':constants,'independent_integer_instrument':instrument,'ordinate_blind_spot':{'symbolic_z_squared_coefficient_difference':str(coefficient),'strictly_positive_for':'gamma>0 and alpha>0','interpretation':'Ordinate-only observables cannot distinguish a reflected off-line quartet from two repeated central pairs. These are abstract zero multisets, not a construction of alternative zeta zeros.'},'boundary':'Constructed spectral regularization only. No natural Hilbert-Polya operator, real-part identification, or RH bound.'},indent=2))
