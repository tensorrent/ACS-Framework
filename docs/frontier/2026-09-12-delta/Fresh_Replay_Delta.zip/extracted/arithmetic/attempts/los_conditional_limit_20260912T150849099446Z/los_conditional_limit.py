"""Two exact routes to a conditional fixed-modulus LOS spectral limit."""
import json, math
import numpy as np
import sympy as sp

def leading(k, exact=False):
    if exact:
        L=sp.zeros(k*k)
        for a in range(k):
            for b in range(k):
                for c in range(k):L[b*k+c,a*k+b]=sp.Rational(1,2*k)-sp.Rational(int(b==c),2)
    else:
        L=np.zeros((k*k,k*k))
        for a in range(k):
            for b in range(k):L[b*k:(b+1)*k,a*k+b]=1/(2*k)-np.eye(k)[b]/2
    return L

exact=[]
for k in [2,3,4,5]:
    L=leading(k,True)
    S=sp.zeros(k,k*k);V=sp.zeros(k*k,k)
    for a in range(k):
        for b in range(k):
            S[b,a*k+b]=1
            V[a*k+b,a]=sp.Rational(1,2*k)-sp.Rational(int(a==b),2)
    assert L==V*S
    assert S*V==-(sp.eye(k)-sp.ones(k)/k)/2
    # Independent direct characteristic polynomial, no numeric root matching.
    t=sp.symbols('lambda')
    cp=L.charpoly(t).as_expr()
    assert sp.factor(cp-t**(k*k-k+1)*(t+sp.Rational(1,2))**(k-1))==0
    assert L.rank()==k
    assert L**3==-L**2/2
    exact.append({'k':k,'rank':k,'characteristic_polynomial':str(sp.factor(cp)),'nonzero_eigenvalues':{'-1/2':k-1},'limiting_effective_rank':k-1})

# Exact quotient derivative verifies the c1 cancellation separately from V,S.
h,aa,bb,cc,k=sp.symbols('h aa bb cc k',positive=True)
C=1-k*(aa+bb)/2
Cbar=sp.Rational(1,2)-k*aa/2
P=(1+h*C)/(k*(1+h*Cbar))-1/k
assert sp.simplify(sp.diff(P,h).subs(h,0)-(sp.Rational(1,2)/k-bb/2))==0

surrogate=[]
for k in [2,4,8]:
    L=leading(k)
    C=np.zeros((k,k,k))
    for a in range(k):
        for b in range(k):
            for c in range(k):C[a,b,c]=1-k*(int(a==b)+int(b==c))/2
    for h in [.03,.01,.003,.001]:
        P=np.zeros_like(L)
        for a in range(k):
            for b in range(k):
                prob=1+h*C[a,b,:];prob/=prob.sum()
                P[b*k:(b+1)*k,a*k+b]=prob-1/k
        e=abs(np.linalg.eigvals(P/h))
        effective=e.sum()**2/(e@e)
        error=float(np.linalg.norm(P/h-L,2))
        # Leading data have delta=h*(k-1) and eta=0.
        delta=h*(k-1)
        bound=(k-1)*delta/(1-delta)
        assert error<bound
        surrogate.append({'k':k,'h':h,'operator_error':error,'proved_generic_error_bound':bound,'effective_rank':float(effective),'target':k-1})

# Fresh prime instrumentation, counted by two independently implemented paths.
# This is finite evidence; it neither verifies nor falsifies the x->infinity claim.
limit=2_000_000
sieve=np.ones(limit+1,dtype=bool);sieve[:2]=False
for p in range(2,math.isqrt(limit)+1):
    if sieve[p]:sieve[p*p::p]=False
primes=np.flatnonzero(sieve)
finite=[]
for modulus in [3,4,6,10,12,30]:
    residues=[r for r in range(modulus) if math.gcd(r,modulus)==1]
    index={r:i for i,r in enumerate(residues)};k=len(residues)
    for x in [20_000,200_000,2_000_000]:
        pp=primes[(primes>modulus)&(primes<=x)]
        seq=np.array([index[int(p%modulus)] for p in pp])
        count=np.bincount((seq[:-2]*k+seq[1:-1])*k+seq[2:],minlength=k**3).reshape(k,k,k)
        if x==20_000:
            direct=np.zeros_like(count)
            for a,b,c in zip(seq[:-2],seq[1:-1],seq[2:]):direct[a,b,c]+=1
            assert np.array_equal(count,direct)
        totals=count.sum(axis=2)
        if np.min(totals)==0:raise ValueError('Missing column; operator not defined by the manuscript.')
        P=np.zeros((k*k,k*k))
        for a in range(k):
            for b in range(k):P[b*k:(b+1)*k,a*k+b]=count[a,b,:]/totals[a,b]-1/k
        # Clear each positive column denominator. Exact integer ranks bypass
        # eigenvalue cutoffs and the ill-conditioning of small eigenvalues.
        exact_block_ranks=[]
        for b in range(k):
            numerator=sp.Matrix([[int(k*count[a,b,c]-totals[a,b]) for a in range(k)] for c in range(k)])
            exact_block_ranks.append(numerator.rank())
        h=math.log(math.log(x))/math.log(x)
        e=abs(np.linalg.eigvals(P))
        finite.append({'modulus':modulus,'k':k,'x':x,'eligible_primes':len(pp),'minimum_column_count':int(totals.min()),'exact_block_ranks':exact_block_ranks,'exact_algebraic_rank':sum(exact_block_ranks),'maximal_possible_rank':k*(k-1),'rho_over_h':float(e.max()/h),'effective_rank':float(e.sum()**2/(e@e)),'leading_target_effective_rank':k-1,'norm_P_over_h_minus_L':float(np.linalg.norm(P/h-leading(k),2))})

print(json.dumps({'status':'passed','external_hypothesis':'Lemke Oliver-Soundararajan Main Conjecture, https://arxiv.org/html/1603.03720v4, for r=3 and each fixed modulus. This script does not prove the conjecture.','own_conditional_conclusion':'h=loglog(x)/log(x); P(x)/h -> L with L[(b,c),(a,b)]=1/(2k)-1_{b=c}/2. Hence rho(P)/h -> 1/2 and the manuscript eigenvalue participation rank -> k-1 for k>=2.','exact_routes':exact,'controlled_surrogates':surrogate,'finite_actual_prime_checks':finite,'endpoint_convention':'LOS counts triples by first prime <=x, whereas this finite code requires all three <=x. At most two endpoint triples plus finitely many primes <=m differ; for each fixed modulus this is negligible compared with li(x)*h.','boundary':'No uniform-in-modulus LOS remainder and no unconditional arithmetic theorem established.'},indent=2))
