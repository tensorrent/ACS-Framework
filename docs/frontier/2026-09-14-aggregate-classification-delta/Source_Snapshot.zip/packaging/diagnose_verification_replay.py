import hashlib,json,sys
from pathlib import Path
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
sys.path.insert(0,str(CODE))
import dedekind_full_quartic_audit as audit
from verify_aggregate_moment_delta import canonical
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta'
stored=json.loads((OUT/'Full_Class_Audit.json').read_text())
fresh=audit.run(OUT/'Full_Quartic_Class.json',OUT/'Metadata.json',ROOT/'docs/frontier/2026-09-13-biquadratic-delta/Pair_Candidate_Class.json')
normalized=json.loads(json.dumps(fresh))
assert canonical(stored)!=canonical(fresh)
assert canonical(stored)==canonical(normalized)
old=stored['independent_group_audit']['subgroup_order_counts'];new=fresh['independent_group_audit']['subgroup_order_counts']
assert {int(k):v for k,v in old.items()}==new
r={'status':'passed','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
   'cause':'JSON roundtrip changes integer object keys to strings. Sorting fresh integer keys numerically and stored string keys lexically gives unequal byte serializations despite identical subgroup counts.',
   'stored_key_types':sorted({type(k).__name__ for k in old}), 'fresh_key_types':sorted({type(k).__name__ for k in new}),
   'counts':old,'raw_sorted_serialization_equal':False,'JSON_normalized_full_document_equal':True,
   'scope':'The entire regenerated audit equals the recorded document after JSON normalization. No numerical, group-theoretic, arithmetic or scientific-source change is required. Correct only the new verifier comparison in a separate version.'}
(BASE/'Verification_Diagnosis.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
