from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-variable-noise-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta'
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta';CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
sys.path.insert(0,str(CODE))
from verify_aggregate_variable_noise_delta import summarize,FAILURES,ADVANCED

OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)
    assert (OUT/name).stat().st_size<100*1024**2

documents=['Boundary_Pair_Proposals.json','Boundary_Pair_Checks.json','Shifted_Pair_Proposals.json','Shifted_Pair_Checks.json','Variable_Noise_Certificate.json','Independent_Variable_Noise_Audit.json','Adversary_Audit.json','Lean_Check.json','Source_Acquisition.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
reports=[read(BASE/n) for n in ['Variable_Noise_Certificate.json','Independent_Variable_Noise_Audit.json','Adversary_Audit.json','Lean_Check.json','Shifted_Pair_Proposals.json']]
write('Variable_Noise_Summary.json',{'recorded_utc':now,'result':'Four exact variable-noise pairs with freely moving feature midpoints improve the local ambiguity upper endpoint to approximately 1.831989439894397e-10. The ratio to the inherited uniform lower guarantee is approximately 1.0359001329.',
    'derived_results':summarize(*reports),'source_premises':'Inherited complete discriminant-576 two-field class and complete 22-entry positive source populations below 39/2, selected before coordinate errors and retaining every entry and multiplicity.',
    'unchanged_contract':'Root error r=U-1e-8<L; radius-0.01 standard coordinate cube about the same rational midpoint roots; the same 22 finite features and independent absolute feature errors. No raw roots, count profile, infinite moment or unknown tail is included.',
    'new_construction':'Fix both critical roots just inside their source bounds and all B roots as exact rationals. Solve for 21 A corrections and alpha=tau/1e-10, with constant final Jacobian column -2e-10*v. The common report is the exact feature midpoint of the pair, not constrained to Phi(c).',
    'existence_and_independence':'Real interval Jacobians at 768/1024 bits prove strict self-mapping contraction on mixed-variable cubes of radius 1e-120. Independent complex derivatives at 896/1152 bits, modular nonsingularity and 704 directly rebuilt scalar source inequalities support all four pairs. Both analytic routes share FLINT.',
    'threshold_scope':'The inherited uniform lower guarantee is unchanged. Each exact pair has a sharp midpoint budget equal to its own positive tau; the upper endpoint bounds the restricted global ambiguity threshold from above. No globally optimal threshold or arbitrary-report decoder is established.',
    'failures_and_negative_evidence':'One original Newton search fails with a numerically singular matrix; separate v2 uses a predictor and backtracking. A later numerically converged, source-feasible trial with a lower tau leaves the certified cube and is rejected. Both are retained without impossibility claims.',
    'formal_scope':'Six new Lean lemmas prove scaled positive bounds, affine noise-column behavior, midpoint error and necessary budget, critical separation and fixed-report scope control. The complete contraction/calculus, interval/modular and field/spectral bridges remain written or computational.',
    'open_gates':'Tighter source-constrained uniform lower bounds or subdivisions; better upper constructions; validated parameter families; bounded-error inverse decoding; global region extensions/counterexamples; physical acquisition and fuller formalization. All wider ACS and private-input branches remain active.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==10 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean']]+[(CODE/'proofs/VariableNoiseMidpoint.lean','VariableNoiseMidpoint.lean')])
write('Development_Notes.json',{'recorded_commands':10,'successful_commands':9,'failed_commands':1,
    'failures':[{'receipt':'shifted-pair-exploration','result':'The first common-shift search calls Newton from the unchanged A correction and raises ZeroDivisionError: matrix is numerically singular. No proposal JSON is emitted. Separate v2 predicts the common A shift and first-order tau change, and catches failed trial solves during backtracking. The failed source remains unchanged.'}],
    'rejected_trial':'The last full optimizer step converges and passes source-center checks, but its maximum center displacement exceeds the cube radius by approximately 1.4599e-6. The smaller accepted step is certified. A rejected search trial does not prove global impossibility.',
    'setup_note':'An initial scratch-directory setup used a workspace-relative path from the repository directory; cp and runner launch failed before any scientific script executed. The unexecuted directory was moved to the intended scratch location. No scientific source was overwritten or run during that setup attempt.',
    'source_policy':'Executed sources and reports remain immutable. Numerical proposal labels reflect their original exploratory status; later canonical certificates and independent audits establish the stated exact results. The subsequent recursive verifier preserves its own external receipt and supplies exact stdout bytes as Verification.json.',
    'runtime':'No package acquisition, version change or new source roots. Existing pinned Python/FLINT and Lean/mathlib are reused.',
    'independence':'Primary real interval Jacobian matrix products and independent complex scalar derivative bounds share FLINT. The independent auditor rebuilds source inequalities directly and repeats polynomial factorizations. Classification, source roots and the uniform lower theorem are inherited and recursively verified.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned numerical and Lean/mathlib runtimes; no acquisition. Six new variable-noise midpoint and scope lemmas compile. Previous acquisitions retain original dated records.')
for key,pkg in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(pkg)
write('Runtime.json',runtime)
paths=[SOURCE/'Equal_Population_Inputs.zip',SOURCE/'Equal_Population_Decoder.json',PRIOR/'Verification.json',PRIOR/'Research_Queue.json',PRIOR/'Branch_Events.jsonl',PRIOR/'Feature_Space_Proposals.json',PRIOR/'Weighted_Region_Certificate.json',PRIOR/'Independent_Weighted_Region_Audit_v2.json',ANCHOR,CLASS/'Full_Quartic_Class.json',CLASS/'Full_Class_Audit.json',PAIR/'Pair_Arithmetic.json',CODE/'verify_aggregate_weighted_feature_delta_v2.py']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'Complete field class, source populations, root midpoint/direction, previous numerical seed, certified region and uniform lower bound remain inherited. Fresh exact source constraints, analytic audits and arithmetic comparisons are added; the whole previous chain is recursively verified.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',CLASS/'Primary_Sources.json',PAIR/'Primary_Sources.json']},'new_source_record':'Source_Acquisition.json',
    'scope':'Primary Mathlib absolute-value documentation was retrieved. Pinned absolute-value and normed-group sources match local Git objects and are archived with their license. Current documentation is distinct from pinned source evidence. The new midpoint, scaling and implicit-derivative arguments are explicitly derived.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Moving feature midpoints and tighter variable-noise delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=ADVANCED,
    replay_scope='Four mixed root/noise contraction certificates, independent complex and exact source audits, moving midpoint separation, 64 adversaries and six Lean lemmas. Original searches, failure and rejected trial are preserved and replayed. All wider branches remain tracked.',
    next_priority=['R12/R13/R14: source-constrained lower bounds or subdivisions, improved upper constructions and bounded-error inverse decoding','R15: validated parameter families, global region extensions and complete analytic/formal bridges','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
    'R12':('free_midpoint_reports_certified_under_unchanged_contract','Four exact variable-noise pairs inside the same radius-0.01 cube and fixed root-error contract share freely moving feature midpoint reports. A budget of 1.832e-10 is sufficient; the best exact endpoint is approximately 1.831989439894397e-10. The earlier fixed-report exclusions do not exclude these pairs.','Audit source-constrained lower bounds and physical feature units; implement bounded-error inverse-set decoding and validate parameter families without silently changing region, source selection or tail contracts.'),
    'R13':('arithmetic_ambiguity_at_tighter_feature_budget','Independent polynomial arithmetic confirms 456 fixed and 148 ambiguous coefficients among 604 at each new noisy report. The unchanged conditional uniform lower guarantee and improved actual upper endpoint have ratio approximately 1.0359001329.','Tighten the restricted threshold, recover robust coefficient domains for arbitrary reports and extend metadata classes or global domains with explicit premises.'),
    'R14':('variable_noise_constructions_reduce_local_threshold_gap','Solving for 21 A roots and one scaled noise variable, with fixed critical roots and rational B, certifies four pairs by two analytic routes. The strongest accepted common-shift pair reduces the upper/lower ratio from about 1.1309 to 1.0359. One lower numerical trial leaves the region and is correctly rejected.','Improve both lower and upper bounds, validate continuous families and optimize directions/reports. Investigate global regions or counterexamples; numerical convergence and failure are not optimality or impossibility proofs.'),
    'R15':('independent_mixed_variable_and_midpoint_audits','Independent complex derivatives, modular matrices and 704 direct scalar source inequalities audit four mixed root/noise systems. Sixty-four mutations reject; six Lean lemmas prove noise scaling, midpoint budgets and scope controls. A singular Newton failure and an out-of-region trial remain preserved.','Formalize the full mixed-system contraction and analytic bridges; audit bounded-error inverse algorithms and source-constrained stability bounds, preserving exact scale, fixed-coordinate and region assumptions.'),
    'K04':('append_only_free_midpoint_noise_delta','All 117 branches and 448 preceding events are preserved. Five new events link four exact variable-noise pairs, independent audits, 64 adversaries, six Lean lemmas and ten recorded commands including one failed numerical search.','Continue evidence-backed discovery across the whole ACS program, preserve source versions and explicit open gates, and make no global completion or exhaustion claim.')}
prefix=str(OUT.relative_to(ROOT))+'/'
evidence=['Variable_Noise_Summary.json','Variable_Noise_Certificate.json','Independent_Variable_Noise_Audit.json','Shifted_Pair_Proposals.json','Adversary_Audit.json','Lean_Check.json','Development_Notes.json']
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_variable_noise_and_free_midpoint_audit')
        b['new_evidence']=[prefix+n for n in evidence]
        b['verification_routes']+=['Four mixed root/noise real interval contraction certificates','Independent complex constant-column and second-derivative audits','704 exact scalar source constraints and 1128 polynomial factorizations','64 adversarial mutations and exact fixed-report/Newton/scaling controls','Six Lean midpoint, scaling, budget and scope lemmas']
        b['shared_assumptions_and_scope']='Complete inherited two-field metadata class and finite 22-entry populations selected before root noise. Region Q_.01, root radius and feature units are unchanged. Four actual free-midpoint reports improve a conditional local ambiguity upper bound; global threshold sharpness and arbitrary-report decoding remain open. Both analytic routes share FLINT.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=448
for bid in ADVANCED:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'variable_noise_free_midpoint_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Moving feature midpoints tighten the local noise threshold — 14 September 2026

**Four exact variable-noise pairs improve the ambiguity upper endpoint to approximately 1.831989439894397e-10.** Under the unchanged radius-0.01 observation contract, the inherited uniform identification guarantee remains approximately 1.768500052962292e-10. Their ratio is about 1.03590013, leaving roughly a 3.6% gap. The convenient rational budget 1.832e-10 also supports the strongest pair.

The [proof and reproduction guide](../../../code/frontier_verification/VARIABLE_NOISE_README.md) derives the mixed root/noise equations, interval existence proofs, moving midpoint budgets and exact scope. The [preceding checkpoint](../2026-09-14-aggregate-weighted-feature-delta/README.md) established larger uniqueness regions, componentwise stability and the original two-sided noise bounds.

- [Results and continuation gates](Variable_Noise_Summary.json).
- Original [boundary-pair proposals](Boundary_Pair_Proposals.json) and [exploratory interval checks](Boundary_Pair_Checks.json), followed by [shifted proposals with accepted and rejected trials](Shifted_Pair_Proposals.json) and [exploratory checks](Shifted_Pair_Checks.json).
- [Four canonical variable-noise certificates](Variable_Noise_Certificate.json) and [independent complex/source/arithmetic audit](Independent_Variable_Noise_Audit.json).
- [Sixty-four adversarial mutations and exact controls](Adversary_Audit.json).
- [Six compiled Lean lemmas](Lean_Check.json) and [proof source/compiled artifact](Lean_Artifacts.zip).
- [Primary source acquisition](Source_Acquisition.json), [inherited primary sources](Primary_Sources.json), [runtime](Runtime.json) and [inherited inputs](Inherited_Inputs.json).
- [Ten command receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [preserved failure and rejected trial](Development_Notes.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [453-event append-only ledger](Branch_Events.jsonl), retaining all 448 earlier events byte for byte.

The complete inherited class has two discriminant-576 quartic fields, each with 22 positive source roots below 19.5. Source selection precedes independent root errors and preserves all entries. Root error remains r=U-1e-8<L, observations stay inside the same standard coordinate cube of radius 0.01, and the 22 finite feature definitions and absolute error units are unchanged. No raw roots, counts, infinite moment or unknown tail is added.

Fix both critical roots just inside their source bounds and all B roots as rationals. Solve for 21 A root corrections and alpha=tau/1e-10. The final Jacobian column is the exact constant -2e-10*v with zero variation. Real interval Jacobians at 768/1024 bits and independent complex second derivatives at 896/1152 bits prove self-mapping contraction on variable boxes of radius 1e-120. The tau radius is scaled by 1e-10. Modular nonsingularity and all 704 direct scalar source inequalities pass.

At each exact solution, Phi(A)-Phi(B)=2*tau*v. Its feature midpoint is a common report with each component error exactly tau. Every new midpoint differs certifiably from Phi(c); the strongest differs in component 0 by about -0.0048814. The preceding failures for fixed Phi(c) target pairs therefore do not exclude these constructions. Each fixed pair has a sharp budget tau, while the globally optimal restricted threshold remains open.

The corrected common-shift search accepts eight steps among nine trials. Its last full step has a smaller numerical tau but escapes the certified cube by about 1.4599e-6, so it is rejected. The smaller accepted step is fully certified with cube margin about 2.26229e-9. The first search version's numerically singular Newton failure, source and actual receipt are preserved; a separate v2 adds prediction and backtracking. Ten development commands contain nine successes and one failure.

Independent arithmetic performs 1128 polynomial factorizations and 1208 comparisons: 456 of 604 coefficients remain fixed and 148 ambiguous at each common report. The inherited lower guarantee still identifies the field and tracked vector under its stated conditions. An arbitrary-report decoder and global recovery theorem are not established.

Sixty-four adversaries test scale, mixed-variable dimensions, fixed coordinates, source and region constraints, interval evidence and midpoint claims. Six Lean lemmas prove the generic scaling, midpoint, budget and scope logic. The full analytic/interval/modular and field/spectral chain is not entirely formalized. Both analytic routes share FLINT; no runtime version changed and no new source roots were computed.

Next: source-constrained or subdivided lower bounds, improved upper constructions, validated parameter families, bounded-error inverse decoding and global region extensions or counterexamples. Natural operators, infinite arithmetic and real-part information, topology, physical acquisition and private-input gates remain active. No global completion is claimed.
''')
names=['dedekind_variable_noise_certificate.py','dedekind_variable_noise_audit.py','dedekind_variable_noise_adversary.py','check_variable_noise_lean.py','verify_aggregate_variable_noise_delta.py','VARIABLE_NOISE_README.md','proofs/VariableNoiseMidpoint.lean']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
    p=todo.pop()
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for mod in modules:
            d=CODE/(mod+'.py')
            if d.exists() and d not in seen:
                seen.add(d);todo.append(d)
                if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt');mathlib=ROOT.parent/'acs-research/lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/p,'external/'+p) for p in ['Mathlib/Algebra/Order/Group/Abs.lean','Mathlib/Analysis/Normed/Group/Basic.lean']]+[(mathlib/'LICENSE','external/mathlib-LICENSE')]
explorations=[(BASE/n,'exploration/'+n) for n in ['run_recorded.py','capture_sources.py','explore_boundary_pairs.py','check_boundary_pairs.py','explore_shifted_pairs.py','explore_shifted_pairs_v2.py','check_shifted_pairs.py']]
packaging=[(Path(__file__),'packaging/'+Path(__file__).name)]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'exploration_sources':{n:sha(p.read_bytes()) for p,n in explorations},'packaging_sources':{n:sha(p.read_bytes()) for p,n in packaging},'scope':'All seven new instruments, transitive local Python dependencies, five original numerical/check scripts including the failed and corrected search, runner/source capture, packager and pinned Mathlib references with license.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+explorations+external+packaging)
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. Preceding checkpoints are recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 moving midpoint and variable-noise delta](2026-09-14-aggregate-variable-noise-delta/README.md): four exact pairs tighten the local noise threshold bracket to about 3.6%.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-weighted-feature-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-variable-noise-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':10,'successes':9,'failures':1,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
