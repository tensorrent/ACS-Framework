"""Refine the unique maximizer using certified growth and derivative signs."""
import os,sys,json
from pathlib import Path
from fractions import Fraction as Q
root=Path(os.environ.get('ACS_SHEAR_ROOT',Path(__file__).resolve().parents[1]));sys.path.insert(0,str(root/'support'))
from frobenius_jost_v4 import determinant
from curvature_jost_v2 import determinant_kk
from flint import arb,ctx
ctx.prec=128
def b(q):return arb(q.numerator)/q.denominator
def iv(a,z):return arb(b((a+z)/2),b((z-a)/2))
k0=Q('0.4449180422');lo=Q('0.18970210046');hi=Q('0.18970210048');history=[]
while hi-lo>Q(1,10**25):
    m=(lo+hi)/2;d,_=determinant(b(k0),b(m/k0),n=900,bits=160)
    history.append({'growth':str(m),'D':str(d)})
    if d>0:hi=m
    elif d<0:lo=m
    else:raise RuntimeError('inconclusive fixed-k root sign')
upper=hi+Q(1,10**20)
df,fd=determinant(b(k0),b(upper/k0),n=900,bits=160)
_,dk,_,kd=determinant_kk(b(k0),b(upper),tail=24,steps=1200)
# Conservative rational lower bound supplied by the completed curvature cover.
mu=Q(18,100);convex=df-dk.abs_upper()**2/(2*b(mu));assert convex>0
left=Q('0.444918042172');right=Q('0.444918042175');signs=[]
for kv in [left,right]:
    d,d1,d2,detail=determinant_kk(b(kv),iv(lo,upper),tail=24,steps=1200)
    signs.append({'k':str(kv),'D_k':str(d1),'D_kk':str(d2),'details':detail})
assert arb(signs[0]['D_k'])<0 and arb(signs[1]['D_k'])>0
out={'status':'certified_given_uniqueness_certificate','unique_global_maximizer_k_interval':[str(left),str(right)],'k_decimal_interval':['0.444918042172','0.444918042175'],'global_growth_interval':[str(lo),str(upper)],'global_growth_decimal_enclosure':[str(b(lo)),str(b(upper))],'growth_fixed_k_root_bracket':[str(lo),str(hi)],'fixed_k':str(k0),'root_bisection':history,'curvature_lower_used':str(mu),'D_at_global_growth_upper':str(df),'D_k_at_center_upper':str(dk),'global_upper_convexity_margin':str(convex),'endpoint_derivative_signs':signs,'logic':'The previous convexity cover has D_kk>0. At any maximum, D_k=0. The signed endpoint derivative boxes hold for the entire certified growth interval, forcing its k into the stated strict interval.'}
(Path(os.environ['ACS_ATTEMPT_DIR'])/'result.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['root_bisection','endpoint_derivative_signs']},indent=2));print(json.dumps([{'k':r['k'],'D_k':r['D_k']} for r in signs]))
