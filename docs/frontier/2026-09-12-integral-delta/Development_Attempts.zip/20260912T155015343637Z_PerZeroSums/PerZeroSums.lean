import PerZeroError

open Real Filter Topology
open scoped BigOperators

namespace PerZeroSums

theorem half_le_arctan (x : ℝ) (hx : 0 ≤ x) (hx1 : x ≤ 1) : x / 2 ≤ arctan x := by
  have hsq : x ^ 2 ≤ 1 := by
    nlinarith [mul_nonneg hx (sub_nonneg.mpr hx1)]
  have h : x / 2 ≤ x / (1 + x ^ 2) := by
    apply (div_le_div_iff₀ (by norm_num) (by positivity)).2
    exact mul_le_mul_of_nonneg_left (by linarith : 1 + x ^ 2 ≤ 2) hx
  exact h.trans (PerZeroError.arctan_lower x hx)

theorem sum_upper {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (hx : ∀ k ∈ s, 0 ≤ x k) :
    2 * ∑ k ∈ s, arctan (x k) ≤ 2 * ∑ k ∈ s, x k := by
  exact mul_le_mul_of_nonneg_left
    (Finset.sum_le_sum fun k hk => PerZeroError.arctan_upper (x k) (hx k hk)) (by norm_num)

/-- Small total error forces every ratio into the same bounded interval. -/
theorem sum_lower_when_small {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (hx : ∀ k ∈ s, 0 ≤ x k) (hs : 2 * ∑ k ∈ s, arctan (x k) < π / 2) :
    (∑ k ∈ s, x k) ≤ 2 * ∑ k ∈ s, arctan (x k) := by
  calc
    _ ≤ ∑ k ∈ s, 2 * arctan (x k) := by
      apply Finset.sum_le_sum
      intro k hk
      have hsingle : arctan (x k) ≤ ∑ j ∈ s, arctan (x j) :=
        Finset.single_le_sum (fun j hj => arctan_nonneg.mpr (hx j hj)) hk
      have ha : arctan (x k) < arctan 1 := by rw [arctan_one]; linarith
      have hone : x k ≤ 1 := (arctan_strictMono.lt_iff_lt.mp ha).le
      linarith [half_le_arctan (x k) (hx k hk) hone]
    _ = _ := by rw [Finset.mul_sum]

/-- Cardinality may change arbitrarily. No sum/limit interchange is assumed. -/
theorem total_tendsto_iff {α ι : Type*} (l : Filter α)
    (s : α → Finset ι) (x : α → ι → ℝ) (hx : ∀ j k, k ∈ s j → 0 ≤ x j k) :
    Tendsto (fun j => 2 * ∑ k ∈ s j, arctan (x j k)) l (𝓝 0) ↔
      Tendsto (fun j => ∑ k ∈ s j, x j k) l (𝓝 0) := by
  constructor
  · intro h
    apply squeeze_zero' (Eventually.of_forall (fun j => Finset.sum_nonneg (hx j))) ?_ h
    filter_upwards [h.eventually (eventually_lt_nhds (by positivity : (0 : ℝ) < π / 2))] with j hj
    exact sum_lower_when_small (s j) (x j) (hx j) hj
  · intro h
    apply squeeze_zero (fun j => mul_nonneg (by norm_num)
      (Finset.sum_nonneg fun k hk => arctan_nonneg.mpr (hx j k hk)))
      (fun j => sum_upper (s j) (x j) (hx j))
    simpa using h.const_mul 2

end PerZeroSums
