"""Unpublished source-feasible critical-strip bootstrap; not a new published theorem."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,zipfile
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_audit import input_geometry,SPECS,jets
from dedekind_weighted_region_certificate import av,enc,dyadic_upper
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta/Signed_Corner_Certificate.json'
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta/Equal_Population_Inputs.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    cert=json.loads(ANCHOR.read_text())
    with zipfile.ZipFile(SOURCE) as z:data={n:json.loads(z.read(n)) for n in z.namelist()}
    c,L,U=input_geometry(data);r=U-F('1e-8');old=F(cert['corner_uniform_inverse_bound']);upper=F(cert['inherited_ambiguity_upper_endpoint']);difference_cap=2*upper*old
    a=F(data['E1_224.json']['positive_root_intervals'][1]['lo'])-r
    b=F(data['E2_224.json']['positive_root_intervals'][1]['hi'])+r
    assert a>b and a-b==2*(L-r)
    # For any common report with tau<=upper, old secant stability forces
    # A1-B1<=difference_cap. A1>=a and B1<=b imply these outer boxes.
    A=(a,b+difference_cap);B=(a-difference_cap,b);assert A[0]<=A[1] and B[0]<=B[1]
    lo,hi=B[0],A[1];assert c[1]-F(1,100)<lo<hi<c[1]+F(1,100)
    directions=[x['endpoint_direction'] for x in cert['uniform_curvature_checks'][0]['columns']];v=cert['critical_sign_vector']
    assert directions[1]==1 and directions[12]==0
    ref=[x+F(1,100)*s for x,s in zip(c,directions)];ref[1]=hi
    checks=[]
    for bits in [1024,1536]:
        ctx.prec=bits
        def inverse(y):
            J=arb_mat([[jets(spec,av(x))[1] for x in y] for spec in SPECS]);det=J.det();assert det>0 or det<0
            return J.inv(),det
        Y,d=inverse(ref);u12=sum((Y[12,k]*v[k] for k in range(22)),arb(0));assert u12<0
        corner=list(ref);corner[12]=c[12]-F(1,100);Z,dd=inverse(corner);assert (d>0 and dd>0) or (d<0 and dd<0)
        assert all((Z[1,k]>0 if v[k]>0 else Z[1,k]<0) for k in range(22))
        K=sum((abs(Z[1,k]) for k in range(22)),arb(0));ku=dyadic_upper(K,100);guarantee=(L-r)/ku
        assert F(cert['uniform_identification_strictly_below'])<guarantee<upper
        checks.append({'precision_bits':bits,'reference_u12':enc(u12),'reference_determinant':enc(d),'corner_determinant':enc(dd),
            'critical_strip_corner':list(map(str,corner)),'inverse_critical_row':[enc(Z[1,k]) for k in range(22)],'corner_norm':enc(K),'candidate_inverse_bound':str(ku),'candidate_bound_display':float(ku),
            'candidate_strict_lower_guarantee':str(guarantee),'candidate_guarantee_display':float(guarantee),'upper_to_candidate_ratio':str(upper/guarantee),'ratio_display':float(upper/guarantee),
            'relative_threshold_gap':str(upper/guarantee-1),'relative_threshold_gap_display':float(upper/guarantee-1)})
    return {'status':'exploration_passed_requires_complete_bootstrap_proof_and_independent_audit','source_sha256':sha(Path(__file__)),'inputs_sha256':{p.name:sha(p) for p in [ANCHOR,SOURCE,CODE/'dedekind_augmented_feature_audit.py',CODE/'dedekind_weighted_region_certificate.py']},
        'root_error_radius':str(r),'assumed_common_report_budget_at_most':str(upper),'inherited_secant_inverse_bound':str(old),'critical_difference_cap':str(difference_cap),
        'A_critical_source_lower':str(a),'B_critical_source_upper':str(b),'A_critical_outer_interval':list(map(str,A)),'B_critical_outer_interval':list(map(str,B)),
        'critical_secant_coordinate_interval':[str(lo),str(hi)],'critical_interval_offsets_from_c':[str(lo-c[1]),str(hi-c[1])],
        'critical_half_width_display':float((hi-lo)/2),'checks':checks,
        'candidate_argument':'If tau<=the existing actual ambiguity upper endpoint, the previously established uniform secant bound confines the critical root difference. Opposite source constraints then confine both critical roots to a tiny strip. The smaller product column-hull family inherits all global signs and nonsingularity; apply the same 21 replacements with the critical upper endpoint changed to the strip boundary, then recheck the coordinate-12 face sign by Cramer. The resulting corner could give a stronger lower guarantee. Since that guarantee is below the assumed upper endpoint, the bootstrap may be noncircular. This analytic implication and all endpoint/source constraints require dedicated independent audit, adversaries and proof before publication.',
        'scope':'Unpublished scratch only. Does not change checkpoint 31, which is frozen during recursive verification. No sharpness or new published guarantee claimed.'}
r=run();(BASE/'Critical_Strip_Exploration.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'critical_half_width_display':r['critical_half_width_display'],'checks':[{k:x[k] for k in ['precision_bits','candidate_bound_display','candidate_guarantee_display','relative_threshold_gap_display']} for x in r['checks']]},indent=2))
