"""Independent full-half-line Frobenius certificate, with an infinite tail.

No spatial cutoff, ODE time stepping, or imported previous integrator is used.
The polynomial-coefficient ODE and recurrence are derived in report.md.
"""
from flint import arb, acb, ctx

def box(r):
    return acb(arb(0,r),arb(0,r))

def tail_bound(k, eta, n, t1, t2):
    """Uniform diagonal-basis contraction for every recurrence index >=n.

    k, eta may be complex boxes, provided the stated inequalities hold.
    This permits Cauchy bounds for parameter derivatives in a second check.
    """
    k,eta=acb(k),acb(eta)
    A=1+acb(0,1)*eta; lam=1/A; gap=lam-acb('0.5')
    amin=A.abs_lower(); gmin=gap.abs_lower(); kl=k.real.lower()
    assert amin>1 and gmin>0 and kl>0
    lm=lam.abs_upper(); km=k.abs_upper(); one=(1+k).abs_upper()
    eps=(2/amin+one/2)/(n+1+kl)+km*(lm+arb('0.5'))/(amin*gmin*(n+1)*(n+1+kl))
    rho=max(lm,arb('0.5'))+eps
    assert rho<1
    C=(lm+arb('0.5'))*max(t1.abs_upper(),t2.abs_upper())
    ef=C*rho/(1-rho)
    ev=C*(n*rho/(1-rho)+rho/(1-rho)**2)
    return ef,ev,rho
