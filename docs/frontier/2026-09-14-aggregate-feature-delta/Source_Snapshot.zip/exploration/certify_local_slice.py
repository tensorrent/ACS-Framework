"""Arb self-map/contraction certificate for a finite Gaussian feature collision proposal."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as Q
import hashlib,json
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;PP=BASE/'Local_Slice_Proposal_v2.json'
SOURCE=BASE.parent/'aggregate-equal-population-audit/Equal_Population_Decoder.json'
p=json.loads(PP.read_text());data=json.loads(SOURCE.read_text());m=next(c for c in data['matching_cases'] if c['precision_bits']==224)
def enc(x):return {'mid':list(map(int,x.mid().man_exp())),'rad':list(map(int,x.rad().man_exp()))}
def av(x):x=Q(x);return arb(x.numerator)/arb(x.denominator)
assert p['common_rational_coordinates']==m['common_observation'] and p['critical_index']==1
c=list(map(Q,p['common_rational_coordinates']));eps=Q(p['critical_split_epsilon']);rho=Q(1,10**80);w=list(map(Q,p['corrections']));selected=p['selected_A_variable_indices']
assert len(selected)==len(set(selected))==len(w)==17 and 1 not in selected and all(0<=i<22 for i in selected)
r=Q(p['radius']);assert 0<r==Q(m['radius_upper'])-eps<Q(m['radius_lower'])
AC=list(c);BC=list(c);AC[1]+=eps;BC[1]-=eps
for j,i in enumerate(selected):AC[i]+=w[j]
A=[(x-rho,x+rho) if i in selected else (x,x) for i,x in enumerate(AC)];B=[(x,x) for x in BC]
endpoint_checks=[]
for label,boxes in [('A',A),('B',B)]:
    assert all(x[1]<y[0] for x,y in zip(boxes,boxes[1:]))
    for i,(lo,hi) in enumerate(boxes):
        source=list(map(Q,m['pairs'][i][label+'_interval']));margin=r-max(abs(x-y) for x in source for y in [lo,hi]);assert margin>=0
        endpoint_checks.append({'field':label,'index':i,'observed_box':[str(lo),str(hi)],'uniform_source_error_margin':str(margin)})
assert AC[1]-BC[1]==2*eps>0
def compute(bits):
    ctx.prec=bits;alpha=arb(1)/25;us=[arb(n).log() for n in p['centers']]
    def fun(x,u):return 2*(-alpha*x*x).exp()*(u*x).cos()
    def deriv(x,u):return 2*(-alpha*x*x).exp()*(-2*alpha*x*(u*x).cos()-u*(u*x).sin())
    f0=arb_mat([[sum((fun(av(x),u) for x in AC),arb(0))-sum((fun(av(x),u) for x in BC),arb(0))] for u in us])
    X=[av(AC[i])+arb(0,av(rho).upper()) for i in selected]
    J=arb_mat([[deriv(x,u) for x in X] for u in us]);R=arb_mat([[av(x) for x in row] for row in p['preconditioner']])
    assert R.nrows()==R.ncols()==17
    det=R.det();assert det>0 or det<0
    E=arb_mat([[1 if i==j else 0 for j in range(17)] for i in range(17)])-R*J;residual=R*f0
    rows=[]
    for i in range(17):
        q=sum((abs(E[i,j]) for j in range(17)),arb(0));bound=abs(residual[i,0])+av(rho)*q
        assert q<1 and bound<av(rho)
        rows.append({'index':i,'preconditioned_center_residual':enc(residual[i,0]),'derivative_error_row_sum':enc(q),'self_map_bound':enc(bound),'strict_self_map_margin':enc(av(rho)-bound)})
    return {'precision_bits':bits,'preconditioner_determinant':enc(det),'F_center':[enc(f0[i,0]) for i in range(17)],'rows':rows,'maximum_contraction_bound_display':max(float(sum((abs(E[i,j]) for j in range(17)),arb(0)).upper()) for i in range(17))}
checks=[compute(b) for b in [512,768]]
out={'status':'interval_contraction_certified_pending_independent_audit','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in [PP,SOURCE]},
     'contract':'Complete22entry positive source prefix through19.5 is selected before independent bounded coordinate errors; all entries and multiplicities remain. Only17finite Gaussian features with a=1/25 and the specified prime-power log centers are released. No moment, raw roots, counts or unknown-tail contribution is included.',
     'common_feature_centers':p['centers'],'radius':str(r),'point_list_ambiguity_lower':m['radius_lower'],'strict_radius_improvement_below_L':str(Q(m['radius_lower'])-r),
     'critical_split_epsilon':str(eps),'unknown_correction_box_radius':str(rho),'selected_A_variable_indices':selected,'uniform_coordinate_endpoint_checks':endpoint_checks,'interval_checks':checks,
     'theorem':'For the rational center w0 and rational preconditioner R, T(w)=w-R*F(w). Each derivative error row has sum below1 uniformly over the closed correction box, and each center residual plus rho times that sum is strictly belowrho. The box maps into itself and T contracts. Banach gives a unique fixed point in this slice. Certified nonzero detR implies F=0 there. Exact rational endpoint inequalities ensure every possible true source ordinate admits the resulting observation withinr. The two observations have identical finite Gaussian feature vectors and different critical coordinates.',
     'scope':'Two Arb precisions validate one self-map calculation; they are not independent implementations. A separate interval/formula audit, adversarial tests, proof-scope review and repository packaging are still required. This does not establish an optimal feature-only threshold, infinite-spectrum collision, or equality of moments/tail-corrected measurements.'}
(BASE/'Local_Slice_Contraction.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'strict_improvement':out['strict_radius_improvement_below_L'],'coordinate_checks':len(endpoint_checks),'contraction_bounds':[c['maximum_contraction_bound_display'] for c in checks]}))
