from pathlib import Path
import sys,time
sys.path.insert(0,str(Path(__file__).absolute().parents[3]/'acs-repo/code/frontier_verification'))
from dedekind_inputs import load_factors
from flint import acb,arb,ctx
from sympy import primerange
ctx.prec=160
repo=Path(__file__).absolute().parents[3]/'acs-repo'
factors,_=load_factors(repo/'docs/frontier/2026-09-13-dedekind-delta/Factor_Certificates.zip',repo/'docs/frontier/2026-09-13-lfunction-delta/Certificates.zip')
a=arb('1/100');u=arb(11).log()
pi=arb.pi();normal=1/(4*(pi*a).sqrt())
def g(x):return normal*((-(x-u)**2/(4*a)).exp()+(-(x+u)**2/(4*a)).exp())
g0=g(arb(0))
def integrand(x,_):
 if x.abs_upper()<arb('0.01'):
  bx=x*u/(2*a)
  numerator=-g0*((-x*x/(4*a)).expm1()*bx.cosh()+2*(bx/2).sinh()**2)
 else:numerator=g0-g(x)
 return numerator/(2*(x/2).sinh())
start=time.time()
cuts=['1e-20','0.01','0.1','0.5','1','2','3','4','5','6','8','12','20','40','80','180']
integ=sum((acb.integral(integrand,acb(x),acb(y),abs_tol=arb('1e-32'),rel_tol=arb('1e-32')) for x,y in zip(cuts,cuts[1:])),acb(0))
assert integ.is_finite()
gamma=-4*(arb.const_euler()+(8*pi).log())*g0+4*integ.real
pole=2*(a/4).exp()*(u/2).cosh();conductor=arb(125).log()*g0
prime=arb(0)
for p in primerange(2,10001):
 f=1 if p==5 or p%5==1 else 2 if p%5==4 else 4
 n=int(p)**f
 while n<=10000:
  term=2*(1 if p==5 else 4)*arb(int(p)).log()/arb(n).sqrt()*g(arb(n).log())
  if not term.is_finite(): print('BAD',p,n,a,u,normal,g(arb(n).log())); raise SystemExit(1)
  prime+=term
  n*=int(p)**f
zeros=arb(0)
for rows in factors.values():
 for row in rows:
  t=arb(row['lo']).union(arb(row['hi']))
  zeros+=2*(-a*t*t).exp()*(u*t).cos()
print({'seconds':time.time()-start,'zero':str(zeros),'pole':str(pole),'conductor':str(conductor),'gamma':str(gamma),'prime':str(prime),'residual':str(zeros-(pole+conductor+gamma-prime))})
