from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent
ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-uncertainty-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-coupled-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

names=['Ranges_Probe160.json','Ranges_160.json','Ranges_224.json']
archive('Ordinate_Audits.zip',[(BASE/n,n) for n in names])
(OUT/'Ordinate_Audit.json').write_bytes((BASE/'Ordinate_Audit.json').read_bytes())
audit=read(BASE/'Ordinate_Audit.json');grid=read(BASE/'Ranges_224.json')
assert audit['status']=='passed' and len(grid['cases'])==160
with zipfile.ZipFile(PRIOR/'Measurements.zip') as z:assert z.read('Measurements.json')==(BASE/'Measurements.json').read_bytes()
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)>=4
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
write('Ordinate_Summary.json',{'recorded_utc':now,'input_archive':'../2026-09-13-coupled-delta/Measurements.zip',
 'input_sha256':sha((BASE/'Measurements.json').read_bytes()),'target_count':91,'target_prime_power_limit':361,
 'generic_coefficient_support':604,'prime_cutoff':4096,'precision_bits':[160,224],'additional_radii':['5e-6','5e-5','5e-4','5e-3'],
 'cases':[{'additional_radius':c['additional_radius'],'height':c['settings']['top'],'method':c['method'],'policy':c['policy'],
   'unique_targets':c['unique_target_coefficients'],'unique_support':c['unique_support_coefficients'],'measurement_count':c['measurement_count'],
   'unresolved_targets':[d for d in c['domains'] if d['n']<=361 and len(d['candidates'])>1]} for c in grid['cases']],
 'audit':{k:audit[k] for k in ['exclusions_replayed','critical_point_strict_phase_brackets','precision_domain_comparisons','domain_inclusion_comparisons','probe_repeat_cases']},
 'scope':'Finite coefficient-box inference under declared loss of ordinate precision. Bounds are sufficient, not an optimal noise threshold; unresolved candidates do not establish joint feasibility or alternate fields.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':len(receipts),
 'successful_recorded_commands':sum(r['returncode']==0 for r in receipts.values()),
 'unsuccessful_recorded_commands':sum(r['returncode']!=0 for r in receipts.values()),
 'source_policy':'Previously dated checkpoints and all previously pinned instruments are unchanged. New instruments and their execution receipts are retained.',
 'initial_integrity_check':'The first retained-evidence verifier invocation wrote its result to scratch, so the final link check found the as-yet absent checkpoint Verification.json. The failure is retained in Verification_Bootstrap_Failure.json. Redirecting the unchanged verifier to the checkpoint output path resolves this packaging-order issue; no numerical result or certificate changed.',
 'precision_model':'Nominal extra displacement delta around certified intervals. Machine intervals round outward; range methods use their actual endpoints, derivative allowances use nominal delta with derivatives evaluated on outer boxes. Membership is fixed.',
 'scalar_range_scope':'Endpoint and critical-value sums enclose the marginal finite Gaussian range. They do not retain common-ordinate correlations between rows.',
 'higher_uncertainty_scope':'At delta 5e-3 the retained stationary rows identify 73 targets and leave 18 candidate domains unresolved. This exclusion fixed point is not a feasibility certificate.',
 'no_new_completeness_claim':'Existing finite root-count certificates and analytic tails are reused. No global RH/GRH, field identification, optimal precision threshold or research exhaustion is asserted.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Unchanged pinned runtime. FLINT/Arb certifies enclosures, exact Python integers replay exclusions, and mpmath independently checks selected extrema.'
write('Runtime.json',runtime)
sources=read(PRIOR/'Primary_Sources.json');sources['recorded_utc']=now
sources['scope']='Inherited analytic inputs retain the preceding primary-source mapping. The new Gaussian derivative, monotone phase, contraction, extrema and retained-constraint arguments are derived directly in ORDINATE_README.md; no additional source-dependent theorem is assumed.'
write('Primary_Sources.json',sources)
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Ordinate uncertainty delta 2026-09-13','recorded_utc':now,
 'baseline_branches':116,'branches_total':116,'new_branches':[],'advanced_existing_branches':['R12','R13','K04'],
 'replay_scope':'Four finite-sum bounds, five heights, four radii, two retention policies and two precisions; exact integer exclusion replay, strict turning-point phase brackets, independent 80-digit scalar extrema and three adversarial controls.',
 'next_priority':['R12/R13: retain common-ordinate correlations when combining rows; compare certified linear-combination bounds with sums of marginal ranges',
 'R12/R13: choose widths from declared uncertainty bounds and test the 18 remaining coefficient domains at delta 5e-3; distinguish exclusion limits from joint feasibility',
 'R13/R14: add measurements and linked-tail constraints to the certified height-220 relaxation ambiguity without local arithmetic seeds',
 'R14/P05: acquire or infer the original 48 unresolved square coefficients and distinguish residue-degree information from ramification',
 'R13/R07: specify statistical calibration independently of deterministic coefficient recovery',
 'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: retain coupled RG and geometric-topology gates',
 'K02/K05: private corpus and historical-run identities']})
updates={
 'R12':('per_ordinate_ranges_and_retained_cutoffs_certified',
   'Individual derivative, direct interval and stationary-point bounds recover all 91 targets at every tested height from 600 through 2000 with additional ordinate radius 5e-4. At 5e-3, retained stationary rows recover 73 and leave 18 explicit domains. Both precisions agree; the moment bound is recomputed on enlarged intervals.',
   'Exploit the common ordinate errors across Gaussian rows and choose widths using declared uncertainty. Preserve membership and distinguish sufficient noise bounds from optimal thresholds or spectra of perturbed fields.'),
 'R13':('noise_robust_coupled_inference_with_monotone_retention',
   'Retaining earlier measurements prevents loss of established exclusions. At height 2000 and radius 5e-4 it raises the old global method from 55 to 78 targets, while each sharper method gives 91. At radius 5e-3 stationary single-cutoff recovery gives 66, and retained-prefix recovery gives 73. All coefficient deletions receive exact integer replay and held-out arithmetic checks.',
   'Test common-error and linked-tail constraints, certified combinations and noise-aware widths. The 18 wider-radius survivors are not proved jointly feasible; extend or separate the relaxation before making nonidentifiability claims.'),
 'K04':('ongoing_delta_with_independent_ordinate_extrema_audits',
   f'Preserve 116 branches and the 360-event prefix, adding three events to reach 363. Retain 360 producer cases, {audit["exclusions_replayed"]} exact exclusion replays, {audit["critical_point_strict_phase_brackets"]} strict phase brackets and twelve independent 80-digit extrema checks, with three rejected logic errors.',
   'Continue append-only evidence-backed deltas and independent challenges across the full queue without global completion or exhaustion.')}
evidence={'R12':['Ordinate_Audits.zip','Ordinate_Audit.json','Ordinate_Summary.json'],
 'R13':['Ordinate_Audits.zip','Ordinate_Audit.json','Ordinate_Summary.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-uncertainty-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']]
        b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_ordinate_range_and_retention_audit')
        b['new_evidence']=[prefix+n for n in evidence[b['id']]]
        b['verification_routes']+=['Per-root derivative and direct interval finite-sum bounds','Complete monotone-phase critical-point enclosure with independent strict brackets',
           'Exact outward fixed-grid integer exclusion replay','Independent 80-digit scalar extrema','Retained-cutoff and uncertainty domain inclusion checks']
        if b['id'] in ['R12','R13']:
            b['shared_assumptions_and_scope']='Inherited field invariants, finite zero certificates, explicit formula and unconditional tails. Independent root-interval enlargement with fixed membership; no local arithmetic seeds. Marginal row ranges forget shared-error correlations. Finite exclusion survivors are not alternate fields or established feasible vectors.'
write('Research_Queue.json',q)
old=(PRIOR/'Branch_Events.jsonl').read_bytes();events=old;last=json.loads(old.splitlines()[-1])['event_sha256'];sequence=360
for bid in ['R12','R13','K04']:
    b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    event={'sequence':sequence,'utc':now,'release':q['release'],'kind':'ordinate_uncertainty_evidence_advanced','branch_id':bid,
       'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(event,sort_keys=True,separators=(',',':')).encode());event['event_sha256']=last
    events+=(json.dumps(event,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dedekind_ordinate_ranges.py','dedekind_ordinate_audit.py','verify_ordinate_delta.py','ORDINATE_README.md']
deps=['dedekind_coupled_recovery.py','dedekind_coupled_audit.py','verify_coupled_delta.py','source_requirements.txt','COUPLED_README.md','RECOVERY_README.md']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
 'scope':'New ordinate-uncertainty instruments; all earlier pinned source and dated evidence bytes preserved.'}
write('Source_Inventory.json',inventory)
entries=[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]
entries.extend((p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',Path(__file__).absolute()])
entries.extend((p,'retained_versions/'+p.name) for p in (BASE/'source_versions').glob('*.py'))
archive('Source_Snapshot.zip',entries)
files={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for name in new_names:
    path=CODE/name;raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
 'scope':'Manifest and verification result excluded to avoid self-reference; preceding checkpoint checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':len(q['branches']),'events':sequence,
 'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
