"""Rigorous complex disk enclosure for the inherited rectangular-barrier pole."""
import cmath,json
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp
from scipy.optimize import root
from flint import acb,arb,acb_series,ctx
mp.mp.dps=80
def Dmp(E):
    k=mp.sqrt(E);q=mp.sqrt(E-20)
    u=mp.sin(k)/k;v=mp.cos(k)
    U=mp.cos(q)*u+mp.sin(q)/q*v
    V=-q*mp.sin(q)*u+mp.cos(q)*v
    return V-1j*k*U
pole=mp.findroot(Dmp,(mp.mpc(6,-.01),mp.mpc(7,-.02)))
center_re=mp.nstr(pole.real,35);center_im=mp.nstr(pole.imag,35)
ctx.prec=180;ctx.cap=6
center=acb(arb(center_re),arb(center_im));r=arb('1e-30')
def Darb(E):
    k=E.sqrt();q=(E-20).sqrt()
    u=k.sin()/k;v=k.cos()
    U=q.cos()*u+q.sin()/q*v
    V=-q*q.sin()*u+q.cos()*v
    return V-acb(0,1)*k*U
jet=Darb(acb_series([center,1],prec=3));d0=jet[0];d1=jet[1]
domain=center+acb(arb(0,r),arb(0,r))
diskjet=Darb(acb_series([domain,1],prec=3));half_second=diskjet[2].abs_upper()
left=d0.abs_upper()+r*r*half_second
right=r*d1.abs_lower()
assert left<right
width_center=-2*center.imag
width=width_center+arb(0,2*r)
assert width>0
# Independent outgoing ODE shooting, with an intentionally displaced start.
def odeD(E):
    y=np.array([0j,1+0j])
    for lo,hi,V in [(0,1,0),(1,2,20)]:
        sol=solve_ivp(lambda x,z:[z[1],(V-E)*z[0]],[lo,hi],y,method='DOP853',rtol=2e-12,atol=1e-13)
        assert sol.success;y=sol.y[:,-1]
    return y[1]-1j*cmath.sqrt(E)*y[0]
def residual(x):
    z=odeD(complex(*x));return [z.real,z.imag]
fit=root(residual,[float(pole.real)*1.01,float(pole.imag)*1.1],tol=1e-10)
Eode=complex(*fit.x);error=abs(Eode-complex(pole))
assert error<2e-10
# Exact small determinant scaling leaves root error unchanged.
scaling=[{'epsilon':eps,'root_distance':2.,'residual_at_zero':2*eps} for eps in [1.,1e-10,1e-30]]
print(json.dumps({'branches':['N06','N07'],
 'model':'Half-line -u_second+V*u=E*u, u(0)=0; V=0 for 0<r<1, V=20 for 1<r<2, V=0 for r>2; outgoing u_prime=i sqrt(E) u at r=2. Dimensionless units hbar^2/(2mu)=1.',
 'analytic_determinant':'D(E)=V_b-i sqrt(E) U_b, obtained by exact two-region transfer; analytic on the certified disk with local square-root branches.',
 'certificate':{'center_real':center_re,'center_imag':center_im,'disk_radius':str(r),
   'center_residual_upper':str(d0.abs_upper()),'center_derivative_lower':str(d1.abs_lower()),
   'half_second_derivative_upper_on_enclosing_box':str(half_second),
   'Rouche_left':str(left),'Rouche_right':str(right),'strict_inequality':bool(left<right),
   'unique_root_count_in_disk':1,'width_enclosure':str(width),'working_bits':ctx.prec},
 'proof':'On |E-E0|=r the Taylor remainder is at most r^2 sup|D_second|/2. The strict inequality |D(E0)|+r^2 sup|D_second|/2 < r |D_prime(E0)| makes D and D_prime(E0)(E-E0) have the same one zero by Rouche. Arb interval arithmetic encloses every displayed bound, including the whole complex disk via a containing box.',
 'independent_ODE':{'pole_real':Eode.real,'pole_imag':Eode.imag,'distance_to_certified_center':error,
                     'scaled_residual':residual(fit.x)},
 'residual_counterfamily':{'D_epsilon':'epsilon*(E-2), evaluated at E0=0','rows':scaling,
   'consequence':'A small raw residual, or agreement at fixed ODE tolerances, alone cannot certify the imaginary part of an extremely narrow nuclear pole. A certified disk radius must be small compared with half the width.'},
 'boundary':'Rigorous closure of one inherited benchmark pole only. No nuclear potential or branch is identified, and no rigorous radius is claimed for the previous Woods-Saxon/Coulomb nuclear poles.'},indent=2))
