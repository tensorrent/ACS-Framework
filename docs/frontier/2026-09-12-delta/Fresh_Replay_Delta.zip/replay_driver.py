"""Replay frozen workstreams in a fresh extraction; append one receipt per invocation.

Install requirements.txt before running. Dependency wheels/runtime are not bundled.
Pass stream names to select a subset. With no arguments, use every registered stream.
"""
from pathlib import Path
import concurrent.futures, datetime, hashlib, json, os, shutil, subprocess, sys, time, zipfile

ROOT=Path(__file__).resolve().parent
REGISTRY={
 'arithmetic':[['run_checks.py'],['run_checks.py','audit_shear_evidence.py']],
 'foundations':[['run_checks.py'],['run_physical_review.py']],
 'physical':[['run_check.py',name] for name in ['flavor_boundaries','nuclear_identifiability','isospectral_overlap','outgoing_certificate','moment_capacitance']],
 'navier_stokes':[['energy_checks.py','--output','evidence/fresh_checks.json']],
 'projection':[['run_check.py','truncated_jacobi','formalization_static_audit']],
 'rg':[['derive_and_check.py'],['two_loop_yukawa_slice.py']],
}
# The shear certificate registry is written only after its adversarial review.
shear_registry=ROOT/'workstreams/shear/replay_commands.json'
if shear_registry.exists(): REGISTRY['shear']=json.loads(shear_registry.read_text())
chosen=sys.argv[1:] or list(REGISTRY)
assert len(chosen)==len(set(chosen)) and all(k in REGISTRY for k in chosen)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
DEST=ROOT/'fresh_replays'/stamp;DEST.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
(DEST/'replay_driver.py').write_bytes(Path(__file__).read_bytes())
source_hashes={}
staged=set(chosen)
if 'arithmetic' in staged: staged.add('shear')
if 'foundations' in staged: staged.add('physical')
with zipfile.ZipFile(DEST/'input.zip','x',zipfile.ZIP_DEFLATED) as z:
 for stream in sorted(staged):
  for p in sorted((ROOT/'workstreams'/stream).rglob('*')):
   if not p.is_file() or any(k in p.parts for k in ['.deps','deps','__pycache__']):continue
   rel=p.relative_to(ROOT/'workstreams').as_posix()
   z.write(p,rel)
   if p.suffix=='.py' or '/support/' in rel or '/sources/' in rel or p.name=='requirements.txt':
    source_hashes[rel]=sha(p.read_bytes())
with zipfile.ZipFile(DEST/'input.zip') as z:z.extractall(DEST/'extracted')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONHASHSEED='0')
started=time.monotonic()
def run(stream):
 folder=DEST/'extracted'/stream
 (folder/'outputs').mkdir(exist_ok=True)
 receipts=[]
 for idx,args in enumerate(REGISTRY[stream]):
  t=time.monotonic();command=[sys.executable,*args]
  try:
   proc=subprocess.run(command,cwd=folder,env=env,capture_output=True,timeout=1800)
   status='passed' if proc.returncode==0 else 'failed';stdout,stderr=proc.stdout,proc.stderr;rc=proc.returncode
  except subprocess.TimeoutExpired as e:
   status='timeout';stdout,stderr=e.stdout or b'',e.stderr or b'';rc=None
  for label,data in [('stdout',stdout),('stderr',stderr)]:
   (DEST/f'{stream}_{idx}_{label}.log').write_bytes(data)
  rec={'stream':stream,'command':command,'status':status,'returncode':rc,
       'elapsed_seconds':time.monotonic()-t,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
  receipts.append(rec);print(json.dumps(rec),flush=True)
 return receipts
with concurrent.futures.ThreadPoolExecutor(max_workers=min(6,len(chosen))) as pool:
 results=[r for group in pool.map(run,chosen) for r in group]
import importlib.metadata as md
versions={}
for p in ['numpy','scipy','sympy','mpmath','python-flint']:
 try:versions[p]=md.version(p)
 except md.PackageNotFoundError:versions[p]='not found'
receipt={'id':stamp,'fresh_extraction':True,'chosen_streams':chosen,'all_passed':all(r['status']=='passed' for r in results),
 'elapsed_seconds':time.monotonic()-started,'commands':results,'input_sha256':sha((DEST/'input.zip').read_bytes()),
 'source_input_sha256':source_hashes,'python':sys.version,'dependencies':versions,
 'driver_sha256':sha((DEST/'replay_driver.py').read_bytes()),
 'scope':'A fresh replay of the selected programs, not an independent derivation or a theorem-kernel verification.'}
(DEST/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (ROOT/'Replay_Events.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
print(json.dumps({'receipt':str(DEST/'receipt.json'),'all_passed':receipt['all_passed'],'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
sys.exit(0 if receipt['all_passed'] else 1)
