"""Arb enclosure of the tanh half-line Jost determinant.

Real Taylor integral remainders are bounded by interval jets over each entire
step. A Gronwall enclosure bounds the unknown solution in those jets. Infinite
tail error is included using the rescaled Jost Volterra equation. No floating
point ODE solver, cutoff without error, or tolerance-as-proof is used.
"""
from flint import arb,acb,acb_series,ctx

def box(r):return acb(arb(0,r),arb(0,r))
def Wseries(y,k,eta,N):
    p=acb_series([acb(y),1],prec=N+1);e=(2*p).exp();u=(e-1)/(e+1)
    return -2*u*(1-u*u)/(u-acb(0,eta))
def jet(W,k,f,v,N):
    fs=[acb(f)];vs=[acb(v)]
    for j in range(N):
        fs.append(vs[j]/(j+1))
        vs.append((sum((W[l]*fs[j-l] for l in range(j+1)),acb(0))-2*k*vs[j])/(j+1))
    return fs,vs
def horner(cs,h):
    z=acb(0)
    for c in reversed(cs):z=z*h+c
    return z
def determinant(k,eta,steps=240,tail=12,order=16,bits=96):
    ctx.prec=bits;ctx.cap=order+2;k=arb(k);eta=arb(eta);h=arb(tail)/steps
    assert k>0 and eta>0
    # A_tail <= 4 exp(-2 tail); Gronwall for the Volterra kernel <=1/(2k).
    at=4*arb(-2*tail).exp();bound=(at/(2*k)).exp()
    f=1+box(bound-1);v=box(at*bound)
    for step in range(steps):
        y=-arb(tail)+step*h;yb=y+arb(h/2,h/2)
        W=Wseries(y,k,eta,order);Wr=Wseries(yb,k,eta,order)
        L=max(arb(1),Wr[0].abs_upper()+2*k.abs_upper())
        B=(h*L).exp();rf,rv=jet(Wr,k,box(B),box(B),order)
        remf=box(rf[order].abs_upper()*h**order);remv=box(rv[order].abs_upper()*h**order)
        a,b=jet(W,k,1,0,order-1);c,d=jet(W,k,0,1,order-1)
        m00=horner(a,h)+remf;m10=horner(b,h)+remv
        m01=horner(c,h)+remf;m11=horner(d,h)+remv
        f,v=m00*f+m01*v,m10*f+m11*v
    # At y=0, reflection-conjugation matching is Re(psi' conjugate(psi))=0.
    D=(k*f*f.conjugate()+v*f.conjugate()).real
    return D,{'f':str(f),'v':str(v),'tail_integral_upper':str(at),'tail_f_error':str(bound-1),'steps':steps,'order':order,'bits':bits}
