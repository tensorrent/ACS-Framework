from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,platform,subprocess,sys,zipfile
import flint,mpmath,sympy,numpy,scipy,pytest
BASE=Path(__file__).absolute().parent
ROOT=BASE.parents[1]/'acs-repo'
CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-recovery-delta'
PRIOR=ROOT/'docs/frontier/2026-09-13-explicit-delta'
OUT.mkdir(exist_ok=True)
now=datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):
 (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for path,arcname in entries:z.write(path,arcname)
def members(names):return [(BASE/n,n) for n in names]
archive('Certificates.zip',members(['character-2.json','character-3.json','character-4.json','riemann-160.json']))
archive('Replays.zip',members(['replay-2.json','replay-3.json','replay-4.json','riemann-224.json']))
archive('Recovery_Audits.zip',members(['Recovery_Inputs.json','Recovery_160.json','Recovery_224.json']))
archive('Contour_Development.zip',members(['count220-2.json','count220-3.json','count220-4.json','folded220-2.json','partitioned2000-2.json']))
for name in ['Cross_Method.json','Local_Identifiability.json']:(OUT/name).write_bytes((BASE/name).read_bytes())
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==23
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/file,name+'/'+file) for name in receipts for file in ['receipt.json','stdout.txt','stderr.txt']])
low=read(BASE/'Recovery_160.json');high=read(BASE/'Recovery_224.json');inputs=read(BASE/'Recovery_Inputs.json');cross=read(BASE/'Cross_Method.json');local=read(BASE/'Local_Identifiability.json')
write('Recovery_Summary.json',{'recorded_utc':now,'counts':inputs['counts'],'total_positive_roots':7602,'prefix_220':inputs['prefix_checks'],
 'target_count':91,'prime_power_limit':361,'generic_prime_powers_through_4096':604,
 'height_comparison':[{'height':int(T),'direct_unique':v['direct_unique'],'local_unique':v['local_unique']} for T,v in low['inferences_by_height'].items()],
 'final_targets':[{'n':r['n'],'prime':r['prime'],'power':r['power'],'direct_candidates':r['candidates'],'denominator':r['denominator'],'estimate':r['estimate'],
 'local_candidates':next(v['candidates'] for p in low['inferences_by_height']['2000']['models'] for v in p['powers'] if v['n']==r['n'])} for r in high['cases']],
 'unresolved_local_factors':48,'next_distinguishing_square_range':local['range_of_next_powers'],'mutation_exclusion_counts':cross['mutation_exclusion_counts'],
 'cases_160':455,'cases_224':91,'independent_final_targets':91,'scope':'Finite resolution and conditional coefficient recovery; field invariants are supplied and local factors can remain ambiguous.'})
write('Development_Notes.json',{'scope':'Recorded mathematical commands and preserved development probes; ordinary file reads and packaging operations are not research experiments.',
 'controlled_stops':read(BASE/'development/Controlled_Stops.json'),
 'unsuccessful_recorded_attempts':{k:v['returncode'] for k,v in receipts.items() if v['returncode']!=0},
 'corrections':['The first retained-evidence verifier used the human-readable broad estimate strings to reproduce candidates. Arb rounds these strings outward; three lower-height cases gained extra candidates. The corrected verifier reconstructs the tighter enclosure from recorded pole/gamma/zero terms and explicit error allowances. No recovery output or producer computation changed.',
 'Unseeded wide interval evaluations at height 2000 were stopped after a 64-segment seeded folded contour succeeded. All four stopped processes were task-owned and their receipts ended with SIGTERM.',
 'The initial held-out factor_list(expression, modulus=p) route failed when sorting FLINT modular coefficients. Poly(..., modulus=p).factor_list() avoids that expression-sort conversion and factors are multiplied back.',
 'The 224-bit Riemann replay uses 90-digit mpmath values because the 60-digit comparison in the 160-bit producer would be too coarse for a new 224-bit root enclosure.',
 'The float64 resolution probe is a planning experiment only; all coefficient claims use interval arithmetic. Preliminary budget counts differ from realized singleton counts and are not guarantees.',
 'A preparatory git rev-parse was issued outside the checkout, returned not-a-repository, and was corrected by supplying the checkout cwd. It is not one of the recorded mathematical commands.'],
 'noncircularity':'Decoder output hashes predate polynomial validation; the decoder uses no actual nuisance coefficients or prime partial sum in its moment bound.',
 'inconclusive_control':'Omitting the discriminant term has zero exclusions on this width grid; all 455 cases remain inconclusive.'})
write('Runtime.json',{'recorded_utc':now,'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
 'python_flint':flint.__version__,'flint':flint.__FLINT_VERSION__,'mpmath':mpmath.__version__,'sympy':sympy.__version__,'numpy':numpy.__version__,'scipy':scipy.__version__,'pytest':pytest.__version__,
 'requirements':'code/frontier_verification/source_requirements.txt'})
write('Primary_Sources.json',{'recorded_utc':now,'sources':[
 {'url':'https://dlmf.nist.gov/25.15','locator':'25.15.1, 25.15.3, 25.15.5, 25.15.7-9','use':'Dirichlet series, independent Hurwitz representation, primitive functional equation, trivial zeros and nonvanishing at 1.'},
 {'url':'https://python-flint.readthedocs.io/en/latest/acb.html#flint.acb.lgamma','locator':'acb.lgamma','use':'Analytic log-gamma differs from the principal logarithm of the gamma value; the contour needs its continuous argument lift.'},
 {'url':'https://www.jmilne.org/math/CourseNotes/ANT.pdf','locator':'Theorems 3.34 and 3.35, printed pages 59-60; PDF pages 60-61','use':'Degree sum and the discriminant criterion for ramification. The local-model enumeration uses these general constraints, not the specific splitting pattern.'},
 {'url':'https://arxiv.org/pdf/1305.0035','locator':'Section 2, equations (1)-(2), page 3','use':'Inherited Weil-Poitou identity; use and admissibility are derived in the prior checkpoint.'},
 {'url':'https://arxiv.org/pdf/1407.1375','locator':'Section 2, equations (2.1)-(2.7), page 4','use':'Inherited unconditional Euler/Hadamard logarithmic-derivative premise at s=2; later GRH-dependent estimates are not used.'}],
 'scope':'Primary documents are linked, not redistributed. New bounds and finite inference arguments are stated in RECOVERY_README.md.'})
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Finite coefficient-recovery delta 2026-09-13','recorded_utc':now,
 'baseline_branches':115,'branches_total':116,'new_branches':['R14'],'advanced_existing_branches':['P05','R12','R13','K04'],
 'replay_scope':'7602 finite roots through 2000, all-sign/count higher-precision replays, 455 recovery cases, 91 final higher-precision and independent numeric cases, held-out polynomial arithmetic, mutation and local-identifiability audits.',
 'next_priority':['R13/P05: use coupled interval constraints and already certified neighbor coefficients; test target/width/height/precision budgets without the local-model inference',
 'R14: distinguish the 48 remaining local factors at square powers 529..128881; separate residue degrees from non-identifiable ramification assignments',
 'R12: adapt root precision and certified height to the next target band; preserve finite and unconditional tail scopes',
 'R13/R07: declare statistical calibration separately from deterministic explicit-formula identities',
 'R04/R05/R06/R08/R10: natural-operator and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: physical RG and geometric topology gates remain as recorded',
 'K02/K05: private corpus and historical run identities']})
results={
 'P05':('finite_prime_power_coefficients_recovered_without_splitting_oracle','For the supplied quartic field invariants, finite zeros determine 89 of 91 coefficients through 361 directly and all 91 after general degree-four local constraints. Frozen candidates agree with separate polynomial factorizations.','Generalize or couple coefficient constraints under declared field invariants; do not infer unknown field identity, natural operators or physical interpretation from this finite recovery.'),
 'R12':('extended_finite_certificates_and_recovery_error_budgets_verified','All four factors are complete through height 2000 with 7602 separated positive roots; 528 old intervals and rounded rows agree. Every Dirichlet endpoint/count and every Riemann interval is replayed at higher precision. Unknown-zero bounds allow off-line zeros and use no arithmetic partial sum.','Choose further height and root precision from target-specific error budgets. The fixed-height narrow-width limit remains uncontrolled; finite certificates do not establish a global zero theorem.'),
 'R13':('noncircular_finite_coefficient_recovery_with_two_inference_stages','Direct singleton counts rise from 46 at height 220 to 89 at height 2000; general local constraints give 56 and 91 respectively. All 91 final estimates have independent 70-digit checks. Six deliberate error types cause false exclusions; the discriminant omission remains inconclusive on this grid.','Test coupled spectral constraints, sharper justified nuisance bounds and extended target bands. Separate statistical calibration and operator identification, and carry local-factor ambiguities into R14.'),
 'K04':('ongoing_delta_with_recovery_and_identifiability_evidence','The unchanged 350-event prefix extends to 355 events. All 115 prior branches remain, with R14 added for the demonstrated local-identification ambiguity. Preserve 23 receipts including five unsuccessful attempts, source versions and exact continuation gates.','Continue append-only evidence-backed deltas and independent challenges. No global completion or exhaustion claim.')}
evidence={
 'P05':['Recovery_Audits.zip','Cross_Method.json','Primary_Sources.json'],
 'R12':['Certificates.zip','Replays.zip','Recovery_Audits.zip','Recovery_Summary.json'],
 'R13':['Recovery_Audits.zip','Cross_Method.json','Local_Identifiability.json','Recovery_Summary.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-recovery-delta/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[]
 b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in results:
  status,result,gate=results[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_finite_recovery_and_identifiability_audit')
  b['new_evidence']=[prefix+n for n in evidence[b['id']]]
  b['verification_routes']+=['Folded contour with analytic vertical lifts and higher-precision partitions','All-root endpoint replay and selected independent Hurwitz roots','Universal nuisance bounds without arithmetic feedback','Frozen polynomial validation and all-final-target mpmath recomputation','Independent local compositions and explicit coefficient-prefix ambiguities']
  if b['id'] in ['R12','R13']:b['shared_assumptions_and_scope']='Specified quartic field invariants, inherited analytic explicit formula, finite interval certificates and unconditional omitted-zero bounds. Interval methods share FLINT/Arb; mpmath verifies numerical values. No global GRH or natural-operator identification. Finite coefficients need not identify full local factors.'
new={'id':'R14','question':'Which local arithmetic data are identifiable from a finite recovered prime-power coefficient prefix, and which require new observations or non-Euler information?',
 'current_status':'finite_local_ambiguity_and_generic_ramification_obstruction_identified','assessment_this_pass':'new_evidence_backed_branch',
 'related_branches':['R13','R12','P05','R10'],
 'latest_scoped_result':'All 91 coefficients through 361 are identified under the stated model, but 48 of 72 local factors still admit residue-degree partitions (2,2) or (4). Their first distinguishing powers are squares 529..128881. Four degree-four power coefficients determine residue-degree multiplicities, while distinct ramification assignments can share the entire Euler coefficient sequence.',
 'continuation_condition':'Acquire or infer the distinguishing square coefficients with certified resolution; separately characterize information beyond Euler factors needed to identify ramification assignments. Do not equate target-coefficient recovery with full local or field identification.',
 'verification_routes':['Independent ordered-composition enumeration','Exact divisor-sum inversion for residue degrees','Period-12 coefficient grouping and explicit equal-Euler-factor ramification pair'],
 'shared_assumptions_and_scope':'General degree-four local constraints. The ramification ambiguity is a generic algebraic obstruction, not a claim that both models occur at prime 5 of Q(zeta_5).',
 'prior_delta_evidence':[],'new_evidence':[prefix+'Local_Identifiability.json',prefix+'Recovery_Audits.zip',prefix+'Primary_Sources.json']}
q['branches'].append(new);write('Research_Queue.json',q)
old=(PRIOR/'Branch_Events.jsonl').read_bytes();events=old;last=json.loads(old.splitlines()[-1])['event_sha256'];seq=350
for bid in ['P05','R12','R13','K04','R14']:
 b=next(x for x in q['branches'] if x['id']==bid);seq+=1
 e={'sequence':seq,'utc':now,'release':q['release'],'kind':'local_identifiability_branch_added' if bid=='R14' else 'finite_recovery_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dirichlet_strip_certificate.py','dirichlet_folded_count.py','dirichlet_extended_certificate.py','dirichlet_strip_replay.py','riemann_recovery_certificate.py','riemann_recovery_replay.py','dedekind_recovery_inputs.py','dedekind_coefficient_recovery.py','dedekind_recovery_audit.py','dedekind_local_identifiability.py','verify_recovery_delta.py','RECOVERY_README.md']
dep_names=['lfunction_zero_certificate.py','dedekind_inputs.py','verify_explicit_delta.py','source_requirements.txt']
inv={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in dep_names},
 'scope':'New recovery/certification instruments and unchanged pinned dependencies; development snapshots preserve superseded prototypes.'}
write('Source_Inventory.json',inv)
entries=[]
for kind in ['instruments','dependencies']:
 entries.extend((ROOT/p,kind+'/'+p) for p in inv[kind])
entries.extend((p,'development/'+p.name) for p in sorted((BASE/'development').iterdir()) if p.is_file())
entries.extend((p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',Path(__file__).absolute()])
archive('Source_Snapshot.zip',entries)
files={}
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for n in new_names:
 p=CODE/n;raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inv['baseline_commit'],'files':files,'scope':'Verification.json and the manifest itself excluded to avoid self-reference; prior checkpoints verified recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'successes':sum(r['returncode']==0 for r in receipts.values()),'branches':len(q['branches']),'events':seq,'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
