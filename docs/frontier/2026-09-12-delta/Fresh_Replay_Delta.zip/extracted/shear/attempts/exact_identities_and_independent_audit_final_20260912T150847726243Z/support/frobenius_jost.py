"""Independent full-half-line Frobenius certificate, with an infinite tail.

No spatial cutoff, ODE time stepping, or imported previous integrator is used.
The polynomial-coefficient ODE and recurrence are derived in report.md.
"""
from flint import arb, acb, ctx

def box(r):
    return acb(arb(0,r),arb(0,r))

def tail_bound(k, eta, n, t1, t2):
    """Uniform diagonal-basis contraction for every recurrence index >=n.

    k, eta may be complex boxes, provided the stated inequalities hold.
    This permits Cauchy bounds for parameter derivatives in a second check.
    """
    k,eta=acb(k),acb(eta)
    A=1+acb(0,1)*eta; lam=1/A; gap=lam-acb('0.5')
    amin=A.abs_lower(); gmin=gap.abs_lower(); kl=k.real.lower()
    assert amin>1 and gmin>0 and kl>0
    lm=lam.abs_upper(); km=k.abs_upper(); one=(1+k).abs_upper()
    eps=(2/amin+one/2)/(n+1+kl)+km*(lm+arb('0.5'))/(amin*gmin*(n+1)*(n+1+kl))
    rho=lm+eps
    assert rho<1
    C=(lm+arb('0.5'))*max(t1.abs_upper(),t2.abs_upper())
    ef=C*rho/(1-rho)
    ev=C*(n*rho/(1-rho)+rho/(1-rho)**2)
    return ef,ev,rho

def solution(k,eta,n=600,bits=128):
    ctx.prec=bits;k=acb(k);eta=acb(eta)
    A=1+acb(0,1)*eta;lam=1/A;gap=lam-acb('0.5')
    t1=1/gap;t2=-t1;f=acb(1);v=acb(0)
    for j in range(n):
        den=j+1+k
        e1=-2/(A*den)-k*lam/(A*(j+1)*den*gap)
        e2=(1+k)/(2*den)-k/(2*A*(j+1)*den*gap)
        d=e1*t1+e2*t2
        t1,t2=lam*t1+d,t2/2-d
        b=lam*t1+t2/2
        f+=b;v+=(j+1)*b
    ef,ev,rho=tail_bound(k,eta,n,t1,t2)
    return f+box(ef),v+box(ev),{'terms':n,'bits':bits,'rho':str(rho),'f_tail':str(ef),'v_tail':str(ev),'f_partial':str(f),'v_partial':str(v)}

def determinant(k,eta,n=600,bits=128):
    f,v,details=solution(k,eta,n,bits)
    D=(acb(k)*f*f.conjugate()+v*f.conjugate()).real
    return D,details
