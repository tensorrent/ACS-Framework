from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-source-constrained-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_source_constrained_delta import summarize,ADVANCED,FAILURES,HASH_LIMITATIONS
import dedekind_source_constrained_audit as audit

OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def archive(n,entries):
    with zipfile.ZipFile(OUT/n,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,name in entries:z.write(p,name)
    assert (OUT/n).stat().st_size<100*1024**2

documents=['Critical_Strip_Exploration.json','Independent_Critical_Strip_Audit.json','Corner_Pair_Diagnostic.json','Complementary_Pair_Proposals.json','Complementary_Pair_Checks.json',
    'Source_Strip_Certificate.json','Mixed_Noise_Certificate.json','Independent_Source_Constrained_Audit.json','Adversary_Audit.json','Lean_Check.json','Source_Acquisition.json','Proof_Audit.md']
for n in documents:(OUT/n).write_bytes((BASE/n).read_bytes())
reports=[read(BASE/n) for n in ['Source_Strip_Certificate.json','Mixed_Noise_Certificate.json','Independent_Source_Constrained_Audit.json','Adversary_Audit.json','Lean_Check.json','Corner_Pair_Diagnostic.json']]
summary=summarize(*reports)
write('Source_Constrained_Summary.json',{'recorded_utc':now,'result':'A source-critical strip bootstrap strengthens the uniform local lower guarantee, while two mixed A/B pairs improve the actual ambiguity upper endpoint. Their exact ratio is approximately 1.0064543677534608.',
    'derived_results':summary,'unchanged_contract':reports[0]['contract'],
    'lower_argument':'Any common report below the inherited budget cap has a bounded critical root difference. Opposite source bounds then force both critical roots into a narrow strip. The restricted convex column family inherits all global signs; a newly checked coordinate 12 face sign gives its corner constant. The new lower budget is below the original cap, making the exclusion noncircular under the original observation contract.',
    'upper_argument':'For each noncritical coordinate, pin one observation inside its selected cube endpoint and solve the other A or B root, plus scaled noise. Explicit signs, side-specific correction boxes and direct source inequalities certify two strict self-mapping contractions. Exact feature midpoints make the pairs ambiguous at their positive tau.',
    'independence':'Real-polynomial Cramer ratios audit the lower corner; complex scalar derivatives independently audit the real interval mixed systems. All 352 scalar source inequalities and 1128 polynomial factorizations are rebuilt. Both numerical routes share FLINT and inherited source/classification premises.',
    'formal_scope':'Seven generic Lean lemmas prove necessary/sufficient source bounds, strip and segment inclusions, common-budget caps, noncircular exclusion and the actual free-A/free-B derivative rule. Full concrete analytic assembly remains partly written or computational.',
    'negative_evidence':'The original all-free-A near-corner proposal fails a region/source assertion. A separate diagnostic proves all three numerical/source-center checks pass while each leaves the coordinate cube. These are rejected trials, not ambiguity endpoints or impossibility results.',
    'open_gates':['Tighter source-feasible thresholds and actual pairs','Validated parameter families','Arbitrary-report bounded-error inverse-set decoding','Wider/global regions and counterexamples','Complete analytic formalization','All natural operator, infinite arithmetic, real-part, topology, physical acquisition and private-input branches remain active']})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==12 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
assert sorted(n for n,r in receipts.items() if not r['input_sources_sha256'])==HASH_LIMITATIONS
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean']]+[(CODE/'proofs/SourceConstrainedNoise.lean','SourceConstrainedNoise.lean')])
write('Development_Notes.json',{'recorded_commands':12,'successful_commands':11,'failed_commands':1,
    'failures':[{'receipt':'corner-pair-exploration','result':'The original naive near-corner search asserts source and cube feasibility; it fails before writing a proposal JSON. Separate v2 records all three outcomes. They converge and pass source-center checks, but leave Q by approximately0.000287–0.000288. Their smaller numerical tau values are rejected.'}],
    'receipt_hash_limitations':[{'receipt':'corner-pair-diagnostic','result':'The original runner hashes relative script arguments from its launch cwd, while the child uses an explicit repository cwd. This launch left its automatic source-hash map empty. The actual receipt is retained unchanged. The diagnostic JSON records the exact script hash; Source_Snapshot.zip preserves the version and the full verifier replays its output byte for byte.'}],
    'source_policy':'All executed scientific sources and reports remain immutable; corrections use separate versions. Four successful exploratory calculations, a successful rejection diagnostic and one failed naive search precede six successful canonical/source/formal commands. The final recursive verifier has a separate external receipt and supplies exact stdout bytes to Verification.json.',
    'critical_margin':'The new exact pairs fix epsilon=1e-8+1e-24, reducing the earlier safety increment without changing r or assigning any uncertainty to fixed critical coordinates. Direct source inequalities certify this choice.',
    'runtime':'No package acquisition, runtime version change or new source roots.',
    'audit_scope':'The written Proof_Audit.md is an implementing-investigator audit, not a separate agent or human review. Numerical methods differ while sharing FLINT and inherited premises. Seven generic Lean lemmas compile; the full concrete theorem remains partly written.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned numerical and Lean/mathlib runtime. Seven new source/strip/conditional-budget/mixed-derivative lemmas compile. No acquisition.')
for key,pkg in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(pkg)
write('Runtime.json',runtime)
paths=[ROOT/p for p in [audit.PRIOR,audit.ANCHOR,audit.REGION,audit.UPPER,audit.SOURCE+'/Equal_Population_Inputs.zip',audit.SOURCE+'/Equal_Population_Decoder.json',audit.CLASS,audit.ARITH]]+[PRIOR/n for n in ['Verification.json','Research_Queue.json','Branch_Events.jsonl']]+[CODE/'verify_aggregate_signed_corner_delta.py']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},
    'scope':'Source selection, field classification, root-error radius, coordinate cube, feature units and prior full-family secant theorem are inherited unchanged and recursively verified. A conditional source-strip deduction strengthens the lower guarantee; new mixed pairs improve the upper endpoint.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',ROOT/'docs/frontier/2026-09-14-aggregate-variable-noise-delta/Primary_Sources.json']},'new_source_record':'Source_Acquisition.json',
    'scope':'Current primary Mathlib derivative-addition/subtraction documentation was retrieved. Three pinned derivative/interval sources match Git objects and are archived with license. Source endpoint and budget-bootstrap implications are explicitly derived and compiled in generic Lean form.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Source-critical strip and mixed A/B noise delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=ADVANCED,
    replay_scope='Six original scripts including a failed naive search and diagnostic region violations; conditional strip lower proof; two mixed A/B interval constructions; independent Cramer/complex/direct-source/arithmetic audits; 46 mutations, five exact controls and seven Lean lemmas. One original receipt hash-scanning limitation remains explicit.',
    next_priority=['R12/R13/R14: tighter source-feasible thresholds, validated families and arbitrary-report inverse-set decoding','R15: full analytic formalization and larger/global region counterexamples','R04/R05/R06/R08/R10: natural operator and infinite arithmetic/real-part bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
    'R12':('source_constraints_strengthen_original_contract_guarantee','A common-report budget cap and opposite source bounds force critical roots into a narrow strip. A noncircular conditional secant argument increases the original-contract strict guarantee to approximately 1.8196470598929473e-10.','Refine source-feasible constraints and implement bounded-error inverse sets for arbitrary reports; connect exact feature units to physical acquisition without changing source selection or tail contracts.'),
    'R13':('coefficient_identification_range_and_ambiguity_bracket_improved','The stronger lower budget preserves field identity and the tracked 604-column vector. Two newly certified mixed A/B common reports retain 456 fixed and 148 ambiguous domains, checked by1128 factorizations and 1208 comparisons.','Extend robust coefficient domains, metadata classes and arbitrary-report decoding; finite tracked-vector recovery is not full infinite arithmetic recovery.'),
    'R14':('source_strip_and_mixed_pairs_reduce_threshold_gap','The conditional critical-strip inverse constant is approximately 54.955712129078016. Two mixed-coordinate contraction pairs improve the actual upper endpoint to approximately 1.8313917311990002e-10. The upper/lower ratio is approximately 1.0064543677534608.','Tighten the remaining source-feasible gap, validate parameter families and improve upper constructions or exact lower constraints. Threshold sharpness, arbitrary-report decoding and global recovery remain open.'),
    'R15':('independent_source_direction_and_mixed_variable_audit','Independent real Cramer ratios check the lower bound; complex scalar derivatives and352 directly rebuilt source inequalities audit both mixed A/B systems.46 mutations and five exact controls pass; seven generic Lean lemmas compile. Rejected region-violating trials and a receipt limitation are preserved.','Formalize the full concrete conditional secant and mixed contraction assembly, verify useful inverse algorithms and widen domains or produce counterexamples. Keep necessary/sufficient source endpoints and free-coordinate ownership explicit.'),
    'K04':('append_only_source_constrained_delta','All 117 branches and458 previous events are preserved. Five new events link the stronger conditional lower guarantee, two mixed upper pairs, independent audits, 46 mutations, five controls, seven Lean lemmas and 12 command receipts including one failure.','Continue evidence-backed discovery across the full ACS program, preserve immutable sources and actual failures/limitations, and retain every wider branch and private-input gate. No global completion or exhaustion claim.')}
prefix=str(OUT.relative_to(ROOT))+'/'
evidence=['Source_Constrained_Summary.json','Source_Strip_Certificate.json','Mixed_Noise_Certificate.json','Independent_Source_Constrained_Audit.json','Proof_Audit.md','Adversary_Audit.json','Lean_Check.json','Development_Notes.json']
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_source_strip_and_mixed_A_B_audit')
        b['new_evidence']=[prefix+n for n in evidence]
        b['verification_routes']+=['Exact necessary source endpoints and conditional budget bootstrap','Real-polynomial Cramer ratios for the restricted column corner','Real mixed A/B interval Jacobians versus complex scalar derivatives','352 direct source inequalities and 1128 polynomial factorizations','46 mutations, five exact controls and seven Lean lemmas']
        b['shared_assumptions_and_scope']='Inherited complete finite two-field class, source populations and original feature/root error contract. The critical strip is deduced conditionally from a common report below an inherited cap; the lower guarantee is itself below that cap. Two mixed-coordinate pairs have exact contraction certificates. Numerical routes share FLINT; concrete analytic formalization, threshold sharpness and global decoding remain open.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=458
for bid in ADVANCED:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'source_strip_mixed_pair_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Source constraints narrow the local feature-noise bracket — 14 September 2026

**The strict lower guarantee increases to approximately 1.8196470598929473e-10, while the actual ambiguity upper endpoint improves to approximately 1.8313917311990002e-10.** Their ratio is 1.0064543677534608, leaving about 0.65%. The source-feasible threshold remains open.

The [proof and reproduction guide](../../../code/frontier_verification/SOURCE_CONSTRAINED_README.md) derives the source-critical strip bootstrap and mixed A/B construction. The [written proof audit](Proof_Audit.md) checks quantifiers, endpoint directions and scope. The [preceding checkpoint](../2026-09-14-aggregate-signed-corner-delta/README.md) supplies the full convex column-family theorem.

- [Results and continuation gates](Source_Constrained_Summary.json).
- [Canonical source-strip certificate](Source_Strip_Certificate.json), [two mixed A/B noise certificates](Mixed_Noise_Certificate.json) and [independent analytic/source/arithmetic audit](Independent_Source_Constrained_Audit.json).
- Preserved exploratory [critical strip](Critical_Strip_Exploration.json), [independent strip audit](Independent_Critical_Strip_Audit.json), [rejected near-corner diagnostics](Corner_Pair_Diagnostic.json), [mixed proposals](Complementary_Pair_Proposals.json) and [mixed interval checks](Complementary_Pair_Checks.json).
- [46 adversarial mutations and five exact controls](Adversary_Audit.json), [seven compiled Lean lemmas](Lean_Check.json) and [source/compiled artifact](Lean_Artifacts.zip).
- [Twelve command receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [failed attempt and receipt limitation](Development_Notes.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh full verification](Verification.json).
- [Primary source acquisition](Source_Acquisition.json), [inherited sources](Primary_Sources.json), [runtime](Runtime.json) and [inherited inputs](Inherited_Inputs.json).
- [All 117 research branches](Research_Queue.json) and the [463-event ledger](Branch_Events.jsonl), preserving the 458-event prefix byte for byte.

Any common report within the inherited feature budget cap has a bounded critical root difference. Opposite source constraints then confine the critical roots to a strip of half-width about 1.0342810350341335e-8. Its derivative-column family is a subset of the previously certified nonsingular family. The inherited endpoint signs and a newly verified coordinate 12 face sign give a conditional inverse bound approximately 54.955712129078016. Since the improved lower guarantee lies below the original budget cap, the bootstrap applies under the original observation contract. It does not impose a new external root restriction.

The successful upper constructions choose one free A or B root per noncritical coordinate and pin the opposite observation inside the selected cube endpoint. The21 mixed root variables and alpha=tau/1e-10 form a 22-dimensional system. Free B derivative columns carry a minus sign; the final noise column is the exact constant -2e-10*v. Real interval checks at 768/1024 bits and independent complex scalar checks at 896/1152 bits prove self-mapping contractions on variable cubes of radius 1e-120. All 352 direct source inequalities, positivity/order and cube checks pass. The fixed critical safety increment is explicitly reduced to 1e-24 without changing the root-error radius.

The naive all-free-A corner search produced converged source-feasible centers outside the cube by about 0.000287–0.000288. The failed source and a separate diagnostic retaining all three rejected trials are replayed. Their lower numerical tau values do not certify admissible pairs. One diagnostic receipt omitted its automatic source-hash map because launch and child directories differed; the unchanged receipt, report source hash, archived script and exact replay expose and address that provenance limitation.

Independent real-polynomial Cramer ratios confirm the lower corner. Independent polynomial arithmetic repeats 1128 factorizations and 1208 comparisons; the inherited finite class and 604-column map yield 456 fixed and 148 ambiguous domains at both new common reports. The22-entry source populations below 39/2, selection before root noise, original radius .01 coordinate cube, root error r=U-1e-8<L and 22 finite feature definitions are unchanged.

Seven generic Lean lemmas compile without proof placeholders. The complete concrete secant/contraction and spectral/arithmetic assembly remains partly written or computational. Numerical routes share FLINT and inherited premises. No runtime version changed and no new source roots were computed.

Next: tighter source-feasible bounds and actual pairs, validated parameter families, arbitrary-report bounded-error decoding, larger/global regions or counterexamples and full analytic formalization. All wider natural-operator, infinite-arithmetic, real-part, topology, physical-acquisition and private-input branches remain active. No global completion or exhaustion is claimed.
''')
names=['dedekind_source_strip_certificate.py','dedekind_mixed_noise_certificate.py','dedekind_source_constrained_audit.py','dedekind_source_constrained_adversary.py','check_source_constrained_lean.py','verify_aggregate_source_constrained_delta.py','SOURCE_CONSTRAINED_README.md','proofs/SourceConstrainedNoise.lean']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
    path=todo.pop()
    for node in ast.walk(ast.parse(path.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for mod in modules:
            d=CODE/(mod+'.py')
            if d.exists() and d not in seen:
                seen.add(d);todo.append(d)
                if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt');mathlib=BASE.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/e['path'],'external/'+e['path']) for e in read(BASE/'Source_Acquisition.json')['pinned_sources']]+[(mathlib/'LICENSE','external/mathlib-LICENSE')]
explorations=[(BASE/n,'exploration/'+n) for n in ['run_recorded.py','capture_sources.py','explore_critical_strip.py','audit_critical_strip.py','explore_corner_pairs.py','explore_corner_pairs_v2.py','explore_complementary_pairs.py','check_complementary_pairs.py']]
packaging=[(Path(__file__),'packaging/'+Path(__file__).name)]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},
    'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'exploration_sources':{n:sha(p.read_bytes()) for p,n in explorations},'packaging_sources':{n:sha(p.read_bytes()) for p,n in packaging},
    'scope':'Eight new instruments, transitive imported local Python dependencies, six original scripts including failure and diagnostic, runner/source capture, packager and pinned Mathlib references with license. The preceding verifier is pinned and recursively executed.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+explorations+external+packaging)
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive verification; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. The preceding evidence chain is recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 source-strip and mixed observation delta](2026-09-14-aggregate-source-constrained-delta/README.md): source constraints and mixed A/B constructions narrow the local threshold bracket to about 0.65%.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-signed-corner-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-source-constrained-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':12,'successes':11,'failures':1,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
