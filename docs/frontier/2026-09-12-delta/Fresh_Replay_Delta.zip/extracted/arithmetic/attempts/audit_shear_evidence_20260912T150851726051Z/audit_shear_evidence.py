"""Bounded adversarial audit of sibling shear evidence; no shear mutations.

Uses exact Fraction parsing of serialized decimal balls, independently of Arb.
The expensive interval propagations are inspected, not rerun here.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,re,hashlib
import sympy as S
root=next(p for p in Path(__file__).resolve().parents if (p/'findings.json').is_file())
shear=root.parent/'shear'

def interval(s):
    s=s.strip()
    if s.startswith('['):
        body=s[1:-1].strip()
        if body.startswith('+/-'):return -Q(body[3:].strip()),Q(body[3:].strip())
        a,b=body.split('+/-')
        return Q(a.strip())-Q(b.strip()),Q(a.strip())+Q(b.strip())
    return Q(s),Q(s)

def newest(pattern):
    candidates=sorted((shear/'attempts').glob(pattern+'/result.json'))
    return candidates[-1] if candidates else None

u=newest('uniqueness_certificate_final_*')
p=newest('peak_refinement_certificate_final_*')
i=newest('independent_global_certificate_final_*')
gate=newest('serialized_records_gate_*')
assert u and p
ud=json.loads(u.read_text());pd=json.loads(p.read_text())
outer=json.loads((u.parent/'outer_exclusion.json').read_text())['accepted']
curve=json.loads((u.parent/'curvature_cover.json').read_text())
for row in outer:
    assert interval(row['D_lower'])[0]>0
    assert interval(row['D_upper'])[1]>interval(row['D_lower'])[0]
for a,b in [(Q('0.1897'),Q('.4')),(Q('.5'),Q('.98'))]:
    rows=sorted([r for r in outer if Q(r['lo'])>=a and Q(r['hi'])<=b],key=lambda r:Q(r['lo']))
    assert Q(rows[0]['lo'])==a and Q(rows[-1]['hi'])==b
    assert all(Q(x['hi'])==Q(y['lo']) for x,y in zip(rows,rows[1:]))
assert len(curve)==50
curve.sort(key=lambda r:Q(r['lo']))
assert Q(curve[0]['lo'])==Q('.4') and Q(curve[-1]['hi'])==Q('.5')
assert all(Q(a['hi'])==Q(b['lo']) for a,b in zip(curve,curve[1:]))
assert all(Q(r['s_lo'])==Q('.1897') and Q(r['s_hi'])==Q('.19') for r in curve)
minimum=min(interval(r['D_kk_lower'])[0] for r in curve)
assert minimum>Q('.18')
assert interval(ud['convexity_D_lower_at_upper'])[0]>0
assert interval(ud['independent_D_lower'])[1]<0
assert interval(pd['global_upper_convexity_margin'])[0]>0
assert Q(pd['curvature_lower_used'])==Q('.18')
signs=pd['endpoint_derivative_signs']
assert interval(signs[0]['D_k'])[1]<0 and interval(signs[1]['D_k'])[0]>0
lo,hi=map(Q,pd['growth_fixed_k_root_bracket'])
history={Q(r['growth']):interval(r['D']) for r in pd['root_bisection']}
assert history[lo][1]<0 and history[hi][0]>0
peaklo,peakhi=map(Q,pd['global_growth_interval'])
assert peaklo==lo and peakhi>hi
assert all(Q('.1897')<v<Q('.19') for v in [peaklo,peakhi])
assert [Q(x) for x in pd['k_decimal_interval']]==[Q(x) for x in pd['unique_global_maximizer_k_interval']]
for exact,display in zip([peaklo,peakhi],pd['global_growth_decimal_enclosure']):
    a,b=interval(display);assert a<=exact<=b

# Exact algebraic checks independently implement the fixed-growth chain rule.
k,s,U=S.symbols('k s U');U2=-2*U*(1-U*U)
W=k*U2/(k*U-S.I*s)
assert S.simplify(S.diff(W,k)+S.I*s*U2/(k*U-S.I*s)**2)==0
assert S.simplify(S.diff(W,k,2)/2-S.I*s*U*U2/(k*U-S.I*s)**3)==0
high=Q('.98');height=Q('.1897')
energy=2*high/(1+high)-high*high
assert energy<height*height and 2/(1+high)**2-2*high<0
c=Q('.19');r=Q('.02');ss=Q('.19')
assert 4*(c-r)**2>(c+r)**2+(ss+r)**2

independent={'status':'not_yet_available_in_review','source':None}
if i:
    d=json.loads(i.read_text());rows=sorted(d['accepted_cover'],key=lambda r:Q(r['lo']))
    assert Q(rows[0]['lo'])==Q('.19') and Q(rows[-1]['hi'])==Q('.98')
    assert all(Q(x['hi'])==Q(y['lo']) for x,y in zip(rows,rows[1:]))
    assert all(interval(x['D'])[0]>0 and interval(x['D_lower'])[0]>0 for x in rows)
    independent={'status':'serialized_complete_positive_cover_verified','source':str(i.relative_to(shear)),'cells':len(rows)}
serialization={'status':'not_yet_available_in_review'}
if gate:
    gd=json.loads(gate.read_text())
    assert gd['outer_cells']==132 and gd['curvature_cells']==50
    assert len(gd['records'])==182
    assert all(interval(r['bound'])[0]>0 and interval(r['lower'])[0]>0 for r in gd['records'])
    serialization={'status':'all_182_normalized_balls_positive_under_independent_exact_parser','source':str(gate.relative_to(shear))}

sources=[u,p]
if i:sources.append(i)
if gate:sources.append(gate)
out={'status':'bounded_review_checks_passed','uniqueness_source':str(u.relative_to(shear)),'peak_source':str(p.relative_to(shear)),'positive_outer_cells_by_explicit_lower_endpoint':len(outer),'outer_display_balls_that_lose_sign_despite_positive_recorded_endpoint':sum(interval(x['D_at_lower_growth'])[0]<=0 for x in outer),'curvature_cells':len(curve),'exact_decimal_Dkk_lower':str(minimum),'curvature_exceeds_point_18':True,'endpoint_energy_bound':str(energy),'fixed_growth_derivative_identities':True,'root_bracket_endpoints_each_have_recorded_certified_sign':True,'reported_decimal_enclosures_contain_exact_rational_bounds':True,'independent_cover':independent,'normalized_serialization':serialization,'review_scope':'Exact serialized sign/coverage checks and inspected analytic logic; no full rerun of interval ODE/Frobenius propagators, no reproof of inherited unstable-spectrum classification.','sha256':{str(f.relative_to(shear)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources}}
print(json.dumps(out,indent=2))
