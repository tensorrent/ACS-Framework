This is an unchanged excerpt from ACS_RG_Spectral_Report.md in acs-rg-extension-20260911. These prior analytic premises are inherited, not newly proved by the current shear checks.

## 6. Tanh shear: operator and multiplicity

Use dimensionless y and k, with U=tanh(y), V=2 sech-squared(y), and K=-d-squared/dy-squared+k-squared. For the vorticity q=-K psi, define the state zeta=q divided by square-root(V). The precise Hilbert space for the following spectrum statement is square-integrable zeta on the whole real line.

The bounded Rayleigh operator and conserved form are

\[
R_k=U L_k,\qquad L_k=I-\sqrt{V}K^{-1}\sqrt{V},\qquad \partial_t\zeta=-ikR_k\zeta,
\]

\[
Q(\zeta)=\langle L_k\zeta,\zeta\rangle.
\]

Every ordinary decaying nonreal Rayleigh eigenmode belongs to this space: the eigenvalue equation makes q decay with the additional U-double-prime factor. The weighted space is stated explicitly because changing the state space can change spectral assertions.

The kernel of square-root(V) K-inverse square-root(V) is the product of square-root(V) at the two endpoints and exp(-k times their separation)/(2k). It is Hilbert-Schmidt. Hence R_k is multiplication by U plus a compact perturbation, with Fredholm essential spectrum [-1,1]. Outside that interval its spectrum consists of isolated eigenvalues.

The self-adjoint comparison operator factorizes as

\[
K-V=A^\dagger A+k^2-1,\qquad A=\partial_y+\tanh y,\qquad AA^\dagger=-\partial_y^2+1.
\]

The partner operator has no square-integrable bound states below its continuum. The only bound state of the comparison problem comes from the kernel of A, proportional to sech(y). Therefore K-V has exactly one negative direction for 0<k<1, none for k>1, and one zero direction at k=1. Independently, the unshifted operator -d-squared/dy-squared-V has the zero-energy Sturm solution tanh(y), with one zero, confirming its one-bound-state count before the k-squared shift. Finite-difference Sturm calculations provide a third, numerical check. The Birman-Schwinger correspondence transfers this count to L_k.

For 0<k<1, L_k is invertible with negative index one. Conservation of Q implies that any two growing eigenvectors have zero L-inner product: their growth exponents have a sum with positive real part. The same conclusion extends inductively to generalized eigenvectors. Thus every finite unstable root space is totally isotropic. Its projection onto the one-dimensional negative subspace must be injective, so its dimension is at most one.

The preceding release's whole-line Jost sign-change proof supplies a growing mode for each 0<k<1. Combining existence with the index bound proves exactly one unstable eigenvalue, algebraically simple. Oddness of U gives reflection symmetry, and real coefficients give conjugation symmetry. Uniqueness forces the unstable phase speed to be purely imaginary, with exactly one conjugate decaying partner. The general variational approach has precedent in [2]; the whole-line compactness, state-space and endpoint arguments used here are supplied explicitly rather than inferred from a finite-channel theorem.

## 7. Real spectrum and the neutral endpoint

For real c, substitute psi=(U-c)f into the Rayleigh equation. Direct differentiation gives

\[
\left[(U-c)^2f'\right]'-k^2(U-c)^2f=0.
\]

For real c outside [-1,1], integration against conjugate f gives a sum of two nonnegative integrals, so there is no nonzero decaying eigenfunction. If c is strictly inside the interval and nonzero, the regularity of q forces psi to vanish at the critical layer U=c: otherwise the nonzero U-double-prime there creates a non-square-integrable pole. The ratio f stays bounded, the critical-layer boundary term vanishes, and the same integral identity excludes the eigenfunction.

At c=0 the U-double-prime zero cancels the apparent singularity. The equation becomes (K-V)psi=0, which has a bound state precisely at k=1, with psi proportional to sech(y). At c=1 or -1, the decaying endpoint solution has exponent square-root(k-squared+4) at the corresponding infinity. Its boundary term also vanishes, excluding endpoint eigenfunctions.

The adjoint operator is L_k U. At a nonzero real c, an adjoint eigenvector would become an eigenvector of U L_k after multiplication by U, which is injective. At c=0 and k different from 1, invertibility of L_k excludes an adjoint kernel. At k=1, the neutral zeta is proportional to sech-squared(y); dividing it by U produces a non-square-integrable singularity at zero. The adjoint kernel remains zero. Therefore the real interval is continuous spectrum except for the embedded neutral point at k=1; there is no residual spectrum.

The resulting classification in this state space is:

| Wavenumber | Spectrum and point spectrum |
|---|---|
| 0<k<1 | Continuous interval [-1,1], plus one simple pair of phase speeds +i eta(k), -i eta(k) |
| k=1 | Interval [-1,1], with c=0 an embedded eigenvalue and one-dimensional kernel; other interval points are continuous spectrum |
| k>1 | Continuous interval [-1,1]; no point spectrum |

These are analytic operator claims, with symbolic factorization and divergence-identity checks. The independent spectral discretization confirms representative cases but is not a second universal proof of the whole classification. No formal proof-assistant kernel has verified this new argument.

## 8. Growth maximum and endpoint asymptotics

Two separate numerical formulations were used. The first integrates the complex half-line Riccati equation with analytic derivatives in k and imaginary phase speed. The second maps the whole line using u=tanh(y), factors out the exact endpoint decay, and solves a Chebyshev generalized eigenvalue pencil. It has no finite far-field boundary.

At spectral degree 384, each of k=0.2,0.4446,0.7,0.9 has exactly one computed unstable eigenvalue above the stated 1e-7 threshold, and k=1.1 has none. The leading eigenvalues agree with shooting within 5.2e-11 in these cases. The spectral degree and shooting domain/tolerance are varied independently.

The stationary peak estimate is

\[
k_*\simeq0.444918,\qquad \eta_*\simeq0.4263754,\qquad k_*\eta_*\simeq0.18970210.
\]

The growth values agree within 1.2e-11; the spectral optimizer's maximizing k varies by approximately 7e-7 relative to the sensitivity result. This is a converged numerical estimate, not an interval-certified value. In physical units, multiply the growth by U0/delta and replace k by k delta.

An additional exact result controls the upper endpoint:

\[
\eta(k)\sim\frac{2}{\pi}(1-k),\qquad k\longrightarrow1^-.
\]

To derive it, let F(k,eta) be the real logarithmic derivative of the left-decaying Jost solution at zero. At eta=0, the exact Darboux solution gives F(k,0)=(k-squared-1)/k. The perturbing potential has L1 norm 2 eta asinh(1/eta). Jost perturbation theory around k near 1 has a quadratic remainder of order eta-squared log-squared(eta). At k=1 the real first-order term is exactly

\[
2\eta(1+\eta^2)\arctan(1/\eta)-2\eta^2=\pi\eta+O(\eta^2).
\]

The critical-layer boundary weight is one uniformly as k approaches 1, so F(k,eta)=(k-squared-1)/k+pi eta+o(eta). Spectral exclusion at k=1 forces the unstable root to eta=0, and the root equation gives the slope above. Independent quadrature verifies the first-order integral; full shooting at five shrinking endpoint distances verifies the limiting ratio.

For completeness, the complex-c version of the divergence identity gives the semicircle bound. With weight equal to absolute f-prime squared plus k-squared absolute f squared, its imaginary part makes the real phase speed the weighted mean of U; its real part makes eta-squared the weighted variance. Since absolute U is at most one, absolute c is at most one and growth is at most k. Growth therefore tends to zero also as k approaches zero.

Simplicity gives a continuous unstable branch. Positive growth in the interior and zero limits at both ends prove that an interior global maximum exists. The saved finite scan observes the expected derivative sign on both sides of the reported peak, but cannot exclude an unsampled additional stationary point. A certified unique global maximizing location remains open. Linear two-dimensional spectral classification also leaves nonlinear, viscous and three-dimensional persistence questions open.

