from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-primal-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-nested-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_primal_delta import summarize
OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
for n in ['Global_Cut_Audit.json','Model_Hull_Witnesses.json','Model_Witness_Audit.json','Joint_Target_Branches.json','Joint_Projection_Audit.json','Discriminant_Parity.json','Parity_Audit.json','Adversary_Audit.json','Primary_Sources.json']:(OUT/n).write_bytes((BASE/n).read_bytes())
for n in ['Pool_A','Pool_B']:archive(n+'.zip',[(BASE/(n+'.json'),n+'.json')])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==12 and sum(r['returncode']==0 for r in receipts.values())==10
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(*[read(BASE/n) for n in ['Global_Cut_Audit.json','Model_Witness_Audit.json','Joint_Projection_Audit.json','Parity_Audit.json','Adversary_Audit.json']])
write('Primal_Summary.json',{'recorded_utc':now,'result':'All seventeen targets recovered at radius 1/10 for A and 3/50 for B using simultaneous cuts, exhaustive finite target projection and parity derived from the signed field discriminant.',
 'input_contract':['degree four','absolute field discriminant 576','signature (0,2)','complete aggregate finite critical-line spectra through 20','unchanged root population, original intervals and measurement family','validated domains at the same or a containing uncertainty radius'],
 'derived_metadata_consequence':'Signed discriminant is +576=24^2. Unramified Frobenius permutations are even, allowing degree partitions 1111, 31 and 22. This does not identify the group as V4.',
 'final_profile':'degree plus discriminant ramification plus derived signed-square parity; both historical seed profiles use this consequence in the final step',
 'not_inference_inputs':['Galois-group label','candidate-field catalogue','defining polynomials','arithmetic coefficient seeds','new zeros or measurement rows'],
 'new_roots_computed':0,'target_count':17,'measurement_rows':17,'generic_coefficients':604,'derived_results':summary,
 'scope':'The 99-branch projection is complete for the old necessary-cut/local-model relaxation; two target tuples per observation/profile survive it. Signed-discriminant parity refutes one per case. Four new full integer witnesses satisfy the strengthened relaxation, not a claimed alternate-field realization. The success radii are sufficient and extend to contained smaller boxes, not optimal thresholds.',
 'full_number_theoretic_proof_formalized':False,'next_gate':'Extend noise-radius tests with the derived parity rule; separate spectral information from metadata consequences; investigate additional actual fields, global compatibility and complete arithmetic formalization.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':12,'successful_commands':10,'failed_commands':2,
 'recording_scope':'Ten successful numerical, combinatorial, source and adversarial executions, one failed HTTP acquisition and one failed parity auditor. Packaging and final recursive verification are separate.',
 'failures':[{'command':'primary-source-acquisition','reason':'HTTP 406 with default urllib headers','resolution':'Separate acquire_primary_sources_v2.py with standard request headers; old source and receipt preserved'},
             {'command':'independent-parity-audit','reason':'SymPy expression factor sorting reached FLINT nmod comparison: TypeError nmods cannot be ordered','resolution':'Separate dedekind_aggregate_parity_audit_v2.py uses Poly.factor_list for that control; old source and receipt preserved'}],
 'freeze_boundary':'All executed instrument versions are retained unchanged. The v2 correction changes only the factorization API in the index-prime control, not the decoder, mathematical hypotheses or arithmetic comparison.',
 'method_delta':'Keep full global cut vectors; explore the convex hull of local models; branch over every remaining target tuple and prove infeasibility with constant-zero rational separation; derive missing unramified parity from signed discriminant.',
 'no_gain_control':'52 model-hull objectives give zero new individual-domain exclusions before joint target branching.',
 'solver_acceptance':'12 optimal maximum-slack proposals have negative exact selected slack and are rejected. A status-zero solver result is not evidence of feasible inequalities.',
 'verification_search_scope':'Final verification reruns the continuum and model-hull LP deduction computations. It checks every stored MILP point and every joint separation exactly instead of repeating MILP search or the joint branch LP proposal search.',
 'independence':'Real continuum versus complex quadratic covers, rational moments, integer versus Fraction supports, independent local catalogues, full integer witnesses, unrounded interval margins, permutation inversion/cycle/determinant agreement, polynomial/Sylvester discriminants and separate irreducibility controls. Transcendental interval routes share FLINT; mpmath displaced controls are samples.',
 'arithmetic_scope':'Source-backed general discriminant arguments are written, not Lean formalized. The finite permutation checks do not alone prove the general number-theoretic bridge.',
 'history_policy':'Keep all 117 branches, preserve the 413-event prefix and append five events. Research remains active without global completion.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Inherited pinned Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0, mpmath 1.3.0 and python-flint 0.9.0/FLINT 3.6.0. New HiGHS LP/MILP proposals, exact integer/Fraction checks, 224-bit real and 384-bit complex interval covers. No new Lean theorems or package installations.';write('Runtime.json',runtime)
paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json','Primary_Sources.json']]+[PRIOR/n for n in ['Nested_Feedback.zip','Nested_Closure.json','Manifest.json','Verification.json']]+[ROOT/'docs/frontier/2026-09-13-aggregate-adaptive-delta/Adaptive_Feedback.zip',ROOT/'docs/frontier/2026-09-13-aggregate-optimized-delta/Proposals.json',ROOT/'docs/frontier/2026-09-13-aggregate-moment-delta/Moment_Proposals.json']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'Old vectors supply directions only; fresh uncertainty budgets are recalculated. Prior same-radius domains retain recursively checked numerical and local proofs. Baseline explicit-formula sources and input provenance remain inherited.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Simultaneous-cut projection and discriminant-parity delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
 replay_scope='Fresh simultaneous cut budgets, model hulls, exact exhaustive target projection, complete integer witnesses and derived signed-discriminant parity with independent arithmetic controls.',
 next_priority=['R12/R13: test wider uncertainty with derived parity; measure spectral contribution beyond signed-discriminant consequences','R13/R14: investigate global compatibility beyond the finite local-model relaxation and formalize the arithmetic bridge','R15: extend actual-field benchmarks with matched metadata and certified input contracts','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('simultaneous_global_cuts_recertified','351 distinct directions including all 34 unit signed rows per observation receive fresh budgets at A radius 1/10 and B radius 3/50. Independent checks cover 378480 stored midpoint evaluations, 756960 complex leaves and 1404 displaced controls. Complete cut vectors are retained before residual projection.','Test larger noise boxes with fresh budgets, preserve exact transfer direction and distinguish finite-row consequences from global realization.'),
 'R13':('all_targets_via_joint_projection_and_discriminant_parity','All seventeen targets follow at A radius 0.1 and B radius 0.06. Joint branching exactly projects the retained finite relaxation; signed discriminant 576=24^2 then excludes the unwanted unramified splitting at A prime 29 or B prime 5. Both historical seed profiles now use derived discriminant parity.','Extend sufficient radii and determine what finite spectra contribute beyond metadata-derived even splitting, without claiming optimal thresholds or field classification.'),
 'R14':('complete_relaxed_target_projection_and_stronger_integer_witnesses','All 99 Cartesian assignments are accounted for: 91 strict rational separation certificates and eight full integer witnesses, two per case. Parity refutes four target tuples and four new complete integer witnesses satisfy every strengthened local rule and cut, including unrounded interval checks.','Study global-field and spectral realizability beyond necessary local inequalities; preserve complete projection only for its stated finite relaxation.'),
 'R15':('signed_discriminant_ramification_and_index_guards','Twenty-four permutations are cross-checked by inversions, determinants and orbits. Exact polynomial controls distinguish signed square from absolute square, A4 from V4, and field ramification from polynomial-index divisibility. Ten mutations are rejected. Twelve optimal slack-search proposals remain rejected as infeasible.','Retain signed-discriminant and ramification guards, avoid power-basis errors at index primes, and extend actual-field benchmarks and cross-method audits.'),
 'K04':('ongoing_delta_with_projection_parity_and_preserved_failures','Preserve 117 branches and 413 events; append five. Twelve recorded commands comprise ten successes and two retained failures resolved by separate versioned retries. Final verification replays numerical proofs and stored finite certificates; the general arithmetic argument remains unformalized.','Continue evidence-backed research deltas, retaining assumptions, failed versions, proof scope, provenance and concrete next gates without global completion.')}
prefix=str(OUT.relative_to(ROOT))+'/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_simultaneous_projection_and_signed_discriminant_audit')
  b['new_evidence']=[prefix+n for n in ['Primal_Summary.json','Pool_A.zip','Pool_B.zip','Global_Cut_Audit.json','Joint_Projection_Audit.json','Discriminant_Parity.json','Parity_Audit.json','Adversary_Audit.json']]
  b['verification_routes']+=['Fresh real and independent complex continuum cut certificates','Exact integer and independent Fraction local-model supports','Exhaustive Cartesian target coverage and rational separation','Complete integer witnesses with unrounded interval checks','Signed-discriminant derivation plus permutation and polynomial controls','Ten semantic mutations and an actual min-support counterexample']
  b['shared_assumptions_and_scope']='Degree four, signature (0,2), absolute field discriminant 576 and complete finite critical-line spectra through 20. Same source roots and measurements; no field catalogue, Galois-group label or arithmetic seed. Final profiles use derived discriminant parity. Exact finite-relaxation projection is not a field-realization theorem. Sufficient noise radii are not optimal thresholds; the general arithmetic proof is written rather than Lean formalized.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=413
for bid in q['advanced_existing_branches']:
 b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'simultaneous_projection_and_discriminant_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Simultaneous projection and discriminant parity — 14 September 2026

All seventeen benchmark coefficients through 31 are certified at ordinate radius **0.10 for A** and **0.06 for B**, advancing the preceding sufficient radii 0.08 and 0.05. The change combines full simultaneous inequalities, exhaustive finite target branching and a consequence of the supplied signed discriminant. No new zeros, measurements, defining polynomials, Galois-group label, field catalogue or arithmetic coefficient seeds enter inference. Both old seed profiles now use discriminant and its square consequence.

The [derivation and reproduction guide](../../../code/frontier_verification/AGGREGATE_PRIMAL_README.md) explains the exact cuts, conditional separation proofs, the field-basis and finite-algebra parity arguments, their index-prime safeguards and remaining scope.

- [Results and next gates](Primal_Summary.json).
- [A continuum certificates](Pool_A.zip) and [B continuum certificates](Pool_B.zip): 163 and 188 freshly certified directions, including 34 signed unit rows each.
- [Independent global cut audit](Global_Cut_Audit.json): 378,480 midpoint checks, 756,960 fresh complex quadratic leaves and 1,404 displaced controls.
- [Model-hull proposals and every integer point](Model_Hull_Witnesses.json), with [independent audit](Model_Witness_Audit.json): 52 exact objectives give no further individual exclusions; 66 of 78 proposals satisfy selected cuts and 37 satisfy the full pool. Twelve optimal proposals remain infeasible.
- [All 99 target assignments](Joint_Target_Branches.json) and [independent complete projection](Joint_Projection_Audit.json): 91 rationally refuted, eight witnessed, zero unresolved. These witnesses strictly satisfy unrounded interval cuts but establish only finite-relaxation feasibility.
- [Signed-discriminant deduction and new witnesses](Discriminant_Parity.json), with [independent permutation, polynomial and interval audit](Parity_Audit.json): one of two target tuples is refuted in each case, leaving all seventeen necessary targets and four full witnesses for the strengthened relaxation.
- [Ten mutations, rejected solver points and min-support counterexample](Adversary_Audit.json).
- [Execution receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json) and [primary source fingerprints](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [frozen snapshots including failed versions](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [418-event ledger](Branch_Events.jsonl), preserving the preceding 413 events byte for byte.

Signed D=+576=24 squared forces even permutations. At unramified primes, the allowed splitting degrees are 1111, 31 and 22. This excludes A's alternative c29=2 and B's alternative (c5,c25)=(0,0), while preserving three-cycles. The rule is not applied at ramified primes. A separate generator check handles the polynomial-index exception at prime 5. The general mathematical argument is source-backed written work, not yet a Lean proof.

Ten of twelve recorded commands succeed. The initial source download returns HTTP 406, and the first parity auditor encounters a SymPy/FLINT factor-sorting error; separately preserved retries succeed. Earlier failures and stronger scoped results remain in the [preceding checkpoint](../2026-09-13-aggregate-nested-delta/README.md).

The new sufficient radii extend to contained smaller boxes under the unchanged contract. They do not give optimal thresholds or classify all fields. Next, test wider noise with the derived parity rule, separate spectral information from metadata consequences, examine further actual fields and global compatibility, and formalize the arithmetic bridge. The wider ACS investigation remains active.
''')
names=sorted({p.name for p in CODE.glob('dedekind_aggregate_primal*.py')}|{'dedekind_aggregate_discriminant_parity.py','dedekind_aggregate_parity_audit.py','dedekind_aggregate_parity_audit_v2.py','verify_aggregate_primal_delta.py','AGGREGATE_PRIMAL_README.md'})
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'scope':'New and failed instrument versions plus transitive local Python dependencies; previous checkpoints verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py','acquire_primary_sources.py','acquire_primary_sources_v2.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoints verified recursively.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]'
text=text.replace(marker,'- [14 September 2026 simultaneous projection and discriminant-parity delta](2026-09-14-aggregate-primal-delta/README.md): exhaustive target projection and derived even splitting recover all seventeen coefficients at radii 0.10 and 0.06, with full integer witnesses and independent arithmetic guards.\n'+marker)
text=text.replace('[Current research queue](2026-09-13-aggregate-nested-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-primal-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
