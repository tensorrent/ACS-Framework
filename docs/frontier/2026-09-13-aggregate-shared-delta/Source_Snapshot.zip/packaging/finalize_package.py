"""Preserve the first verification packaging failure and finalize its output path."""
import hashlib,json,zipfile
from pathlib import Path

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-shared-delta'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
stderr=(BASE/'verification-stderr.txt').read_bytes();stdout=(BASE/'Verification.json').read_bytes()
assert b"'Verification.json')" in stderr and b'line 92' in stderr and stdout==b''
notes={'first_invocation':{'returncode':1,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),
    'command':'../acs-research/.venv/bin/python code/frontier_verification/verify_aggregate_shared_delta.py > ../acs-research/aggregate-shared-audit/Verification.json 2> ../acs-research/aggregate-shared-audit/verification-stderr.txt',
    'failure':'The final README link check required the new output Verification.json, but this invocation redirected the report into scratch before any repository report file existed.',
    'completed_before_failure':'Recursive history, new producers, all three independent audits, manifests, input hashes, receipts, source records, branch preservation and ledger replay reached the final local-link check successfully.'},
    'correction':'Create a marked in-progress report at the expected output path, then rerun the unchanged verifier and replace it with the successful report.',
    'instruments_changed':False,'scientific_recorded_commands':7,'scientific_failed_commands':0,'retained_packaging_verification_failures':1}
write(OUT/'Verification_Attempts.json',notes)
with zipfile.ZipFile(OUT/'Verification_Attempts.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr('first-invocation/stdout.txt',stdout);z.writestr('first-invocation/stderr.txt',stderr)
    z.writestr('first-invocation/notes.json',json.dumps(notes,indent=2)+'\n')
development=read(OUT/'Development_Notes.json');development['packaging_verification_failure']=notes
write(OUT/'Development_Notes.json',development)
readme=OUT/'README.md';text=readme.read_text();needle='- [Manifest](Manifest.json) and [fresh recursive verification](Verification.json).'
assert needle in text
readme.write_text(text.replace(needle,needle+' The [first verification attempt](Verification_Attempts.json) and [its exact output](Verification_Attempts.zip) preserve an output-file ordering failure at the final link check; the scientific instruments and results were unchanged.'))
with zipfile.ZipFile(OUT/'Source_Snapshot.zip','a',compression=zipfile.ZIP_DEFLATED) as z:z.write(Path(__file__),'packaging/'+Path(__file__).name)
manifest=read(OUT/'Manifest.json')
for p in OUT.iterdir():
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();manifest['files'][str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write(OUT/'Manifest.json',manifest)
print(json.dumps({'status':'finalized','retained_packaging_failure':1,'manifest_files':len(manifest['files'])}))
