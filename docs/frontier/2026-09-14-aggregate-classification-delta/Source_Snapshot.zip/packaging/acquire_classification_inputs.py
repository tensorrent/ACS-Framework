import hashlib,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=BASE.parent/'aggregate-audit/inputs/S1_224.json';other=BASE.parent/'aggregate-audit/inputs/S2_224.json'
keys=['degree','discriminant','real_places','complex_places'];metadata={k:json.loads(original.read_text())[k] for k in keys}
assert metadata=={k:json.loads(other.read_text())[k] for k in keys}
(BASE/'Metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
url='https://kconrad.math.uconn.edu/blurbs/gradnumthy/different.pdf'
with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'application/pdf'}),timeout=60) as r:raw=r.read();resolved=r.url
assert raw.startswith(b'%PDF');new=BASE/'Conrad_Different.pdf';new.write_bytes(raw)
old=BASE.parent/'aggregate-primal-audit/ANT.pdf';assert sha(old)=='24b83c789a89f25aebffb3cbe4ae5ca29edd0075acc072de093d140770630847'
(BASE/'Milne_ANT.pdf').write_bytes(old.read_bytes())
result={'status':'passed','source_sha256':sha(Path(__file__)),'recorded_utc':datetime.now(timezone.utc).isoformat(),'metadata_sha256':sha(BASE/'Metadata.json'),'metadata_source_sha256':{p.name:sha(p) for p in [original,other]},'new_downloads':1,'reused_local_primary_PDFs':1,
 'sources':[{'author':'Keith Conrad','title':'The Different Ideal','url':url,'resolved_url':resolved,'bytes':new.stat().st_size,'sha256':sha(new),'locations':['Theorem4.13, printed/PDF page12: tame exponent e−1 and wild exponent at least e','Corollary4.16, printed/PDF page14: local contributions to field discriminant'],'redistributed_in_repository':False},
 {'author':'J.S. Milne','title':'Algebraic Number Theory','url':'https://www.jmilne.org/math/CourseNotes/ANT.pdf','bytes':old.stat().st_size,'sha256':sha(old),'locations':['Proposition2.26 and2.40: embedding determinant and sign','Theorem3.35: ramification iff field-discriminant divisibility','Theorem4.9: no nontrivial extension of Q unramified at all finite primes','Corollaries7.51/7.52: closure of unramified local extensions','Lemma7.57, Theorem7.58, Corollary7.59: inertia, normal wild filtration and tame embedding','Proposition8.2 and decomposition-group section: local factors and local Galois action'],'redistributed_in_repository':False}],
 'inherited_sources':{'record':'docs/frontier/2026-09-13-biquadratic-delta/Primary_Sources.json','sha256':sha(ROOT/'docs/frontier/2026-09-13-biquadratic-delta/Primary_Sources.json'),'use':'Conductor-discriminant formula and certified candidate arithmetic/spectral identities'},
 'scope':'Decoder metadata contains only degree, absolute discriminant and signature. New primary source download and exact reuse are distinguished. PDFs stay in scratch; written mathematical derivations and independent finite audits are required in addition to source fingerprints.'}
(BASE/'Primary_Sources.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
