"""Unpublished source-feasible variable-noise pairs near the critical-strip corner."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
import mpmath as mp
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES,kernel,number,exported
from dedekind_feature_certificate import coordinate_audit
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta/Signed_Corner_Certificate.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    mp.mp.dps=220;cert=json.loads(ANCHOR.read_text());s=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text())
    common=list(map(F,cert['common_root_center']));c=list(map(number,common));r=F(cert['contract']['root_coordinate_error_radius']);v=cert['critical_sign_vector'];epsilon=F('1e-8')+F('1e-24');free=[i for i in range(22) if i!=1]
    directions=[x['endpoint_direction'] for x in cert['uniform_curvature_checks'][0]['columns']];directions[12]=-1
    corner=[common[i]+F(1,100)*directions[i] for i in range(22)];corner[1]=common[1]
    J=mp.matrix([[kernel(spec,number(x),True) for x in corner] for spec in FEATURES]);u=J**-1*mp.matrix(v)
    tau0=number(epsilon)/u[1];delta=[2*tau0*x for x in u];assert tau0>0
    cases=[];scale_tau=mp.mpf('1e-10')
    for margin_text in ['1e-6','1e-8','1e-10']:
        margin=F(margin_text);B=list(common)
        for i in free:
            estimated=F(mp.nstr(delta[i],170));B[i]=corner[i]-directions[i]*(max(F(0),directions[i]*estimated)+margin)
        B[1]=common[1]-epsilon;Bm=list(map(number,B));BF=[sum(kernel(spec,x) for x in Bm) for spec in FEATURES]
        variables=mp.matrix([number(B[i]-common[i])+delta[i] for i in free]+[tau0/scale_tau]);history=[]
        def evaluate(w):
            A=list(c);A[1]+=number(epsilon)
            for j,i in enumerate(free):A[i]+=w[j]
            residual=mp.matrix([sum(kernel(spec,x) for x in A)-BF[k]-2*scale_tau*w[21]*v[k] for k,spec in enumerate(FEATURES)])
            JJ=mp.matrix([[kernel(spec,A[i],True) for i in free]+[-2*scale_tau*v[k]] for k,spec in enumerate(FEATURES)])
            return A,residual,JJ
        for iteration in range(25):
            A,f,JJ=evaluate(variables);res=max(abs(x) for x in f);history.append({'iteration':iteration,'residual':mp.nstr(res,170)})
            if res<mp.mpf('1e-160'):break
            variables-=mp.lu_solve(JJ,f)
        A,f,JJ=evaluate(variables);tau=scale_tau*variables[21];rationalA=list(common);rationalA[1]+=epsilon
        for j,i in enumerate(free):rationalA[i]+=F(mp.nstr(variables[j],170))
        records=coordinate_audit({'radius':r,'boxes_A':[(x,x) for x in rationalA],'boxes_B':[(x,x) for x in B]},s,SOURCE/'Equal_Population_Inputs.zip')
        maxdis=max(abs(x-y) for coords in [rationalA,B] for x,y in zip(coords,common));source_ok=all(x['within_radius'] for x in records)
        assert res<mp.mpf('1e-160') and source_ok and maxdis<F(1,100)
        cases.append({'status':'numerical_proposal_not_certified','B_correction_scale':'corner_margin_'+margin_text,'free_A_indices':free,'fixed_A_critical_coordinate':str(common[1]+epsilon),'fixed_B_coordinates':list(map(str,B)),
            'A_coordinate_corrections':[mp.nstr(variables[j],170) for j in range(21)],'scaled_tau':mp.nstr(variables[21],170),'tau_scale':'1/10000000000','feature_difference_direction':v,
            'preconditioner':exported(JJ**-1),'tau_proposal':mp.nstr(tau,170),'tau_display':float(tau),'numerically_converged':max(abs(x) for x in f)<mp.mpf('1e-160'),'history':history,
            'maximum_residual':mp.nstr(max(abs(x) for x in f),170),'minimum_cube_margin':str(F(1,100)-maxdis),'rational_center_source_constraints_all_pass':source_ok,'rational_center_coordinate_audit':records})
    return {'status':'exploratory_proposals_require_certification','source_sha256':sha(Path(__file__)),'inputs_sha256':{p.name:sha(p) for p in [ANCHOR,SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_proposal.py',CODE/'dedekind_feature_certificate.py']},
        'mpmath_dps':220,'export_significant_digits':170,'critical_epsilon':str(epsilon),'root_coordinate_error_radius':str(r),'cases':cases,
        'scope':'Three numerical pairs near the maximizing column corner, with source and region checks at rational centers. The critical split is 1e-8+1e-24, within the unchanged root-error contract. Exact existence, interval-box source constraints, independent audit and proof are required before any new upper endpoint is published. Separate from frozen checkpoint 31.'}
r=run();(BASE/'Corner_Pair_Proposals.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'cases':[{k:x[k] for k in ['B_correction_scale','tau_display','minimum_cube_margin','numerically_converged']} for x in r['cases']]},indent=2))
