"""Exploratory mixed-A/B boundary systems; preserve all rejected trials."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
import mpmath as mp
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES,kernel,number,exported
from dedekind_feature_certificate import coordinate_audit
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta/Signed_Corner_Certificate.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    mp.mp.dps=220;cert=json.loads(ANCHOR.read_text());src=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text())
    c=list(map(F,cert['common_root_center']));r=F(cert['contract']['root_coordinate_error_radius']);v=cert['critical_sign_vector'];eps=F('1e-8')+F('1e-24');free=[i for i in range(22) if i!=1]
    signs=[x['endpoint_direction'] for x in cert['uniform_curvature_checks'][0]['columns']];signs[12]=-1
    corner=[c[i]+F(1,100)*signs[i] for i in range(22)];corner[1]=c[1]
    JJ=mp.matrix([[kernel(spec,number(x),True) for x in corner] for spec in FEATURES]);u=JJ**-1*mp.matrix(v);tau0=number(eps)/u[1];delta=[2*tau0*x for x in u]
    sides=['B' if signs[i]*u[i]>0 else 'A' for i in free];scale=mp.mpf('1e-10');cases=[]
    for margin in [F('1e-6'),F('1e-10')]:
        fixedA=list(c);fixedB=list(c);fixedA[1]+=eps;fixedB[1]-=eps;initial=[]
        for i,side in zip(free,sides):
            endpoint=corner[i]-signs[i]*margin
            if side=='B':fixedA[i]=endpoint;initial.append(number(endpoint)-delta[i])
            else:fixedB[i]=endpoint;initial.append(number(endpoint)+delta[i])
        w=mp.matrix(initial+[tau0/scale]);history=[];error=None
        def evaluate(w):
            A=list(map(number,fixedA));B=list(map(number,fixedB))
            for j,(i,side) in enumerate(zip(free,sides)):(A if side=='A' else B)[i]=w[j]
            f=mp.matrix([sum(kernel(spec,x) for x in A)-sum(kernel(spec,x) for x in B)-2*scale*w[21]*v[k] for k,spec in enumerate(FEATURES)])
            J=mp.matrix([[(1 if side=='A' else -1)*kernel(spec,(A if side=='A' else B)[i],True) for i,side in zip(free,sides)]+[-2*scale*v[k]] for k,spec in enumerate(FEATURES)])
            return A,B,f,J
        try:
            for it in range(25):
                A,B,f,J=evaluate(w);res=max(abs(x) for x in f);history.append({'iteration':it,'residual':mp.nstr(res,170)})
                if res<mp.mpf('1e-160'):break
                w-=mp.lu_solve(J,f)
            A,B,f,J=evaluate(w)
        except (ValueError,ZeroDivisionError) as e:error=type(e).__name__+': '+str(e)
        if error is not None:cases.append({'margin':str(margin),'status':'numerical_failure','error':error,'history':history});continue
        a=list(fixedA);b=list(fixedB)
        for j,(i,side) in enumerate(zip(free,sides)):(a if side=='A' else b)[i]=F(mp.nstr(w[j],170))
        constraints=coordinate_audit({'radius':r,'boxes_A':[(x,x) for x in a],'boxes_B':[(x,x) for x in b]},src,SOURCE/'Equal_Population_Inputs.zip')
        maxdis=max(abs(x-y) for coords in [a,b] for x,y in zip(coords,c));ok=all(x['within_radius'] for x in constraints);converged=max(abs(x) for x in f)<mp.mpf('1e-160')
        cases.append({'status':'feasible_numerical_candidate' if ok and maxdis<F(1,100) and converged else 'rejected_numerical_trial','margin':str(margin),'free_indices':free,'free_coordinate_sides':sides,
            'fixed_A_coordinates':list(map(str,fixedA)),'fixed_B_coordinates':list(map(str,fixedB)),'variable_center':[mp.nstr(x,170) for x in w],
            'rational_A_coordinates':list(map(str,a)),'rational_B_coordinates':list(map(str,b)),'preconditioner':exported(J**-1),'tau_scale':'1e-10','tau_proposal':mp.nstr(scale*w[21],170),'tau_display':float(scale*w[21]),
            'minimum_cube_margin':str(F(1,100)-maxdis),'minimum_cube_margin_display':float(F(1,100)-maxdis),'source_centers_pass':ok,'numerically_converged':converged,'history':history,'source_coordinate_checks':constraints})
    return {'status':'exploration_finished_not_certified','source_sha256':sha(Path(__file__)),'inputs_sha256':{p.name:sha(p) for p in [ANCHOR,SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_proposal.py',CODE/'dedekind_feature_certificate.py']},
        'critical_epsilon':str(eps),'root_coordinate_error_radius':str(r),'feature_direction':v,'cases':cases,
        'scope':'Each noncritical coordinate pins one observation to its selected cube endpoint with an interior margin and solves the other. Choice of which field is free follows the initial inverse-direction sign. Unknowns are 21 mixed A/B root coordinates plus scaled noise. Rejected trials are retained. Canonical interval existence, independent source/error audits and a new proof contract are still required. This remains separate from frozen checkpoint 31.'}
r=run();(BASE/'Complementary_Pair_Proposals.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'cases':[{k:x[k] for k in ['status','margin','tau_display','minimum_cube_margin_display','source_centers_pass','numerically_converged'] if k in x} for x in r['cases']]},indent=2))
