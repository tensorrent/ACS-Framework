from pathlib import Path
from fractions import Fraction as F
import hashlib,json
from flint import arb,ctx

BASE=Path(__file__).absolute().parent;SOURCE=BASE/'Weighted_Region_Certificate.json'
def endpoint(x,which):
    m,e=x['mid'];r,t=x['rad'];return F(m)*F(2)**e+which*F(r)*F(2)**t
def av(x):q=F(x);return arb(q.numerator)/arb(q.denominator)
def decode(x):return arb(arb(tuple(x['mid'])),arb(tuple(x['rad'])))
data=json.loads(SOURCE.read_text());ctx.prec=1024;failures=[];exact_violations=[];count=0
for region in data['regions']:
    for case in region['checks']:
        for i,row in enumerate(case['majorant_matrix']):
            for j,stored in enumerate(row):
                upper=F(region['exact_nonnegative_majorant'][i][j]);exact=endpoint(stored,1);count+=1
                if upper<exact:exact_violations.append({'region':region['radius'],'bits':case['precision_bits'],'i':i,'j':j,'exact_margin':str(upper-exact)})
                if not av(upper)>=decode(stored):
                    decoded=decode(stored).upper();m,e=map(int,decoded.man_exp());decoded_upper=F(m)*F(2)**e
                    failures.append({'region':region['radius'],'bits':case['precision_bits'],'i':i,'j':j,'exact_margin':str(upper-exact),
                        'reconstructed_endpoint_inflation':str(decoded_upper-exact),'inflation_display':float(decoded_upper-exact)})
out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'endpoint_comparisons':count,'exact_rational_endpoint_violations':exact_violations,'reconstructed_ball_comparison_failures':failures,
    'scope':'Compare the exact dyadic midpoint-plus-radius endpoint with Arb reconstruction. This diagnoses serialization/constructor behavior; it does not alter the original certificate.'}
(BASE/'Serialized_Endpoint_Diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'comparisons':count,'exact_violations':len(exact_violations),'reconstruction_failures':len(failures),'examples':failures[:3]},indent=2))
