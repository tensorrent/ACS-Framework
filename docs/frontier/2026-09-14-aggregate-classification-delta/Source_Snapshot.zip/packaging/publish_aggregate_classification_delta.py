from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-primal-delta'
INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_classification_delta import summarize
OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
documents=['Metadata.json','Full_Quartic_Class.json','Full_Class_Audit.json','A4_Field_Controls.json','Complete_Class_Count_Decode.json','Complete_Count_Audit.json','Adversary_Audit.json','Primary_Sources.json']
for n in documents:(OUT/n).write_bytes((BASE/n).read_bytes())
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==7 and all(r['returncode']==0 and not r['timed_out'] for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(*[read(BASE/n) for n in ['Full_Quartic_Class.json','Full_Class_Audit.json','A4_Field_Controls.json','Complete_Class_Count_Decode.json','Complete_Count_Audit.json','Adversary_Audit.json']])
write('Classification_Summary.json',{'recorded_utc':now,
 'result':'Degree four, signature (0,2) and absolute field discriminant 576 imply V4 and exactly two fields. A certified distinguishing aggregate zero count selects the field and its Euler coefficient formula; all 604 tracked coefficients are checked independently.',
 'metadata_classifier_input':['degree four','absolute field discriminant 576','zero real places','two complex places'],
 'metadata_classifier_excludes':['supplied Galois-group label','candidate catalogue','defining polynomial','spectrum','arithmetic coefficient seed'],
 'count_decoder_input':'Derived complete field class, certified quadratic-factor and zeta root intervals through height 20, and an observation height/count with an externally justified completeness and error contract. The selector receives no label or individual ordinate.',
 'exact_count_gate':'The complete positive-zero count through height 20 is 23 for A and 22 for B.',
 'robust_count_gate':'The positive-zero count below 7/3 distinguishes the two fields for independent ordinate displacements of absolute size at most 1/3. Completeness through 20 prevents omitted higher roots entering this interior gate.',
 'negative_control':'At radius 1/2 this count statistic is ambiguous: each field admits counts zero and one, with explicit uniform-displacement witnesses. This does not prove ambiguity of full spectra.',
 'prior_information':'Metadata alone fixes 456/604 coefficients and 12/17 targets; the count distinguishes the remaining 148 coefficients and target indices 3,7,19,27,31.',
 'new_roots_computed':0,'new_measurement_rows':0,'tracked_coefficients':604,'target_count':17,'derived_results':summary,
 'number_theoretic_proof_formalized_in_Lean':False,
 'scope':'The complete classification concerns only fields with the stated metadata. General ramification and discriminant arguments are source-backed written mathematics. Independent finite enumerations, actual maximal-order controls and exact arithmetic audits check their implementations and finite components, not the full theorem in Lean.',
 'next_gate':'Construct actual-field benchmarks matching degree, signature, discriminant and finite zero counts, or state explicit restrictions on prior information and decoder. Preserve earlier restricted Gaussian recovery results without interpreting their sufficient radii as optimal information limits.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':7,'successful_commands':7,'failed_commands':0,
 'recording_scope':'Seven source-acquisition, classification, actual-field, count-decoding and adversarial commands. Packaging and final recursive verification are separate.',
 'failures':[],
 'freeze_boundary':'Every executed instrument is unchanged. Earlier dated checkpoints and pinned instruments remain unchanged. No new package dependencies, roots or measurement rows were introduced.',
 'method_delta':'Derive the complete field class from metadata by excluding an A4 normal closure using its cyclic cubic quotient, local wild ramification and Minkowski. Then determine exactly which arithmetic information a certified aggregate count contributes.',
 'independence':'Generator closure versus exhaustive subgroup subsets with opposite composition and cycle parity; square-class planes versus all sign-valued functions modulo 24; order trace discriminants and exhaustive projective nonintegrality checks versus round_two; multiplication characteristic polynomials versus Newton traces; factor-root template construction versus held-out aggregate roots; interval envelopes versus dynamic attainable-count sets; character coefficients versus 1128 local polynomial factorizations.',
 'shared_backend_limits':'Exact algebraic methods share Python and SymPy/FLINT in places. Independent formulations are not independent software stacks. Candidate spectral enclosures and completeness certificates are inherited and recursively verified; no new transcendental certification is claimed.',
 'arithmetic_scope':'The written arithmetic bridge is supported by primary references and finite checks but is not a Lean proof. Two actual A4 fields show that dropping ramified-prime support or the small 3-adic discriminant exponent invalidates the obstruction.',
 'information_scope':'The original benchmark remains valid for its restricted decoder. A more informed decoder uses the complete metadata class and distinguishing count, so prior sufficient Gaussian noise radii do not characterize the information available in this richer model.',
 'history_policy':'Keep all 117 branch IDs, preserve the 418-event byte prefix and append five events. Research remains active without global completion.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Inherited pinned Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0, mpmath 1.3.0 and python-flint 0.9.0/FLINT 3.6.0. New computations use exact integer/rational arithmetic and symbolic polynomial methods. Spectral certification is inherited and replayed recursively. No new Lean theorems or package installations.';write('Runtime.json',runtime)
paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json']]+[PAIR/n for n in ['Pair_Arithmetic.json','Pair_Candidate_Class.json','Pair_Decoding.json','Pair_Spectra.zip','Primary_Sources.json']]+[PRIOR/n for n in ['Manifest.json','Verification.json']]
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'The metadata-only classifier reads only four fields extracted from anonymous inputs. Candidate spectra are inherited. Labelled arithmetic, aggregate templates and the older V4-conditional classification are downstream audit comparisons; they do not seed the new classifier or count selector.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Complete quartic classification and count-information delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
 replay_scope='Fresh complete metadata classification, independent group/character enumeration, exact maximal-order A4 controls, count-only field selection, independent arithmetic comparison and thirteen semantic mutations.',
 next_priority=['R12/R13/R15: construct actual-field benchmarks matching invariants and finite zero counts, or declare restrictions on the prior and decoder','R14/R15: formalize the arithmetic bridge and extend classification beyond the stated metadata','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('certified_count_information_separated_from_ordinate_locations','A complete positive-zero count through 20 is 23 for A and 22 for B. The interior count below 7/3 remains distinguishing for ordinate radius 1/3 with the stated completeness margin; radius 1/2 admits both counts for both actual fields. No new roots or measurement rows are added.','Match finite counts in the next actual-field benchmark and maintain independent completeness/error contracts; count ambiguity alone does not imply full-spectrum ambiguity.'),
 'R13':('all_arithmetic_from_derived_field_class_and_count','Metadata fixes 456 of 604 coefficients and twelve of seventeen targets. A distinguishing count selects one of the two completely classified fields and resolves the remaining 148 coefficients, including targets 3,7,19,27,31. Twenty cases and 1208 independent coefficient comparisons validate the implementation.','Investigate arithmetic recovery when metadata and counts no longer select a field, while preserving earlier Gaussian results as sufficient certificates for their restricted decoder.'),
 'R14':('non_V4_gap_closed_for_discriminant_576','The Galois group is derived from degree four, signature (0,2) and absolute discriminant 576. Square signed discriminant leaves V4 or A4; a cyclic cubic quotient, wild ramification at three and Minkowski exclude A4. Seven quadratic planes then give exactly two fields.','Formalize the source-backed arithmetic bridge and extend to new invariant classes. The complete theorem is scoped to these metadata and does not settle global ACS field realization.'),
 'R15':('actual_A4_hypothesis_controls_and_stronger_benchmark_gate','Actual A4 fields of discriminants 3136 and 5184 test the ramified-prime and wild-exponent hypotheses. Exact maximal-order audits cover 2510 nonzero residue cosets using 470 representatives and agree with round_two. The current benchmark admits full arithmetic selection from metadata plus count.','Construct and independently certify distinct fields matching degree, signature, discriminant and finite counts, or explicitly restrict the available prior and inference method.'),
 'K04':('delta_with_complete_scoped_classification_and_information_audit','Preserve 117 branches and 418 events; append five. All seven recorded source/scientific commands pass and thirteen semantic mutations are rejected. Written general number theory remains distinct from finite computational checks and Lean formalization.','Continue evidence-backed deltas with frozen sources, precise theorem scope, independent routes and concrete next gates; do not claim global completion or exhaustion.')}
prefix=str(OUT.relative_to(ROOT))+'/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_full_metadata_classification_and_count_information_audit')
  b['new_evidence']=[prefix+n for n in ['Classification_Summary.json','Full_Quartic_Class.json','Full_Class_Audit.json','A4_Field_Controls.json','Complete_Class_Count_Decode.json','Complete_Count_Audit.json','Adversary_Audit.json']]
  b['verification_routes']+=['Metadata-only classifier and source-backed local ramification proof','Generator closure versus 2048 subgroup subsets and independent character enumeration','Actual A4 fields with exact maximal-order and round_two comparison','Count-only selection versus independent attainable-count sets','Character Euler coefficients versus 1128 polynomial factorizations','Thirteen semantic mutations and eight explicit count-ambiguity controls']
  b['shared_assumptions_and_scope']='Degree four, signature (0,2), absolute field discriminant 576; no supplied group or field catalogue in classification. Count selection uses inherited certified root templates and an externally established completeness/error contract. Complete classification and coefficient formula concern the stated two-field class; count ambiguity is not full-spectrum ambiguity. The arithmetic proof is written, not Lean formalized.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=418
for bid in q['advanced_existing_branches']:
 b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'full_classification_and_count_information_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Complete quartic classification and count information — 14 September 2026

Degree four, signature (0,2) and absolute field discriminant **576 determine exactly two fields**, A=Q(sqrt(2),sqrt(-3)) and B=Q(sqrt(-2),sqrt(-3)). The V4 group is derived from those metadata, closing the earlier non-V4 classification gap. A certified aggregate positive-zero count then selects the field and its Euler coefficient formula. All 604 tracked coefficients are independently checked.

The [proof and reproduction guide](../../../code/frontier_verification/FULL_QUARTIC_CLASS_README.md) gives the full arithmetic argument, source references, actual-field controls and count contracts. The general proof is written mathematics, **not yet formalized in Lean**.

- [Results and next gates](Classification_Summary.json), with the [four-field metadata input](Metadata.json).
- [Complete field classification](Full_Quartic_Class.json) and [independent audit](Full_Class_Audit.json): generator closure versus all 2,048 identity-containing A4 subsets; square-class planes versus all 256 sign-valued functions modulo 24.
- [Two actual A4 controls](A4_Field_Controls.json), of field discriminants 3136 and 5184: integral orders, exact trace discriminants, 470 projective maximality checks covering 2,510 nonzero residue cosets, Newton trace agreement and independent round_two lattices.
- [Count-only arithmetic decoder](Complete_Class_Count_Decode.json) and [independent count/arithmetic audit](Complete_Count_Audit.json): twenty cases, sixteen unique selections, 1,128 polynomial factorizations and 1,208 coefficient comparisons.
- [Thirteen semantic mutations](Adversary_Audit.json), with eight interval-certified half-radius count-ambiguity controls in the independent audit.
- [Seven successful execution receipts](Execution_Receipts.json), [full execution logs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited input hashes](Inherited_Inputs.json) and [primary source fingerprints](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [frozen source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [423-event ledger](Branch_Events.jsonl), preserving the previous 418 events byte for byte.

Square signed discriminant restricts the normal-closure group to V4 or A4. In the A4 case its cyclic cubic quotient cannot ramify at two; ramification at three would force a wild cubic local factor and a discriminant exponent at least three, contradicting two. The quotient would be everywhere unramified at finite primes, contradicting Minkowski. The remaining V4 case has seven possible quadratic-subfield planes, of which precisely two have the specified invariants.

The exact complete count through height 20 is 23 for A and 22 for B. The count below 7/3 also distinguishes them for every allowed independent ordinate displacement of size at most **1/3**. At radius 1/2 both fields can yield either count zero or one: this is ambiguity of this statistic, not a claim about the full spectrum. Completeness through 20 alone does not justify a noisy count at height 20; the robust result uses an interior gate with a checked margin.

Metadata alone fixes **456 of 604 coefficients and 12 of 17 targets**. The distinguishing count resolves the other 148 coefficients, including target indices 3,7,19,27,31. No new roots or measurement rows are computed. The classifier reads no group label, catalogue, polynomial or spectrum; the count selector receives no field label or individual ordinates. Candidate templates use inherited certified roots, and arithmetic vectors appear only in downstream independent checks.

The actual A4 controls demonstrate the need for the hypotheses: discriminant 3136 permits an extra ramified prime seven, while discriminant 5184 permits wild exponent four at three. All seven recorded source/scientific commands succeed. Earlier dated evidence, failed attempts and stronger scoped certificates remain unchanged in the [preceding checkpoint](../2026-09-14-aggregate-primal-delta/README.md).

The next benchmark should match degree, signature, discriminant and finite zero counts, or declare explicit restrictions on prior information and decoder. Earlier Gaussian recovery remains valid under its stated method and assumptions; its sufficient radii are not optimal limits for the richer decoder here. Arithmetic formalization, broader field classes, natural operators, infinite arithmetic, topology and private-input gates remain active. No global completion or exhaustion is claimed.
''')
names=['dedekind_full_quartic_class.py','dedekind_full_quartic_audit.py','dedekind_quartic_class_controls.py','dedekind_class_count_decode.py','dedekind_class_count_audit.py','dedekind_full_class_adversary.py','verify_aggregate_classification_delta.py','FULL_QUARTIC_CLASS_README.md']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'scope':'New instruments and complete transitive local Python imports; prior checkpoints are also verified recursively. Source-backed arithmetic is written, not a new Lean theorem.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py','acquire_classification_inputs.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoints verified recursively.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]'
assert marker in text
text=text.replace(marker,'- [14 September 2026 full quartic classification and count-information delta](2026-09-14-aggregate-classification-delta/README.md): metadata derives the complete two-field class; a certified count selects all 604 coefficients, with independent arithmetic, actual A4 controls and a stronger benchmark gate.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-primal-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-classification-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
