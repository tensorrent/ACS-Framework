from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-shared-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-uncertainty-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

names=['Marginal_224.json','Shared_Probe160.json','Shared_160.json']
archive('Shared_Audits.zip',[(BASE/n,n) for n in names]);(OUT/'Shared_Audit.json').write_bytes((BASE/'Shared_Audit.json').read_bytes())
audit=read(BASE/'Shared_Audit.json');result=read(BASE/'Shared_160.json');probe=read(BASE/'Shared_Probe160.json')
assert audit['status']=='passed' and result['unique_targets']==81
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==4 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
seed=result['provenance']['seed_case'];newly=[d for d,s in zip(result['domains'],seed['domains']) if d['n']<=361 and len(d['candidates'])==1 and len(s['candidates'])>1]
write('Shared_Summary.json',{'recorded_utc':now,'height':2000,'additional_radius':'5e-3','retained_measurements':455,
 'known_positive_ordinates':7602,'coefficient_support':604,'target_count':91,'prior_unique_targets':73,
 'marginal_dual_unique_targets':73,'two_target_probe_unique_targets':74,'shared_unique_targets':81,
 'new_singletons':newly,'unresolved_targets':[d for d in result['domains'] if d['n']<=361 and len(d['candidates'])>1],
 'all_target_domain_changes':[{'n':d['n'],'before':s['candidates'],'after':d['candidates']} for d,s in zip(result['domains'],seed['domains']) if d['candidates']!=s['candidates']],
 'main_shared_certificates':56,'main_requested_solver_calls':48,'opposite_box_bounds_without_solver':8,
 'probe_limited_solver_calls':2,'marginal_certificates_replayed':36,'shared_certificates_at_two_precisions':120,
 'independent_derivative_cases':75,'independent_finite_center_sums':2,
 'scope':'Same declared uncertainty, inputs and inherited analytic assumptions. Only shared-error information changes the inference model. The ten surviving domains do not establish joint feasibility, an optimal noise threshold or alternate fields.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':4,'unsuccessful_recorded_commands':0,
 'retained_limited_trials':'The first shared probe uses the default HiGHS route. Its lower-bound solves for targets 32 and 361 reach their 90-second limits; those two certificates retain valid zero-multiplier box bounds. Upper-bound proposals complete, and the probe certifies coefficient 32.',
 'solver_change':'The later instrument uses highs-ipm with a 15-second limit. All 48 requested solves finish successfully. Eight already supplied opposite box bounds avoid unnecessary optimization after a singleton is established.',
 'certification_policy':'Any rational signed combination is eligible for direct interval validation. Solver success, time limits, feasibility tolerances and claimed optimality are never proofs.',
 'continuation_scope':'First-order ordinate errors are shared across rows; absolute curvature and omitted-tail allowances remain separate. Combining curvature or introducing common quadratic displacements with cubic remainders is a new explicit gate.',
 'history_policy':'Earlier dated packages and previously pinned instruments remain byte-identical. No global completion or exhaustion is asserted.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Same pinned runtime. HiGHS interior-point proposals run under SciPy 1.17.0; analytic interval and integer certificates decide every inference.';write('Runtime.json',runtime)
sources=read(PRIOR/'Primary_Sources.json');sources['recorded_utc']=now
sources['sources'].append({'url':'https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs-ipm.html',
 'use':'Interior-point route, inequality marginals and solver status/time-limit semantics. The live manual is version 1.18.0; executed version 1.17.0 is pinned separately. No proof depends on solver correctness.'})
sources['scope']='Inherited analytic source mapping plus the official optimizer interface. New Taylor, shared-coordinate support and signed-combination proofs are derived directly in SHARED_README.md.';write('Primary_Sources.json',sources)
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Shared ordinate error delta 2026-09-13','recorded_utc':now,
 'baseline_branches':116,'branches_total':116,'new_branches':[],'advanced_existing_branches':['R12','R13','K04'],
 'replay_scope':'Marginal control, retained limited probe, full shared-error duals, 160/224-bit replay, exact integer objectives, symbolic and 80-digit derivative/center checks.',
 'next_priority':['R12/R13: combine signed curvature bounds or introduce common quadratic displacements with certified cubic remainders',
 'R12/R13: test the ten remaining domains at radius 5e-3 with noise-aware widths, linked tails and certified combinations',
 'R13/R14: distinguish bound limitations from joint feasibility; retain or separate explicit models of the chosen finite relaxation',
 'R14/P05: pursue the original 48 unresolved local-factor square coefficients and distinguish residue degrees from ramification',
 'R13/R07: statistical calibration independent of deterministic coefficient recovery',
 'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates',
 'K02/K05: private corpus and historical-run identities']})
updates={
 'R12':('shared_ordinate_linearization_and_remainders_certified',
   'A common displacement coordinate for each of 7602 certified ordinates links all 455 retained measurements. Per-row interval Taylor remainders make the linearization rigorous. At extra radius 5e-3, signed combinations identify 81 of 91 targets, while independent-row optimization remains at 73. All shared decisions agree at 160 and 224 bits.',
   'Retain shared curvature or quadratic displacements with certified cubic remainders, and use uncertainty-aware widths. Keep fixed membership and sufficient bounds distinct from optimal precision thresholds or perturbed-field spectra.'),
 'R13':('eight_additional_coefficients_from_certified_error_cancellation',
   'Shared-error certificates identify 32,257,269,271,281,283,311,313 and remove further candidates at 125,243,343. The ten remaining targets are 64,81,125,128,243,256,289,343,359,361. Thirty-six marginal certificates and 120 shared-certificate replays across two precisions receive exact integer objective checks; no arithmetic oracle seeds inference.',
   'Test stronger common-error and tail constraints, noise-aware measurements and explicit feasible or separating witnesses. Surviving coefficient domains have not been proved jointly feasible or realized by another field.'),
 'K04':('ongoing_delta_with_shared_error_certificates_and_limited_trials',
   'Preserve all 116 branches and the unchanged 363-event prefix, adding three events to reach 366. Four successful commands retain two limited LP trials, 48 successful main solves, exact objective replay, 75 independent derivative cases, two full center sums and three rejected omissions.',
   'Continue append-only evidence-backed deltas and independent challenges across the full research queue without global completion or exhaustion.')}
evidence={'R12':['Shared_Audits.zip','Shared_Audit.json','Shared_Summary.json'],
 'R13':['Shared_Audits.zip','Shared_Audit.json','Shared_Summary.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-shared-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result_text,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result_text,continuation_condition=gate,assessment_this_pass='fresh_shared_ordinate_and_dual_audit')
        b['new_evidence']=[prefix+n for n in evidence[b['id']]]
        b['verification_routes']+=['Common ordinate displacement model with interval Taylor remainders','Rational signed row combinations and full coefficient-residual support',
            'Independent outward fixed-grid integer objectives at two interval precisions','Symbolic second derivative and 80-digit numerical derivative/center checks']
        if b['id'] in ['R12','R13']:
            b['shared_assumptions_and_scope']='Inherited field invariants, finite zero certificates, explicit formula and unconditional tails. Existing certified spectral domains seed inference. Common first-order errors are retained; curvature and tail allowances remain separate. The ten survivors are not established feasible vectors or alternate fields.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=363
for bid in ['R12','R13','K04']:
    b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    event={'sequence':sequence,'utc':now,'release':q['release'],'kind':'shared_ordinate_evidence_advanced','branch_id':bid,
        'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(event,sort_keys=True,separators=(',',':')).encode());event['event_sha256']=last;events+=(json.dumps(event,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dedekind_shared_ordinate.py','dedekind_shared_recovery.py','dedekind_shared_audit.py','verify_shared_delta.py','SHARED_README.md']
deps=['dedekind_coupled_recovery.py','dedekind_coupled_dual.py','dedekind_coupled_dual_refine.py','dedekind_coupled_audit.py',
      'verify_ordinate_delta.py','source_requirements.txt','ORDINATE_README.md','COUPLED_README.md','RECOVERY_README.md']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
 'scope':'New shared-ordinate instruments; all earlier pinned source and dated evidence bytes preserved.'}
write('Source_Inventory.json',inventory)
entries=[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]
entries.extend((p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',Path(__file__).absolute()]);archive('Source_Snapshot.zip',entries)
files={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for name in new_names:
    path=CODE/name;raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
 'scope':'Manifest and verification result excluded to avoid self-reference; preceding checkpoint verified recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':len(q['branches']),'events':sequence,
 'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
