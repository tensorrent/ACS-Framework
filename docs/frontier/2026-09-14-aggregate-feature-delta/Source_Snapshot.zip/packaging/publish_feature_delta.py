from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-feature-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_feature_delta import summarize,FAILURES
OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
documents=['Feature_Collision_Proposals.json','Local_Slice_Proposal.json','Local_Slice_Proposal_v2.json','Local_Slice_Contraction.json','Original_Export_Audit.json','Corrected_Export_Audit.json','Enlarged_Slice_Proposal.json','Enlarged_Slice_Certificate.json','Independent_Feature_Audit.json','Adversary_Audit.json','Lean_Check.json','Lean_Check_after_acquisition.json','Lean_Check_v2.json','Runtime_Acquisition.json','Source_Acquisition.json','Launch_Failure.json','Small_Slice_Certificate.json','Small_Independent_Audit.json','Observable_Boundary.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
cert,small,checked,adv,extra,formal=[read(BASE/n) for n in ['Enlarged_Slice_Certificate.json','Small_Slice_Certificate.json','Independent_Feature_Audit.json','Adversary_Audit.json','Observable_Boundary.json','Lean_Check_v2.json']]
summary=summarize(cert,small,checked,adv,extra,formal)
write('Feature_Collision_Summary.json',{'recorded_utc':now,'result':'Two actual fields share exactly the same seventeen finite Gaussian features at a radius strictly below the full observed-point-list ambiguity bound.',
 'derived_results':summary,'actual_fields':'A=Q(sqrt(2),sqrt(-3)) and B=Q(sqrt(-2),sqrt(-3)); the complete metadata class and finite source spectra are inherited.',
 'proof':'A rational center and preconditioner define a closed correction box. Direct real interval Jacobians and an independent complex Taylor calculation prove a contracting self-map. Banach and nonsingularity give an exact feature-equation zero. Rational source-to-observation inclusions make the witness uniform over both precision versions of the true-root enclosures.',
 'feature_release':'Only the seventeen finite sums are released. The complete22-entry populations are selected before coordinate errors and every entry/multiplicity remains. Raw coordinates, cumulative counts, finite moments and unrecorded tails are not included.',
 'radii':'The main construction uses epsilon=1e-6 and r=U-epsilon, strictly below L. An earlier epsilon=1e-12 construction is also independently verified. Neither is asserted optimal.',
 'witness_boundaries':'Interior counts1/2, a rational moment, an additional center37 Gaussian and a different-width center2 Gaussian distinguish this particular witness. This does not establish uniform identification after augmenting the release; other collisions may exist.',
 'formal_scope':'Six Lean lemmas check interval errors, a self-map criterion and the core Banach-to-zero logic. The calculus/row-norm, ball-arithmetic, modular-matrix, field-classification and spectral-completeness bridges remain written/computational.',
 'next_gate':'Use validated continuation or other slices to improve radii, include additional observables jointly, and relate local Jacobian rank to the number of measurements. Maintain all broader ACS questions and private-input gates without a global completion claim.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==18 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']]+[(BASE/'Launch_Failure.json','unreceipted-launch/Launch_Failure.json')]+[(BASE/'audit-corrected-local-export'/f,'unreceipted-launch/'+f) for f in ['stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check_after_acquisition.json','Lean_Check_v2.json','Lean_Check_v2.olean']]+[(CODE/'proofs'/n,n) for n in ['FeatureContraction.lean','FeatureContraction_v2.lean']])
write('Development_Notes.json',{'recorded_commands':18,'successful_commands':14,'failed_commands':4,'separately_recorded_launch_failures':1,
 'failures':[{'receipt':'audit-original-local-export','result':'Independent complex reconstruction rejects the original post-solve double-application residual and preconditioner reports. Corrected source is separate and passes.'},
             {'receipt':'feature-contraction-lean','result':'Missing compiled Contracting.olean dependency. The pinned mathlib cache was acquired without changing the toolchain, package manifest or source revision.'},
             {'receipt':'feature-contraction-lean-after-acquisition','result':'The same source then fails on out-of-scope nonnegative-real notation. Separate FeatureContraction_v2.lean names NNReal explicitly and passes all six lemmas.'},
             {'receipt':'overextended-feature-slice-proposal','result':'The epsilon5e-6 local Newton attempt raises a numerically singular Jacobian error; this is not a global nonexistence result.'}],
 'manual_launch_failure':'Launch_Failure.json distinguishes the assistant interpreter-path typo from actual runner receipts. The process never launched; empty streams and the observed tool error are retained.',
 'canonical_Lean_source':'code/frontier_verification/proofs/FeatureContraction_v2.lean','source_policy':'Executed sources, failed reports and original prototypes are immutable. The final recursive verifier runs after packaging with a separate external receipt. Exploratory replay excludes clock fields from comparisons, preserves fresh outputs, and uses original clock-bearing input bytes for downstream recorded hashes.',
 'shared_infrastructure':'Independent formulations still share FLINT ball arithmetic, Python and inherited field/spectral evidence. Modular nonsingularity and exact Fraction endpoint checks supply distinct arithmetic routes.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned Python and numerical packages. Acquired the missing compiled Banach fixed-point module and its dependencies for the existing Lean/mathlib revision. Six new generic lemmas pass. No new source zeros or Python package versions.')
for key,package in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(package)
runtime['new_compiled_module']='Mathlib.Topology.MetricSpace.Contracting';runtime['module_olean_sha256']=read(BASE/'Runtime_Acquisition.json')['module_olean_sha256'];write('Runtime.json',runtime)
paths=[PRIOR/'Equal_Population_Inputs.zip',PRIOR/'Equal_Population_Decoder.json',PRIOR/'Verification.json',PRIOR/'Research_Queue.json',PRIOR/'Branch_Events.jsonl',CLASS/'Full_Quartic_Class.json',CLASS/'Full_Class_Audit.json',PAIR/'Pair_Arithmetic.json']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'The complete two-field metadata class and complete finite source populations are inherited and recursively verified; both root-file precision variants are used in the coordinate audit.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [CLASS/'Primary_Sources.json',PAIR/'Primary_Sources.json']},'new_source_record':'Source_Acquisition.json','runtime_acquisition_record':'Runtime_Acquisition.json','scope':'Mathlib4 Banach documentation and the Arb author usage guide were retrieved; the exact pinned module is verified against its local git object. Direct FLINT pages returned403 and are marked as search-excerpt access only. No third-party PDFs are redistributed. New analytic identities and interval arguments are derived and checked locally.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Actual finite Gaussian feature ambiguity delta2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
 replay_scope='Fresh actual-source contraction certificates, complex Taylor and modular determinant audits, polynomial arithmetic, omitted-observable boundaries,35mutations and6Leanlemmas; preserved numerical and runtime failures.',
 next_priority=['R12/R13/R14: validate augmented feature releases, include the finite moment or additional kernels jointly, and improve actual-source ambiguity bounds with validated continuation','R15: connect feature count, Jacobian rank and local identifiability; formalize remaining calculus and arithmetic bridges','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('finite_feature_release_with_explicit_acquisition_and_omission_boundaries','A precise release of17finite Gaussian sums admits an actual common observation below the full-point-list ambiguity threshold. The complete22-entry source population is selected before noise; all entries remain. Interior counts and three omitted statistics distinguish this witness.','Audit joint releases with the finite rational moment, extra centers or widths. Derive any infinite-tail contracts separately and retain complete-source provenance.'),
 'R13':('exact_arithmetic_ambiguity_at_an_actual_common_feature_vector','Both fields in the complete metadata class realize the same finite Gaussian feature vector at r=U-1e-6<L. Exactly456of604coefficient values stay fixed and148are ambiguous. Independent polynomial factorizations verify both arithmetic vectors.','Find stronger recovery or ambiguity results under augmented observables and larger classes. Keep finite-feature equality separate from tail-corrected explicit-formula and infinite-spectrum claims.'),
 'R14':('strict_feature_information_loss_certified_by_two_existence_routes','A closed17-variable correction box contains an exact feature-equation root. Direct real interval Jacobians and independent complex Taylor bounds prove self-mapping contraction; rational source inclusions and modular preconditioner nonsingularity give actual-field witnesses. The critical split grows from1e-12to1e-6.','Use validated continuation or alternative slices to improve the radius and study more released features. The failed epsilon5e-6 Newton attempt does not prove nonexistence or an optimal threshold.'),
 'R15':('independent_fixed_point_source_and_failure_audits','Two source precisions satisfy176independent scalar coordinate inequalities; complex second derivatives and modular determinant37610mod65537 independently support the main witness.35mutations reject, four binary64 zero-margin errors are exposed, and six Lean lemmas compile.','Formalize the calculus/row-norm and matrix/source bridges; verify augmented-feature collisions or local identifiability. Retain the independently rejected double-application export and all runtime/solver failures.'),
 'K04':('ongoing_delta_with_interval_existence_and_precise_failure_provenance','Preserve117branches and433events, appendfive. Eighteen recorded runs comprise14successes and4failures, plus one separately documented pre-launch typo. Source snapshots, inherited hashes and exact continuation gates distinguish proof from numerical proposals.','Continue justified research deltas across the full ACS program without global completion, preserving all assumptions, originals, failures, sources and private-input requirements.')}
prefix=str(OUT.relative_to(ROOT))+'/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_actual_feature_collision_audit')
  b['new_evidence']=[prefix+n for n in ['Feature_Collision_Summary.json','Enlarged_Slice_Certificate.json','Independent_Feature_Audit.json','Small_Slice_Certificate.json','Small_Independent_Audit.json','Observable_Boundary.json','Adversary_Audit.json','Original_Export_Audit.json','Corrected_Export_Audit.json','Lean_Check_v2.json']]
  b['verification_routes']+=['Closed-box real interval Jacobian contraction','Independent complex Taylor bounds and exact modular determinant','Rational source-to-observation inclusions at two source precisions','Independent local polynomial coefficient vectors','Thirty-five semantic mutations and four exact-versus-binary64 margin controls','Six Lean interval/self-map/Banach-to-zero lemmas']
  b['shared_assumptions_and_scope']='Inherited complete two-field metadata class and finite source spectra;22entries selected before coordinate noise and preserved. Release only17finite Gaussian sums. Exact feature equality at r=U-1e-6<L does not imply equality of moments, tails or full point lists. Both interval formulations share FLINT. The complete arithmetic and calculus bridges are not fully Lean formalized.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=433
for bid in q['advanced_existing_branches']:
 b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'actual_finite_feature_collision_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Actual finite Gaussian feature ambiguity — 14 September 2026

Two actual fields can produce **exactly the same17finite Gaussian features** at radius `r=U-1e-6`, strictly below the certified lower bound L for full-point-list ambiguity. The radius is approximately **0.5732763345123776**. Closed-box existence proofs replace a mere small-residual claim.

The [proof and reproduction guide](../../../code/frontier_verification/FEATURE_COLLISION_README.md) derives the coordinate bounds, self-map contraction, independent Taylor certificate, arithmetic consequences and observation limits. The [previous checkpoint](../2026-09-14-aggregate-equal-population-delta/README.md) supplies complete22-entry prefixes and the sharp full-list/count threshold.

- [Results and continuation gates](Feature_Collision_Summary.json).
- [Main numerical proposal](Enlarged_Slice_Proposal.json), [actual existence certificate](Enlarged_Slice_Certificate.json) and [independent complex Taylor, modular determinant and arithmetic audit](Independent_Feature_Audit.json).
- [Earlier smaller certificate](Small_Slice_Certificate.json) and [its independent audit](Small_Independent_Audit.json), preserving the transition from critical split1e-12to1e-6.
- [Omitted-observable boundary](Observable_Boundary.json): interior counts1/2, a rational moment, an additional center37 and a changed-width center2 distinguish this witness; augmented-release identifiability remains open.
- [Thirty-five semantic mutations and exact-zero margin controls](Adversary_Audit.json).
- [Original faulty export](Local_Slice_Proposal.json), [corrected export](Local_Slice_Proposal_v2.json), [independent original rejection](Original_Export_Audit.json) and [corrected acceptance](Corrected_Export_Audit.json).
- [Initial binary64 proposals](Feature_Collision_Proposals.json) and [initial interval prototype](Local_Slice_Contraction.json), with their exact source versions retained.
- [Six successful Lean lemmas](Lean_Check_v2.json), [missing-dependency failure](Lean_Check.json), [subsequent notation failure](Lean_Check_after_acquisition.json) and [sources/compiled artifact](Lean_Artifacts.zip).
- [Runtime acquisition](Runtime_Acquisition.json), [runtime versions](Runtime.json), [primary-source acquisition](Source_Acquisition.json), [inherited source records](Primary_Sources.json) and [inherited inputs](Inherited_Inputs.json).
- [Eighteen runner receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [separate pre-launch failure](Launch_Failure.json), [development notes](Development_Notes.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All117research branches](Research_Queue.json) and [438-event ledger](Branch_Events.jsonl), preserving the preceding433events byte for byte.

Select the complete positive source population below19.5 before independent bounded coordinate errors; preserve every entry and multiplicity. Release only17finite sums `2 sum exp(-y_i^2/25) cos(log(m)y_i)` for the specified prime-power centers through31. Raw coordinates, count profiles, rational moments and unknown tails are absent. The source fields and complete finite spectra are inherited certified examples, not self-authenticated arbitrary observations.

The exact witness is obtained by splitting the critical coordinates, adjusting17other A coordinates, and proving that `w-RF(w)` contracts a closed correction box of radius1e-100 into itself. Nonsingularity of the rational R gives an exact zero of F. The producer uses real interval Jacobians at512/768bits; the independent auditor uses complex second-derivative bounds at640bits and proves detR=37610mod65537. Both retain shared FLINT arithmetic and inherited source premises. Eighty-eight root-box checks correspond to176independent scalar coordinate inequalities. Four exact-zero critical margins would be falsely negative in binary64.

Both actual fields share the feature vector, while their full point lists and interior counts differ. Exactly456of604tracked Euler coefficients remain fixed and148are ambiguous, including3,7,19,27,31. Independent arithmetic uses1128polynomial factorizations per audit to compare1208coefficient values. The six Lean lemmas include the generic Banach-to-root logical step; the full calculus/arithmetic/spectral bridge is not claimed fully formalized.

The original local export's double-application reporting bug is preserved and independently rejected. A larger5e-6Newton attempt fails with a numerically singular Jacobian, which does not prove nonexistence. Eighteen recorded commands include14successes and4failures, plus a separately transcribed launcher typo that failed before the scientific process began.

The strict gap below the full-list threshold is certified, but the optimal finite-feature threshold is not known. Next, audit augmented feature releases and validated continuation, while preserving the broader questions about operators, infinite arithmetic/real parts, topology, physical interpretation, formalization and private inputs. No global completion is claimed.
''')
names=sorted({p.name for p in CODE.glob('dedekind_feature_*.py')}|{'check_feature_contraction_lean.py','verify_aggregate_feature_delta.py','FEATURE_COLLISION_README.md','proofs/FeatureContraction.lean','proofs/FeatureContraction_v2.lean'})
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
mathlib=ROOT.parent/'acs-research/lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/'Mathlib/Topology/MetricSpace/Contracting.lean','external/Mathlib/Topology/MetricSpace/Contracting.lean'),(mathlib/'LICENSE','external/mathlib-LICENSE')]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'scope':'All new instruments, two immutable Lean versions and proof guide, transitive local Python imports, frozen exploratory sources and the pinned Mathlib Banach source with its license. Canonical Lean source is FeatureContraction_v2.lean.'}
write('Source_Inventory.json',inventory)
exploration=['run_recorded.py','propose_feature_collision.py','propose_local_slice.py','propose_local_slice_v2.py','certify_local_slice.py','audit_local_slice_export.py','acquire_contraction_module.py']
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'exploration/'+n) for n in exploration]+external+[(Path(__file__),'packaging/'+Path(__file__).name)])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. Prior checkpoints are recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 actual finite-feature ambiguity delta](2026-09-14-aggregate-feature-delta/README.md): two actual fields share seventeen Gaussian features below the full-point-list threshold, certified by independent contraction proofs, arithmetic audits and six Lean lemmas.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-equal-population-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-feature-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':18,'successes':14,'failed_commands':4,'separate_launch_failure':1,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
