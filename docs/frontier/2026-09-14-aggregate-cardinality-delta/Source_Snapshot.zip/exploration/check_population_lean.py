import hashlib,json,os,subprocess
from pathlib import Path
BASE=Path(__file__).absolute().parent;RESEARCH=BASE.parent
PROJECT=RESEARCH/'lean-audit/withMathlib';BIN=RESEARCH/'runtime/lean-4.34.0-rc2-darwin_aarch64/bin'
SOURCE=BASE/'PopulationObservation.lean';ARTIFACT=BASE/'PopulationObservation.olean'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
command=[str(BIN/'lake'),'env','lean','-o',str(ARTIFACT),str(SOURCE)]
p=subprocess.run(command,cwd=PROJECT,env={**os.environ,'PATH':str(BIN)+':'+os.environ.get('PATH','')},text=True,capture_output=True)
print(p.stdout);print(p.stderr)
assert p.returncode==0 and 'sorryAx' not in p.stdout+p.stderr
theorems=['fixed_population_length','unequal_populations_disjoint','uncrossing','common_observation_separation','interval_center']
assert all('PopulationObservation.'+n in p.stdout for n in theorems)
r={'status':'passed','source_sha256':sha(SOURCE),'driver_sha256':sha(Path(__file__)),
   'lake_manifest_sha256':sha(PROJECT/'lake-manifest.json'),'artifact_sha256':sha(ARTIFACT),
   'theorems':theorems,'command':command,'stdout':p.stdout,'stderr':p.stderr,
   'scope':'Five elementary list and real-interval lemmas only. This does not formalize the quartic classification, certified zero computations, whole sorted-matching algorithm or any global ACS theorem.'}
(BASE/'Population_Lean_Audit.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':'passed','theorems':5,'artifact_sha256':r['artifact_sha256']}))
