from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-cardinality-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta'
INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_cardinality_delta import summarize,domains
OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
documents=['Population_Observation_Proposal.json','Population_Proposal_Audit.json','Population_Decoder.json','Population_Matching.json','Population_Audit.json','Adversary_Audit.json','Critical_Gap_Audit.json','Population_Window_Audit.json','Lean_Check.json','Window_Lean_Check.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
pop,matched,checked,adv,gap,windowed,formal,window_formal=[read(BASE/name) for name in ['Population_Decoder.json','Population_Matching.json','Population_Audit.json','Adversary_Audit.json','Critical_Gap_Audit.json','Population_Window_Audit.json','Lean_Check.json','Window_Lean_Check.json']]
summary=summarize(pop,matched,checked,adv,gap,windowed,formal,window_formal)
write('Common_Observation_Domains.json',domains(pop,matched,windowed))
write('Population_Summary.json',{'recorded_utc':now,
 'result':'Preserved source-list length identifies the complete two-field class independently of coordinate error. Allowing one missing root, or instead selecting the observed window after coordinate noise with no arbitrary deletions, yields actual-field ambiguity at exactly half the second-root gap.',
 'metadata':['degree four','absolute field discriminant 576','signature (0,2)'],
 'metadata_class':'The preceding source-backed classification derives exactly two fields without a supplied Galois-group label. That proof and finite spectral completeness are inherited.',
 'preserved_population_model':'The complete source population is selected through20 before coordinate errors. Entries and multiplicities are preserved; coordinate values and their order may change. Length23 selectsA and22 selectsB, independently of the error radius.',
 'one_deletion_model':'At most one source entry may be deleted per field, no insertions, independent bounded absolute errors on retained entries. A common population must have22entries, so A losesone and B losesnone.',
 'post_noise_window_model':'Every positive source zero ordinate is transformed with bounded absolute error, then every transformed entry inside the open window(0,20) is observed. No arbitrary insertions/deletions. Protected first-two ranks yield the lower bound; moving A last recorded root above20 and leaving all unrecorded tail entries unchanged gives a complete common-observation construction.',
 'exact_threshold_formula':'(second positive ordinate of A - second positive ordinate of B)/2',
 'approximate_radius_display_only':'0.5732773345123776','exact_numerical_bounds':'Use the rational endpoints in derived_results; their width is2e-30. The symbolic identity does not collapse the numerical interval.',
 'arithmetic_at_common_observation':'Both actual fields are compatible and the metadata class contains no others:456tracked coefficients stayfixed and148areambiguous, including targets3,7,19,27,31.',
 'derived_results':summary,'new_roots_computed':0,'new_measurement_rows':0,
 'proof_scope':'Eight elementary list/real-interval lemmas are Lean-checked. The complete quartic classification, spectral certificates, inversion-removal matching proof, dynamic-program correctness and retained-rank window argument are not claimed as complete Lean formalizations.',
 'input_scope':'Completeness/preservation declarations are not self-authenticating. Two actual false-premise population misclassifications are preserved. Window observation is an ideal complete acquisition model; physical detectors and unmodeled missed/extra entries require separate contracts.',
 'next_gate':'Extend error norms, edit budgets, cutoffs and field classes; build equal-population benchmarks; formalize the remaining matching/arithmetic arguments. Preserve broader ACS research without global completion.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==13 and sum(r['returncode']==0 for r in receipts.values())==11
assert sorted(n for n,r in receipts.items() if r['returncode'])==['independent-population-proposal','population-lean-lemmas']
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean','Population_Lean_Audit.json','Window_Lean_Check.json','Window_Lean_Check.olean']]+[(CODE/'proofs'/n,n) for n in ['PopulationObservation.lean','WindowCensoring.lean']])
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':13,'successful_commands':11,'failed_commands':2,
 'recording_scope':'Five initial exploratory/development runs and eight portable scientific/formal runs. Packaging and final recursive verification are separate.',
 'failures':[{'command':'independent-population-proposal','cause':'The exact minimax bounds matched, but the exploratory audit assumed width<1e-30. The actual exported interval width is2e-30 at both nominal precisions.','correction':'Separate audit_population_proposal_v2.py retains the exact bounds and reports their actual gap; the failed source and receipt remain unchanged.'},
             {'command':'population-lean-lemmas','cause':'Lean refused a source outside its default package root before checking the theorem.','correction':'Separate check_population_lean_v2.py adds the documented -R source-root option; the theorem source is unchanged.'}],
 'freeze_boundary':'All executed sources and scientific outputs are preserved. Portable repository instruments are separately recorded versions; old scratch proposals, audits, drivers and theorem source remain in the source snapshot. Earlier dated checkpoints are unchanged.',
 'method_delta':'Separate cardinality from coordinate information; replace necessary coefficient-relaxation feasibility with common finite observations realized by two actual fields; identify the exact critical-root expression and extend the construction to post-noise window selection.',
 'independence':'Factor-contour counts versus held-out aggregate lengths; character coefficients versus1128local polynomial factorizations; deletion enumeration versus minimax dynamic programming and boolean reachability;41796literal finite matchings; pair certificates versus raw interval/doubled-inequality reconstruction; eight Lean lemmas. Exact algebra shares Python/SymPy in places, and source spectral certificates remain inherited.',
 'negative_controls':'A false preservation/completeness claim can misclassify a deleted A population as B; the scalar selector cannot authenticate its premise. A zip-only endpoint loop accepts a21entry witness that violates the deletion budget. Dropping order invalidates uncrossing.',
 'critical_gap_delta':'286strict comparisons show that the second-root gap exactly controls six optimal deletions. Five further window mutations and198inequalities protect source ranks and construct a boundary exit. No unrecorded tail roots move in the upper witness.',
 'window_count_semantics':'The window artifact source-population sizes23/22 refer to the tracked entries originally through20. Those entries still exist after noise; the visible window counts become22/22. The full positive source families are not claimed finite.',
 'formal_scope':'Eight elementary lemmas in two modules are compiled. Full number theory, analytic completeness, finite inversion removal, DP correctness and retained-rank logic remain separately stated written/computational arguments.',
 'history_policy':'Keep all117branch IDs, preserve the423-event byte prefix, appendfiveevents and leave the global research goal active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Inherited pinned Python3.12.14, NumPy2.3.5, SciPy1.17.0, SymPy1.14.0, mpmath1.3.0 and python-flint0.9.0/FLINT3.6.0. New computations use exact integer/Fraction arithmetic and existing polynomial methods. Eight elementary theorems compiled with inherited Lean4.34.0-rc2 and pinned mathlib. No new package installation or root computation.';write('Runtime.json',runtime)
paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Input_Provenance.json']]+[PAIR/n for n in ['Pair_Arithmetic.json','Pair_Spectra.zip','Primary_Sources.json']]+[PRIOR/n for n in ['Full_Quartic_Class.json','Full_Class_Audit.json','Primary_Sources.json','Manifest.json','Verification.json']]
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'The complete metadata class and all finite source zero intervals/completeness certificates are inherited and recursively verified. No external unknown-field observation is asserted complete from its count alone.'})
write('Primary_Sources.json',{'new_downloads':0,'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',PAIR/'Primary_Sources.json']},'scope':'The number-theoretic and analytic premises retain their primary-source references in the inherited records and preceding proof guide. New elementary cardinality, matching, interval and window arguments are derived in the accompanying proof guide and supported by the specified Lean modules.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Population information and actual window-ambiguity delta2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
 replay_scope='Fresh population-only selection, actual common observations, independent arithmetic and minimax matching, strict critical-gap certificates, post-noise window construction,34mutations and8Leanlemmas.',
 next_priority=['R12/R13/R14: extend acquisition contracts, edit budgets, error norms and cutoffs while preserving actual-field feasibility','R15: construct equal-population matched-invariant fields and formalize full matching/arithmetic bridges','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('population_and_post_noise_window_contracts_separated','Preserved source cardinality23/22 selects the complete field class for any coordinate errors under that contract. Seventy-two shift/permutation controls and four all-at-ten controls retain selection. Under complete window selection after noise, one A entry can exit while all unrecorded tail entries remain unchanged.','Examine other source cutoffs and error norms, distinguish ideal complete window acquisition from unmodeled missed/extra observations, and keep explicit completeness provenance.'),
 'R13':('exact_arithmetic_domains_at_actual_common_observations','Population-only selection fixes all604tracked coefficients;1128independent polynomial factorizations verify the arithmetic. At common one-deletion and windowed observations, exactly456coefficients remainfixed and148areambiguous, including targets3,7,19,27,31.','Study recovery in larger or equal-population metadata classes and other observation models; retain prior Gaussian certificates as results of their stated deduction methods.'),
 'R14':('actual_field_ambiguity_and_exact_critical_root_threshold','Two actual fields realize the same22entry finite observation. The threshold under one deletion and under post-noise open-window selection without arbitrary deletions is exactly half their second-positive-root difference, with a2e-30numeric bracket. Six A deletion indices are exactlyoptimal;286strict comparisons verify dominance.','Extend actual-field ambiguity/separation beyond this class and model, including other edit budgets and norms. Formalize the complete inversion-removal, DP and retained-rank arguments.'),
 'R15':('window_boundary_and_population_provenance_controls','Minimax DP, boolean reachability,1012pair rows,176matching endpoint checks,198window inequalities and41796literal finite matchings agree. Thirty-four mutations are rejected; a zip-only false acceptance and two false-preservation misclassifications remain explicit. Eight elementary Lean lemmas compile.','Build matched-count benchmark fields, test additional acquisition contracts and avoid treating declared completeness or precision labels as independent evidence.'),
 'K04':('ongoing_delta_with_actual_witnesses_and_preserved_development_failures','Preserve117branches and423events, appendfive. Thirteen recorded commands includeeleven successes andtwo preserved failures resolved in separate versions. Both observation models, exact symbolic and numerical threshold scopes, and formalization limits remain explicit.','Continue evidence-backed research deltas with immutable sources, exact provenance, independent methods and concrete next gates; no global completion or exhaustion.')}
prefix=str(OUT.relative_to(ROOT))+'/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_population_and_actual_window_ambiguity_audit')
  b['new_evidence']=[prefix+n for n in ['Population_Summary.json','Population_Decoder.json','Population_Matching.json','Population_Audit.json','Critical_Gap_Audit.json','Population_Window_Audit.json','Common_Observation_Domains.json','Adversary_Audit.json','Lean_Check.json','Window_Lean_Check.json']]
  b['verification_routes']+=['Preserved cardinality and coordinate-erasure controls','Independent local polynomial arithmetic','Exhaustive deletion certificates versus minimax DP and boolean reachability','Literal arbitrary finite matchings and actual zip-truncation counterexample','Strict critical-gap dominance and complete window noise-map construction','Eight elementary Lean lemmas and34semantic mutations']
  b['shared_assumptions_and_scope']='Complete two-field metadata class ofdegree4,signature(0,2),discriminant576; inherited finite spectral completeness. Distinguish preserved population,atmostone deletion, and complete post-noise open-window observation. The latter uses no arbitrarydeletions and leaves the unknown tail unchanged in its witness. Exact root-gap identity has a2e-30numeric enclosure; broad arithmetic/matching proofs are not fully Lean formalized.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=423
for bid in q['advanced_existing_branches']:
 b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'population_and_actual_window_ambiguity_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Population information and actual window ambiguity — 14 September 2026

The benchmark fields can produce **the same 22 observed ordinates** after bounded coordinate error and selection of the open window(0,20), with **no arbitrary deletion allowance**. The exact threshold is half their second-positive-root difference, approximately 0.5732773345123776, enclosed by rational bounds of width 2e-30. A separate one-deletion model has the same threshold. A preserved source list instead retains counts 23/22, which identify the field independently of its coordinate values.

The [proof and reproduction guide](../../../code/frontier_verification/POPULATION_OBSERVATION_README.md) derives the matching theorem, exact critical-gap identity, protected-prefix window lower bound and complete common-observation construction. The [preceding checkpoint](../2026-09-14-aggregate-classification-delta/README.md) supplies the complete metadata class and source provenance.

- [Results and remaining gates](Population_Summary.json).
- [Population-only decoder](Population_Decoder.json):72 coordinate transformations,4 all-at-ten controls and 2 actual false-preservation counterexamples.
- [All 23 deletion cases and common observations](Population_Matching.json), with [independent arithmetic and matching audit](Population_Audit.json):1128 polynomial factorizations,1208 distinct-field coefficient comparisons,1012 matching pair rows,176endpoint checks and 8exact reachability boundaries.
- [Exact critical-root identity](Critical_Gap_Audit.json):286 strict comparisons prove that deleting any A index 17 through 22 (zero based) is exactlyoptimal; the second-root gap dominates all other pairs.
- [Coordinate noise followed by complete window selection](Population_Window_Audit.json):198exact inequalities protect each field's firsttwo roots and certify a boundary exit of A's last recorded root. All unrecorded positive ordinates stay unchanged outside the window, so no new root calculations are required.
- [Exact common-observation coefficient domains](Common_Observation_Domains.json):456 fixed values and 148 ambiguous values, including target indices 3,7,19,27,31. Both actual fields realize each stated common observation.
- [Semantic adversary and literal matching comparison](Adversary_Audit.json):25 mutations,543 finite problems and 41796 arbitrary indexed matchings. Critical-gap and window audits reject 4 and 5 additional mutations, for 34 total. A zip-only false acceptance is preserved.
- [Five population/matching Lean lemmas](Lean_Check.json), [three window Lean lemmas](Window_Lean_Check.json) and [sources/compiled artifacts](Lean_Artifacts.zip).
- [Original exploratory proposal](Population_Observation_Proposal.json), [corrected exploratory audit](Population_Proposal_Audit.json), [13execution receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip) and [development notes](Development_Notes.json), preserving both failures and their separately versioned corrections.
- [Runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json), [inherited primary-source records](Primary_Sources.json), [source inventory](Source_Inventory.json), [frozen source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [428-event ledger](Branch_Events.jsonl), preserving the preceding 423events byte for byte.

The complete metadata class consists of A=Q(sqrt(2),sqrt(-3)) and B=Q(sqrt(-2),sqrt(-3)), with degree 4,signature(0,2),discriminant 576. Individual coordinate precision is irrelevant when a complete preselected population retains every entry: list length alone distinguishes the fields. That statement changes once entries may be missing or the displayed window is selected after noise. Contract declarations cannot authenticate themselves; a false completeness/preservation premise can fool a scalar selector.

In the one-deletion model, a common list must contain 22entries, requiring one deletion from A and none from B. In the window model, no source entry is arbitrarily deleted: A's last recorded entry moves above 20, and the observer reports every remaining transformed entry inside(0,20). The full positive source families include the unchanged tail; source-prefix counts 23/22 must not be confused with total numbers of zeros. The explicit rational witnesses work at the certified upper bound; actual-root midpoints prove the exact symbolic threshold. Its numerical interval is not collapsed to a floating-point value.

Eight elementary lemmas are Lean-checked. Full field classification, spectral completeness, inversion removal, DP correctness and retained-rank arguments retain their written/computational proof scopes. Thirteen recorded scientific/development commands comprise eleven successes and two failures: an unsupported sub-1e-30 precision assertion and a missing Lean package-root option. Original sources and receipts are retained; separate corrections pass.

Next, extend cutoffs, edit budgets and error norms, construct equal-population matched-invariant fields, and formalize the remaining arguments. Other ACS branches, including natural operators, infinite arithmetic, topology, physical interpretation and private inputs, remain active. No global completion or exhaustion is claimed.
''')
names=sorted({p.name for p in CODE.glob('dedekind_population_*.py')}|{p.name for p in CODE.glob('check_population_*.py')}|{'verify_aggregate_cardinality_delta.py','POPULATION_OBSERVATION_README.md','proofs/PopulationObservation.lean','proofs/WindowCensoring.lean'})
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'scope':'Fresh portable instruments, two Lean modules and proof guide, with transitive local Python imports. Frozen exploratory sources and both failed versions are included separately; preceding checkpoints are recursively verified.'}
write('Source_Inventory.json',inventory)
exploration=['run_recorded.py','propose_population_observation.py','audit_population_proposal.py','audit_population_proposal_v2.py','check_population_lean.py','check_population_lean_v2.py','PopulationObservation.lean']
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'exploration/'+n) for n in exploration]+[(Path(__file__),'packaging/'+Path(__file__).name)])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before final replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoints verified recursively.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 population and actual window-ambiguity delta](2026-09-14-aggregate-cardinality-delta/README.md): preserved cardinality identifies the field; one missing root or post-noise window selection gives actual-field ambiguity at an exact critical-root threshold, with eight Lean lemmas and independent audits.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-classification-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-cardinality-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':13,'successes':11,'failures':2,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
