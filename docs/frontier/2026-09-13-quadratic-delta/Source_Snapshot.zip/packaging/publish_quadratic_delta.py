from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-quadratic-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-shared-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

names=['Quadratic_Frozen160.json','Quadratic_160.json','Conic_Probe160.json','Conic_Extended160.json','Quadratic_Union160.json']
archive('Quadratic_Audits.zip',[(BASE/n,n) for n in names])
for name in ['Quadratic_Audit.json','Quadratic_Numeric2.json']:(OUT/name).write_bytes((BASE/name).read_bytes())
(OUT/'Lean_Check.json').write_bytes((BASE/'Lean_Check5.json').read_bytes())
audit=read(BASE/'Quadratic_Audit.json');numeric=read(BASE/'Quadratic_Numeric2.json');union=read(BASE/'Quadratic_Union160.json')
result=next(c for c in union['cases'] if c['mode']=='quadratic')
assert audit['status']==numeric['status']=='passed' and result['unique_targets']==83
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==14 and sum(r['returncode']!=0 for r in receipts.values())==4
write('Execution_Receipts.json',receipts)
entries=[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']]
entries += [(BASE/n,n) for n in ['Lean_Check2.json','Lean_Check3.json','Lean_Check4.json','Lean_Check5.json','Lean_Check5.olean','Scalar_Diagnostic.json','Packaging_Failure.json','Verification_Initial.json']]
entries += [(p,'quadratic-lean1/'+p.name) for p in sorted((BASE/'quadratic-lean1').iterdir()) if p.is_file()]
archive('Execution_Artifacts.zip',entries)
seed=union['provenance']['seed_domains']
changes=[{'n':d['n'],'before':s['candidates'],'after':d['candidates']} for d,s in zip(result['domains'],seed) if d['candidates']!=s['candidates']]
write('Quadratic_Summary.json',{'recorded_utc':now,'height':2000,'additional_radius':'5e-3',
 'retained_measurements':455,'known_positive_ordinates':7602,'coefficient_support':604,'target_count':91,'prior_unique_targets':81,
 'frozen_prior_multiplier_counts':{c['mode']:c['unique_targets'] for c in read(BASE/'Quadratic_Frozen160.json')['cases']},
 'combined_proposal_control_counts':{c['mode']:c['unique_targets'] for c in union['cases']},
 'quadratic_unique_targets':83,'new_singletons':[d for d,s in zip(result['domains'],seed) if len(d['candidates'])==1 and len(s['candidates'])>1],
 'unresolved_targets':[d for d in result['domains'] if d['n']<=361 and len(d['candidates'])>1],
 'all_target_domain_changes':changes,'combined_proposals':100,'distinct_multiplier_combinations':15,
 'main_lp_certificates':52,'main_successful_lp_solves':50,'opposite_existing_box_bounds':2,'limited_conic_solves':2,
 'almost_solved_conic_solves':1,'successful_conic_solves':5,'certificate_evaluations_across_precisions':2392,
 'independent_derivative_cases':75,'independent_full_displaced_sums':2,'kernel_checked_scalar_theorems':10,
 'scope':'Same declared uncertainty and inherited analytic assumptions. Both the independent-square and exact quadratic controls identify 83. The exact square relation produces no additional singleton on this collection. Eight surviving target domains are not proved jointly feasible or realized by another field.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':14,'successful_recorded_commands':10,'unsuccessful_recorded_commands':4,'additional_launch_failures':1,
 'failures':[
 {'run':'quadratic-lean1','kind':'launch_failure_without_normal_receipt','result':'The runner was asked to execute the non-executable Python checker without its interpreter. Popen failed before the checker started. The launch failure and empty streams are retained.'},
 {'run':'quadratic-lean2','kind':'Lean_project_root','result':'Lean rejected the external absolute input path. The next checker copies the source into its declared project and checks byte identity.'},
 {'run':'quadratic-lean3','kind':'uncached_umbrella_import','result':'Mathlib.olean was unavailable. The source now imports the specific cached real and tactic modules.'},
 {'run':'quadratic-lean4','kind':'unfinished_scalar_proof','result':'The positivity tactic did not extract positivity of E from a conjunction. Explicit positive E and 2E hypotheses finish attainment. The failed source and sorryAx-bearing failed transcript remain separate from the successful source.'},
 {'run':'quadratic-independent-numeric','kind':'audit_expression_error','result':'The scalar numerical maximum used -d*y-e*y at the vertex, omitting the square. Exact rational evaluation in Scalar_Diagnostic.json confirms the certificate upper bound. The corrected full audit evaluates -d*y-e*y*y and also checks the exact midpoint maximum.'}],
 'limited_solver_trials':'Conic_Probe160 has two MaxTime statuses at 30 seconds; Conic_Extended160 has one AlmostSolved at 120 seconds. All eight conic proposals receive full interval and exact integer checks. Primal vectors remain unverified.',
 'control_interpretation':'Frozen prior multipliers remain at 81 for all three models. Newly optimized and combined proposals produce 81,83,83. The second-order model with a cubic remainder supports the gain; enforcing the exact square relation does not add a singleton on these runs.',
 'formal_scope':'Ten real scalar maximum and cone-geometry theorems are kernel checked. Taylor bounds, zero completeness, explicit formula and coefficient inference retain their existing analytic/computational status.',
 'packaging_failure':'An initial source archive attempted to include lakefile.lean; this project uses lakefile.toml. The failed packager source and Packaging_Failure.json are retained. This is separate from the fourteen computation/runtime/checker receipts.',
 'metadata_correction':'The inherited queue parent_checkpoint still named the older Dedekind checkpoint. This new queue points to its immediate shared-error predecessor. Earlier dated queues remain unchanged. Verification_Initial.json records the successful integrity check before this metadata correction; the final verifier additionally checks the parent pointer.',
 'history_policy':'Earlier dated packages and pinned instruments remain byte-identical. All 116 branches stay recorded. No global completion or exhaustion is asserted.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime.update({'clarabel':'0.11.1','cffi':'2.1.1','pycparser':'3.0','requirements':'code/frontier_verification/quadratic_requirements.txt'})
project=BASE.parent/'lean-audit/withMathlib';lake=read(project/'lake-manifest.json')
runtime['lean_toolchain']=(project/'lean-toolchain').read_text().strip()
runtime['mathlib_revision']=next(p['rev'] for p in lake['packages'] if p['name']=='mathlib')
runtime['lake_manifest_sha256']=sha((project/'lake-manifest.json').read_bytes())
runtime['scope']='Existing NumPy, SciPy and analytic packages remain pinned; Clarabel and two dependencies are additions. Lean uses the previously acquired toolchain and mathlib revision. Solver status is not a proof.';write('Runtime.json',runtime)
sources=read(PRIOR/'Primary_Sources.json');sources['recorded_utc']=now
sources['sources'] += [
 {'url':'https://clarabel.org/stable/python/getting_started_py/','use':'Conic Ax+s=b interface, solver settings and output statuses. Executed version 0.11.1 is pinned separately; proposals are independently validated.'},
 {'url':'https://clarabel.org/stable/api_cone_types/','use':'Lorentz cone convention t >= norm(x). The scalar squared encoding is independently derived and kernel checked.'},
 {'url':'https://pypi.org/project/clarabel/','use':'Clarabel 0.11.1 package distribution and runtime acquisition.'}]
sources['scope']='Inherited analytic sources plus official conic interface references. Scalar support, cubic remainder and complete certificate bounds are derived in QUADRATIC_README.md.';write('Primary_Sources.json',sources)
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Quadratic ordinate error delta 2026-09-13','recorded_utc':now,
 'parent_checkpoint':str((PRIOR/'Research_Queue.json').relative_to(ROOT)),
 'baseline_branches':116,'branches_total':116,'new_branches':[],'advanced_existing_branches':['R12','R13','K04'],
 'replay_scope':'Frozen, LP and conic proposals, three independently seeded error models, 160/224-bit interval and exact integer replay, symbolic/80-digit nonlinear checks, ten real scalar kernel theorems.',
 'next_priority':['R12/R13: select noise-aware measurement widths and tighter signed nonlinear error bounds for the eight surviving targets',
 'R12/R13: link omitted tails or jointly constrain ordinate powers; distinguish a stronger bound from an actual feasible nonlinear model',
 'R13/R14: independently validate or separate proposed integer models, retaining all 604 coefficients and every tail constraint',
 'R14/P05: pursue the original 48 unresolved local-factor square coefficients and distinguish residue degrees from ramification',
 'R13/R07: statistical calibration independent of deterministic coefficient recovery',
 'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates',
 'K02/K05: private corpus and historical-run identities']})
updates={
 'R12':('quadratic_ordinate_terms_cubic_remainders_and_scalar_maxima_certified',
  'Shared quadratic displacements with interval cubic remainders give a complete signed objective bound. Exact scalar maxima and their attainment, signed interval reduction and cone geometry receive ten kernel proofs. The 160/224-bit and exact integer audit validates 2392 retained objective evaluations.',
  'Choose uncertainty-aware widths and bound signed nonlinear sums or shared tails for the eight surviving targets. Scalar kernel proofs do not yet formalize Taylor bounds or the full spectral inference.'),
 'R13':('two_more_coefficients_identified_by_second_order_error_model',
  'At extra radius 5e-3, coefficients 289 and 359 are zero, raising 81 to 83 identified targets. Candidate sets narrow at 128,256,361. Independent-square and exact quadratic controls both reach 83; the conic probes give no extra singleton. Remaining targets are 64,81,125,128,243,256,343,361.',
  'Seek stronger measurements or independently certified feasible/separating models. Conic primal proposals and surviving integer domains are not feasibility or alternate-field certificates. Preserve the wider original local-factor and calibration gates.'),
 'K04':('ongoing_delta_with_quadratic_certificates_and_preserved_audit_failures',
  'All 116 branches and the 366-event byte prefix are preserved; three events bring the ledger to 369. Fourteen receipts retain ten successful and four unsuccessful commands, plus one separate launch failure. Preserve two conic time limits, one AlmostSolved result, source revisions, exact replay, 75 numerical cases, two full displaced sums and ten final kernel theorems.',
  'Continue append-only evidence-backed deltas and materially different challenges across the full queue without a global completion or exhaustion claim.')}
evidence={'R12':['Quadratic_Audits.zip','Quadratic_Audit.json','Quadratic_Numeric2.json','Lean_Check.json'],
 'R13':['Quadratic_Audits.zip','Quadratic_Audit.json','Quadratic_Summary.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-quadratic-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result_text,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result_text,continuation_condition=gate,assessment_this_pass='fresh_quadratic_ordinate_and_scalar_audit')
        b['new_evidence']=[prefix+n for n in evidence[b['id']]]
        b['verification_routes'] += ['Shared second-order ordinate coordinates and certified cubic remainders',
            'Exact scalar support and outward integer replay at two analytic precisions',
            'Independent symbolic third derivative and 80-digit full displaced sums',
            'Lean scalar maximum, attainment and cone geometry']
        if b['id'] in ['R12','R13']:
            b['shared_assumptions_and_scope']='Inherited field invariants, finite zero certificates, explicit formula, unconditional tails and previously certified domains. Quadratic terms share ordinate coordinates; cubic errors and tails remain conservative. No new singleton from the exact-square relation alone on the retained proposals; survivors are not established feasible.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=366
for bid in ['R12','R13','K04']:
    b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    event={'sequence':sequence,'utc':now,'release':q['release'],'kind':'quadratic_ordinate_evidence_advanced','branch_id':bid,
        'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(event,sort_keys=True,separators=(',',':')).encode());event['event_sha256']=last;events+=(json.dumps(event,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dedekind_quadratic_ordinate.py','dedekind_quadratic_recovery.py','dedekind_quadratic_conic.py',
 'dedekind_quadratic_union.py','dedekind_quadratic_audit.py','dedekind_quadratic_numeric.py','check_quadratic_lean.py',
 'proofs/QuadraticSupport.lean','quadratic_requirements.txt','verify_quadratic_delta.py','QUADRATIC_README.md']
deps=['dedekind_shared_ordinate.py','dedekind_shared_audit.py','dedekind_coupled_recovery.py','dedekind_coupled_audit.py',
 'verify_shared_delta.py','source_requirements.txt','SHARED_README.md','ORDINATE_README.md','COUPLED_README.md','RECOVERY_README.md']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
 'scope':'New quadratic instruments and source snapshots, including failed versions. Earlier pinned source and dated evidence remain unchanged.'}
write('Source_Inventory.json',inventory)
entries=[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]
entries += [(p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',BASE/'diagnose_scalar_comparison.py',Path(__file__).absolute()]]
entries += [(p,str(p.relative_to(BASE))) for folder in ['source-versions','lean-versions'] for p in sorted((BASE/folder).rglob('*')) if p.is_file()]
entries += [(project/n,'lean-project/'+n) for n in ['lean-toolchain','lake-manifest.json','lakefile.toml']]
archive('Source_Snapshot.zip',entries)
files={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for name in new_names:
    path=CODE/name;raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
 'scope':'Manifest and verification output are excluded to avoid self-reference; the preceding checkpoint is checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':len(q['branches']),'events':sequence,
 'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
