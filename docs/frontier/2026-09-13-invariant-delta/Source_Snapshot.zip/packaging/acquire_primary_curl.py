from datetime import datetime, timezone
import hashlib, json, subprocess
from pathlib import Path

base = Path(__file__).absolute().parent
dest = base/'primary'
dest.mkdir(exist_ok=True)
sources = [
 ('Milne_ANT.pdf', 'https://www.jmilne.org/math/CourseNotes/ANT.pdf'),
 ('Conrad_Different.pdf', 'https://kconrad.math.uconn.edu/blurbs/gradnumthy/different.pdf'),
 ('Conrad_Tame_Composita.pdf', 'https://math.stanford.edu/~conrad/676Page/handouts/tamecomp.pdf'),
 ('Conrad_Inertia_Surjectivity.pdf', 'https://math.stanford.edu/~conrad/676Page/handouts/inertiasurj.pdf'),
 ('Wang_2018.pdf', 'https://asset.library.wisc.edu/1711.dl/6NIAB7DW5X5WN8J/R/file-284b7.pdf'),
 ('Prasad_Yeung_2007.pdf', 'https://archive.mpim-bonn.mpg.de/id/eprint/741/1/preprint_2007_70.pdf')]
rows = []
for name, url in sources:
    path = dest/name
    proc = subprocess.run(['curl', '--fail', '--location', '--silent', '--show-error', '--max-time', '45', url, '--output', str(path)], capture_output=True, text=True)
    row = {'name': name, 'url': url, 'curl_returncode': proc.returncode, 'stderr': proc.stderr}
    if proc.returncode == 0:
        raw = path.read_bytes()
        assert raw.startswith(b'%PDF'), name
        row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    rows.append(row)
result = {'status': 'passed' if all(r['curl_returncode']==0 for r in rows) else 'partial',
          'downloaded_utc': datetime.now(timezone.utc).isoformat(), 'sources': rows,
          'scope': 'Ordinary curl content negotiation after urllib received HTTP 406. Public PDFs stay in local scratch; unavailable downloads are reported, not bypassed.'}
(base/'Source_Acquisition.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
