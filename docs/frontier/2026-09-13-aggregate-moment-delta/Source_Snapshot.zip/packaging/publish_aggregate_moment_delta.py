from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-moment-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-optimized-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_moment_delta import summarize
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)

for n in ['Moment_Proposals.json','Moment_Audit.json','Moment_Local_Audit.json','Adversary_Audit.json']:(OUT/n).write_bytes((BASE/n).read_bytes())
archive('Moment_Certificates.zip',[(BASE/'Moment_Certificate.json','Moment_Certificate.json')])
archive('Local_Feedback.zip',[(BASE/n,n) for n in ['Moment_Local.json','Moment_Feedback.json']])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==7 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(*[read(BASE/n) for n in ['Moment_Certificate.json','Moment_Local.json','Moment_Feedback.json','Moment_Audit.json','Moment_Local_Audit.json']])
write('Moment_Summary.json',{'recorded_utc':now,
    'result':'Joint finite/moment bounds extend the audit to all seventeen noisy targets, while local projection and frozen-dual residual feedback recover thirteen and ten targets at radius 0.1 under the degree/discriminant profile.',
    'input_contract':['degree four','signature (0,2)','discriminant 576','complete aggregate finite critical-line spectra through 20','generic coefficient boxes 0..4'],
    'local_deduction_profiles':['degree-only local models','degree plus ramification from the supplied discriminant'],
    'not_inference_inputs':['Galois group','field candidate catalogue','defining polynomials','subfields','conductor-parity assignment','held-out arithmetic coefficients','zero-noise domains reused as noisy premises'],
    'new_roots_computed':0,'measurement_rows':17,'target_count':17,'generic_coefficients':604,'derived_results':summary,
    'proposal_count':272,'validated_multiplier_cases':288,'stored_midpoints_checked':104592,'fresh_quadratic_interval_leaves':209184,'exact_objective_bounds':576,
    'symbolic_moment_derivative_checks':3,'independent_displaced_controls':528,'actual_component_mutations_rejected':10,
    'scope':'Coupling tightens 97 budgets, by at most about 0.7042%, without a producer candidate-domain change on the tested grid. The larger integer gains come from local projection and residual feedback. The fixed multiplier family does not match the earlier best exact-input full-row closure. Surviving domains and fixed points do not establish global realization or ambiguity.',
    'full_proof_formalized':False,'next_gate':'Re-optimize multipliers after validated domain reductions and compare noisy standalone-row propagation; investigate the remaining target/support domains with constructive feasibility and global-field constraints.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':7,'successful_commands':7,'failed_commands':0,
    'recording_scope':'Proposal, continuum certificate, one-pass local projection, independent moment audit, local/dual feedback, independent local audit and adversarial audit. Packaging and final recursive verification are separate. Earlier failed attempts remain intact in preceding checkpoints.',
    'freeze_boundary':'The 272 proposals were frozen before continuum validation. The 288 multiplier cases, including sixteen legacy c7 vectors, were frozen before the independent moment audit. Local/dual feedback consumes those independently validated error budgets, with its source frozen before exact local replay. No executed scientific instrument was revised.',
    'moment_derivation':'The baseline tail plus the per-root increment of -2H-kappa*m equals the finite change plus the moving moment tail. Joint and separated interval budgets are independently valid; the minimum is explicitly used when enclosure widths differ.',
    'attribution':'The joint budget is selected in 97 positive-radius cases but changes no producer candidate domain. Its largest relative reduction is about 0.7042%. New noisy target recovery comes from extending the objective set and alternating valid local domains with frozen-dual residual supports.',
    'independence':'Real first-derivative covers are checked by complex quadratic covers. Symbolic moment derivatives and rational monotonic endpoint enclosures add an exact route above t=3/2, which every tested interval satisfies. Integer tail products and rational residual supports replay the deductions. Transcendental interval calculations share FLINT.',
    'input_boundary':'The noisy local stages initialize generic boxes and use only certificates for that radius. Feedback reads analytic budgets and derived candidate domains from the independent audit, not its held-out arithmetic input. Formal noninterference or blindness is not claimed.',
    'baseline_limit':'This frozen-dual family recovers 14/13 exact-input targets with the stronger local profile. Earlier complete row/local feedback already recovers 17/17 and remains the best exact-input result. The lower count is a method limitation, not an information loss or a replacement of the older result.',
    'counterexample_scope':'A unit-row, one-root diagnostic shows a positive omitted moment term above 1.099e-7 when the root moves. It concerns the analytic budget expression; neither unknown-tail saturation nor an alternate field is asserted.',
    'history_policy':'Preserve all 117 branches and the 398-event byte prefix; append five events. The wider ACS investigation remains active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Inherited Python 3.12.14 and pinned scientific libraries. Floating joint-moment proposals; 224-bit/48-leaf real continuum covers; 384-bit/96-leaf complex quadratic audit with rational moment endpoints; 192-bit integer tail/objective replay; 256-bit local residual feedback with exact integer audit; 85-digit mpmath controls. No new packages, zeros or Lean modules.'
write('Runtime.json',runtime)
input_paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json']]+[PRIOR/'Proposals.json']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in input_paths},
    'scope':'The fixed spectra and measurements are inherited. Previous c7 proposals are replayed as additional rational certificates. Arithmetic is read only by downstream validation and adversarial true-value controls.'})
write('Primary_Sources.json',{'recorded_utc':now,'new_downloads':0,'inherited_record':str((INPUTS/'Primary_Sources.json').relative_to(ROOT)),
    'inherited_record_sha256':sha((INPUTS/'Primary_Sources.json').read_bytes()),'sources':read(INPUTS/'Primary_Sources.json')['sources'],
    'scope':'Reuses previously verified explicit-formula, coefficient and moment sources. No new download or page inspection is claimed. The new joint identity, rational derivative monotonicity and domain support follow the displayed derivations; local models and ramification profiles retain the preceding audited contract.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Joint-moment and noisy-target feedback delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Joint finite/moment root increments for all seventeen targets, rational moment monotonicity, generic noisy local projections, frozen-dual residual feedback, independent integer replays and semantic controls.',
    next_priority=['R12/R13: re-optimize multipliers after valid domain reductions and compare noisy standalone-row propagation',
      'R13/R14: resolve the remaining noisy target and support domains or construct feasible/global ambiguity witnesses',
      'R15: extend actual-field benchmarks with matched metadata, completeness and uncertainty contracts',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('joint_root_moment_bounds_with_explicit_modest_gain',
   'The shared finite-root change and known-moment change are enclosed together. Ninety-seven positive-radius budgets tighten, by at most about 0.7042%, without new producer candidate domains on the grid. A one-root interval counterexample shows that freezing the moment omits a positive budget term above 1.099e-7.',
   'Use the joint budget while re-optimizing multipliers under valid reduced coefficient domains; quantify integer gains separately from small continuous-bound improvements.'),
 'R13':('seventeen_noisy_targets_with_frozen_dual_domain_feedback',
   'All seventeen targets are studied at radii 0, 0.005, 0.02 and 0.1 using 272 new rational proposals and sixteen legacy c7 vectors. At radius 0.1, raw spectral recovery is 3/4 targets; local/dual feedback with discriminant ramification reaches 13/10. All held-out coefficients survive the independently replayed deductions.',
   'Re-optimize the fixed multiplier family after domain reductions and compare noisy row propagation; the current family does not match the earlier 17/17 exact-input row/local closure.'),
 'R14':('noisy_local_profiles_and_residual_support_audited',
   'Independent enumeration and exact integer replay validate 12326 one-pass local removals, 12396 local removals within feedback and 56 dual removals across the declared profile/radius replicas. At radius 0.1, degree-only feedback recovers 11/10 targets, while discriminant ramification gives 13/10. The remaining target domains and all 604 support domains are retained.',
   'Distinguish local/spectral fixed points from global realizability and investigate the four A and seven B unresolved targets under the stronger local profile at radius 0.1.'),
 'R15':('moving_moment_and_noisy_premise_boundaries_tested',
   'Ten semantic mutations challenge moment normalization, continuous covers, omitted moment changes, nonnegative multipliers, domain prerequisites, zero-noise reuse and local assumptions. The unit-row counterexample concerns the analytic error budget, not actual saturation or an alternate number field. Neither a field catalogue nor arithmetic coefficients enter inference.',
   'Preserve exact input and deduction contracts when comparing additional fields, solver proposals, sufficient certificates and genuine identification or ambiguity claims.'),
 'K04':('ongoing_delta_with_joint_moment_and_noisy_feedback_audits',
   'Preserve 117 branches and 398 events; append five events. Seven scientific command receipts succeed. Independent checks cover 104592 stored midpoints, 209184 quadratic interval leaves, 576 integer objective bounds, three symbolic moment derivatives, 528 displaced sums and all local/dual removals. Modest coupling gains and fixed-family limits remain explicit.',
   'Continue evidence-backed deltas across the complete queue, retaining assumptions, originals, failures, stronger older results and precise continuation gates without global completion or exhaustion.')}
prefix='docs/frontier/2026-09-13-aggregate-moment-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_joint_moment_noisy_feedback_audit')
        b['new_evidence']=[prefix+n for n in ['Moment_Summary.json','Moment_Certificates.zip','Moment_Audit.json','Local_Feedback.zip','Moment_Local_Audit.json','Adversary_Audit.json']]
        b['verification_routes']+=['Joint finite/moment continuum covers for all seventeen targets','Complex quadratic covers and exact rational moment monotonicity','Integer tail products and coefficient objectives',
            'Generic noisy local projection with frozen-dual domain support','Independent integer replay of all local/dual rounds','Ten semantic mutations and a one-root moment counterexample']
        b['shared_assumptions_and_scope']='Degree four, signature (0,2), discriminant 576 and complete finite critical-line spectra through 20. Noise preserves finite population and cutoff; unknown-zero tails remain unconditional. Local degree and discriminant-ramification deduction profiles are explicit. No field catalogue, Galois group, held-out arithmetic coefficients or zero-noise domains are supplied as noisy premises. Frozen-family fixed points and surviving domains do not establish optimality, realizability or global ambiguity.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=398
for bid in q['advanced_existing_branches']:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'joint_moment_noisy_feedback_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Joint moment uncertainty and noisy target feedback — 13 September 2026

At ordinate-error radius 0.1, generic local rules and frozen-dual residual feedback recover thirteen of seventeen targets in spectrum A and ten in B when ramification is inferred from discriminant 576. Raw spectral certificates recover three and four. Every held-out true coefficient survives the independent integer replay. The remaining four and seven target domains are preserved as unresolved candidates, without a claim of global realization or ambiguity.

The calculation also combines each root's finite-sum and known-moment changes before maximizing its uncertainty budget. It tightens 97 budgets by at most about 0.7042%, but creates no producer candidate-domain changes on this grid. The larger recovery gains come from extending the objective set and feeding valid local domains back into frozen-dual residual supports. The [derivation and reproduction guide](../../../code/frontier_verification/AGGREGATE_MOMENT_README.md) explains both effects and their limits.

Under the degree/discriminant local profile, feedback recovers 13/13 targets at radii 0.005 and 0.02, and 13/10 at radius 0.1. Degree-only local feedback reaches 11/10 at radius 0.1. This method's 14/13 zero-radius result is weaker than the earlier best exact-input 17/17 row/local closure, which remains valid. The limitation motivates re-optimizing after domain reductions.

- [Results, ablations and remaining domains](Moment_Summary.json).
- [272 joint-moment proposals](Moment_Proposals.json) and [288 complete continuum certificates](Moment_Certificates.zip), including sixteen previous coefficient-seven vectors on the common grid.
- [Independent moment audit](Moment_Audit.json): 104,592 stored midpoint checks, 209,184 fresh complex quadratic interval leaves, 576 exact objective bounds, three symbolic moment derivatives and 528 high-precision displaced sums.
- [One-pass local projections and residual feedback](Local_Feedback.zip), with every domain, model and iteration, and [independent exact replay](Moment_Local_Audit.json) of 12,326 one-pass local removals, 12,396 local removals within feedback and 56 dual removals. Counts include the declared method/profile/radius replicas.
- [Ten semantic mutations and a one-root counterexample](Adversary_Audit.json). Moving that root while freezing its known moment omits a positive analytic-budget term above 1.099e-7; unknown-tail saturation and alternate fields are not asserted.
- [Seven scientific execution receipts](Execution_Receipts.json), [full outputs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json) and [reused primary sources](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [403-event ledger](Branch_Events.jsonl), retaining the previous 398 events byte for byte.

No new zeros, measurements, field templates or arithmetic coefficient seeds are supplied to inference. Noisy domains come from certificates for that same radius. The transcendental interval routes share FLINT; rational moment bounds and integer feedback provide additional checks. The complete analytic and number-field proof remains unformalized. All previous failed attempts and stronger scoped results remain intact in the [preceding checkpoint](../2026-09-13-aggregate-optimized-delta/README.md) and its history.

Next, re-optimize multipliers after validated domain reductions and compare noisy standalone-row propagation. Constructive feasibility, global-field ambiguity, additional fields and the wider ACS questions remain open.
''')
names=['dedekind_aggregate_moment_'+n+'.py' for n in ['proposals','certificate','local','audit','feedback','local_audit','adversary']]+['verify_aggregate_moment_delta.py','AGGREGATE_MOMENT_README.md']
deps=['dedekind_aggregate_shared.py','dedekind_aggregate_shared_audit.py','dedekind_aggregate_noise_certificate.py','dedekind_aggregate_noise_audit.py','dedekind_aggregate_integer_audit.py','dedekind_aggregate_local_audit.py','dedekind_coefficient_recovery.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','verify_aggregate_optimized_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New joint-moment and noisy-feedback instruments with direct dependencies. Executed scientific source versions are unchanged; preceding packages and dependency hashes are verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Output placeholder for the fresh recursive verifier; not a success claim.'})
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoint verified recursively.'})
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
