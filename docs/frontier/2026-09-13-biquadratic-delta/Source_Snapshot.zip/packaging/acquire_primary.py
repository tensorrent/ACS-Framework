from pathlib import Path
import hashlib,json,subprocess
BASE=Path(__file__).absolute().parent
OUT=BASE/'primary';OUT.mkdir(exist_ok=True)
sources=[]
for name,url in [('Baker_ANT.pdf','https://www.math.toronto.edu/~ila/ANTBook.pdf'),('Milne_CFT.pdf','https://www.jmilne.org/math/CourseNotes/CFT.pdf'),('DLMF_25_15.html','https://dlmf.nist.gov/25.15')]:
    result=subprocess.run(['curl','--fail','--location','--max-time','90','--output',str(OUT/name),url],capture_output=True,text=True)
    assert result.returncode==0,(name,result.stderr)
    raw=(OUT/name).read_bytes();assert raw and (not name.endswith('.pdf') or raw.startswith(b'%PDF'))
    sources.append({'name':name,'url':url,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'curl_returncode':result.returncode})
(BASE/'Source_Acquisition.json').write_text(json.dumps({'status':'passed','sources':sources},indent=2)+'\n')
print(json.dumps({'status':'passed','sources':len(sources)}))
