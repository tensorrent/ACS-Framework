from pathlib import Path
base=Path(__file__).absolute().parent;code=base.parents[1]/'acs-repo/code/frontier_verification'
text=(code/'check_variable_noise_lean.py').read_text()
text=text.replace('Compile variable-noise scaling, midpoint and fixed-report scope lemmas.','Compile generic matrix column replacement and Cramer corner-reduction lemmas.')
start=text.index('NAMES=');end=text.index('\ndef sha',start)
text=text[:start]+"NAMES=['inverse_difference','column_action','inverse_column_replacement','cramer_column_numerator_invariant','negative_quotient_transfer','endpoint_step_nonnegative','convex_combination_upper','replacement_chain']"+text[end:]
text=text.replace('VariableNoiseMidpoint.','SignedCornerStability.')
start=text.index("'scope':");end=text.index('}\n    if result.returncode',start)
text=text[:start]+"'scope':'Eight generic lemmas: noncommutative inverse difference, rank-one column action and replacement, Cramer numerator invariance, same-determinant-sign negative quotient transfer, nondecreasing endpoint steps, convex combination bounds and a finite replacement chain. Analytic derivative bounds, closed-hull/integral membership, connectedness and the assembled concrete ACS theorem remain written or computational.'"+text[end:]
(code/'check_signed_corner_lean.py').write_text(text)
