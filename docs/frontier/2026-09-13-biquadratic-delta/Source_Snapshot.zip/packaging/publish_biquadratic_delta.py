from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-biquadratic-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-invariant-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

for name in ['Pair_Arithmetic.json','Pair_Arithmetic_Audit.json','Pair_Candidate_Class.json','Pair_Decoding.json','Pair_Adversary.json','Pair_Fresh_Replay.json','Source_Acquisition.json']:
    (OUT/name).write_bytes((BASE/name).read_bytes())
archive('Pair_Spectra.zip',[(BASE/name,name) for name in ['Pair_Spectrum160.json','Pair_Spectrum224.json','Pair_Spectral_Audit.json']])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==11 and sum(r['returncode']==0 for r in receipts.values())==10
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
write('Biquadratic_Summary.json',{'recorded_utc':now,
    'result':'Exactly two V4 quartic fields have signature (0,2) and field discriminant 576; a certified finite zero count distinguishes them even with independent ordinate errors bounded by 1/3.',
    'fields':{'A':'Q(sqrt(2),sqrt(-3))','B':'Q(sqrt(-2),sqrt(-3))'},
    'permitted_global_inputs':read(BASE/'Pair_Arithmetic.json')['input_contract'],
    'class_certificate_strengthens_original_two_example_contract':True,
    'complete_class_requires_V4':True,'candidate_fields':2,'maximal_order_cosets':190,'local_factorizations':144,
    'differing_local_observables':19,'coefficient_at_7':{'A':4,'B':0},
    'finite_factor_roots':40,'height':20,'aggregate_root_counts':{'A':23,'B':22},
    'first_distinguishing_predeclared_integer_height':2,'counts_below_two':{'A':1,'B':0},
    'robust_height':'7/3','robust_ordinate_radius':'1/3','robust_counts':{'A':1,'B':0},
    'radius_half_same_gate':'Both fields can produce either 0 or 1; ambiguity applies to this count statistic.',
    'first_zero_gate_critical_radius':read(BASE/'Pair_Decoding.json')['results'][1]['first_zero_gate_critical_radius'],
    'direct_segments':63405,'fresh_256bit_leaves':77735,'fresh_endpoint_signs':156,'independent_mpmath_roots':16,
    'grid_replays':80,'actual_mutations_rejected':11,'complete_proof_formalized':False,
    'scope':'Closed candidate-class identification followed by arithmetic prediction. Shared-invariant inputs alone leave both actual fields possible. No candidate-free Weil recovery, unknown external observation trial, global GRH, non-V4 class exhaustion, global noise optimum or ACS completion is asserted.',
    'next_gate':'Recover a differing Euler observable through certified explicit-formula constraints using the same declared global inputs, and compare against the enumerated-field selector without leaking factor metadata.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':11,'successful_commands':10,'failed_commands':1,
    'failure':'The first 256-bit replay asserted zero exclusion on each original 224-bit segment without subdivision. It failed because a special-function interval image widened at increased precision. Its exact source and receipt remain preserved. Adaptive subdivision at 256 bits produced 77,735 valid leaves covering every one of the original 63,405 segments.',
    'serialization':'The original direct-contour image printouts are lossy diagnostics. Fresh replay recomputes images and hashes exact dyadic encodings; it does not parse diagnostic image strings as certificates.',
    'freeze_chronology':'The arithmetic producer and integer grid 1..20 were recorded before spectral generation. The class certificate was added later without changing the producer. Threshold 7/3 was designed after inspecting certified roots; this is a mathematical gate construction, not statistical held-out performance. Instruments used by completed runs were preserved; the initial failed replay version is archived separately.',
    'independence':'Order maximality uses producer characteristic polynomials, a radical-basis Newton audit and a classical coprime-discriminants theorem. Radical triples and mod-24 character planes independently enumerate the V4 class. Local polynomial factorizations check character Euler factors while avoiding index primes. Folded and direct contours share FLINT; mpmath selected-root checks use another backend without claiming completeness.',
    'measurement_boundary':'Factor-labelled data certifies candidate templates. Only aggregate count and height enter selection. Observation completeness and the displacement bound remain premises; a plausible bare count cannot establish either. No external unknown-field measurement was tested.',
    'history_policy':'All previous dated checkpoints and pinned instruments remain byte-identical. Preserve all 117 branches and the 378-event prefix; append five events. The ongoing goal stays active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Existing Python 3.12.14, SymPy 1.14.0, python-flint 0.9.0 / FLINT 3.6.0 and mpmath 1.3.0. Exact integers and Fractions, 160/224-bit spectrum generation, 224-bit direct contours, 256-bit fresh replay, 85-digit independent roots. No new dependency or Lean compilation.'
write('Runtime.json',runtime)
locators={'Baker_ANT.pdf':('Proposition 2.42, printed page 52, PDF page 58','Coprime discriminants and product integral basis for disjoint Galois fields.'),
          'Milne_CFT.pdf':('V.3.27 and Example 3.29, printed page 165, PDF page 174','Abelian conductor-discriminant formula and quadratic conductors.'),
          'DLMF_25_15.html':('25.15.E2, E3, E5, E7-E8 and text of sections (i)-(ii)','Euler product, finite Hurwitz sum, analytic continuation, functional equation and trivial zeros.')}
write('Primary_Sources.json',{'recorded_utc':now,'sources':[{**r,'locator':locators[r['name']][0],'use':locators[r['name']][1]} for r in read(BASE/'Source_Acquisition.json')['sources']],
    'scope':'Downloaded public primary references with exact hashes. PDFs, HTML and rendered images remain in scratch; only locators and hashes enter the repository.'})
write('Source_Visual_Checks.json',{'pages':[{'source':source,'one_based_pdf_page':page,'renderer':'pdftoppm -scale-to 1600 -png -singlefile','visually_inspected':True,'page_png_sha256':sha((BASE/'primary'/name).read_bytes())} for source,page,name in [('Baker_ANT.pdf',58,'Baker_Product_Basis.png'),('Milne_CFT.pdf',174,'Milne_Conductor_Discriminant.png')]]})
q=read(PRIOR/'Research_Queue.json');q.update(release='Shared-invariant biquadratic spectral delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],
    advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Exact maximal orders and exhaustive V4 class by two methods; polynomial splitting; two precision spectra, direct and refined contours, independent backend roots, count decoding and actual mutations.',
    next_priority=['R15/R13: compare candidate-free explicit-formula recovery with the certified two-field selector under the same shared-invariant contract',
      'R12: optimize declared noisy count statistics and full spectral matching while separating gate limits from information limits',
      'R14/R15: enlarge the field class with exact invariants and audit metadata sufficiency before generating observations',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('robust_count_gate_on_actual_shared_invariant_fields',
   'The count below 7/3 distinguishes two certified fields under independent positive-ordinate errors <=1/3. At radius 1/2, uniform shifts give either count for either field. The first-zero gate supremum is approximately 0.355733809; this does not optimize all spectral statistics.',
   'Optimize explicitly declared count gates or full spectral statistics, retaining completeness and noise premises and proving any claimed obstruction for the actual observation model.'),
 'R13':('finite_spectral_information_with_enumerated_field_templates',
   'Shared invariants leave c_7 in {0,4}; a complete finite zero count selects the field and its coefficient. Eighty grid replays and independent error bounds agree. This establishes finite information within a known class, not candidate-free explicit-formula coefficient recovery.',
   'Recover a differing coefficient directly from certified explicit-formula constraints under the same global-input contract and compare it to the enumerated-field baseline.'),
 'R14':('same_invariant_actual_fields_with_verified_distinct_local_factors',
   'A=Q(sqrt(2),sqrt(-3)) and B=Q(sqrt(-2),sqrt(-3)) have degree four, signature (0,2), discriminant 576 and group V4. Their maximal orders are independently certified by 190 coset exclusions; 144 local factorizations agree, with index-prime controls. Nineteen local observables differ.',
   'Extend global realizability and local-factor comparisons to larger verified field classes without confusing polynomial discriminants with field discriminants or leaking subfield identities.'),
 'R15':('shared_invariant_candidate_class_and_spectral_separation_certified',
   'Exactly two fields satisfy the stated V4/degree/signature/discriminant prior. Radical triples and character planes agree. Finite spectra through 20 are complete and differ below height 2. The unlabelled count alone selects a field; conductor-parity and factor labels are excluded from the observation.',
   'Measure additional spectral arithmetic information without pre-enumerated candidate templates, and enlarge the allowed arithmetic class while keeping a frozen observation contract. A bare count still requires externally established completeness.'),
 'K04':('ongoing_delta_with_finite_class_spectral_audits_and_retained_failure',
   'Preserve 117 branches and 378 events; append five evidence events. Eleven command receipts retain ten successes and a higher-precision interval replay failure; the corrected adaptive replay validates 77,735 leaves. Eleven actual mutations are rejected.',
   'Continue evidence-backed deltas across the full queue, preserving failed attempts, exact assumptions and inherited gates without global completion or exhaustion.')}
prefix='docs/frontier/2026-09-13-biquadratic-delta/'
for branch in q['branches']:
    branch['prior_delta_evidence']=branch.get('prior_delta_evidence',[])+branch['new_evidence'];branch['new_evidence']=[];branch['assessment_this_pass']='carried_forward_not_newly_audited'
    if branch['id'] in updates:
        status,result,gate=updates[branch['id']]
        branch.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_shared_invariant_field_and_spectral_audit')
        branch['new_evidence']=[prefix+n for n in ['Biquadratic_Summary.json','Pair_Arithmetic_Audit.json','Pair_Candidate_Class.json','Pair_Decoding.json','Pair_Fresh_Replay.json','Pair_Adversary.json']]
        branch['verification_routes']+=['Exact coset maximality versus radical-basis Newton identities and coprime discriminants','Radical triples versus mod-24 character planes',
            'Character Euler factors versus index-aware polynomial factors','Folded contours versus direct contours, fresh subdivided paths and mpmath roots','Aggregate-only count schema and actual malformed-input replays']
        branch['shared_assumptions_and_scope']='Actual V4 quartic fields with signature (0,2) and field discriminant 576; cited classical arithmetic and Dirichlet analytic identities. Exact finite class and finite zero certificates; full proof not formalized. Known candidate templates, no external observation data, and explicit completeness/noise premises. No candidate-free recovery or global noise optimum claimed.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=378
for bid in q['advanced_existing_branches']:
    branch=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'shared_invariant_spectral_evidence_advanced','branch_id':bid,
       'result':branch['latest_scoped_result'],'evidence':branch['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
names=['dedekind_biquadratic_'+n+'.py' for n in ['pair','arithmetic_audit','class','spectrum','spectral_audit','decoding','replay','adversary']]+['verify_biquadratic_delta.py','BIQUADRATIC_README.md']
deps=['lfunction_zero_certificate.py','dirichlet_strip_certificate.py','dirichlet_folded_count.py','verify_invariant_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},
    'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New instruments and preserved initial replay source. Older dated checkpoints and their pinned instruments are unchanged.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/path,kind+'/'+path) for kind in ['instruments','dependencies'] for path in inventory[kind]]+
    [(BASE/n,'packaging/'+n) for n in ['run_recorded.py','acquire_primary.py','build_spectrum_instrument.py',Path(__file__).name]]+
    [(p,'source-versions/'+p.name) for p in sorted((BASE/'source-versions').iterdir())])
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
    'scope':'Manifest and Verification excluded from self-reference; previous checkpoint is checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
