"""Exact flavor and seesaw identifiability bounds; no physical fit."""
import json, math
import numpy as np
import sympy as s
from scipy.linalg import null_space

# F04: Koide constraint leaves a shape parameter, even after fixing a scale.
a=s.symbols('a',positive=True)
b=2*(1+a)+s.sqrt(3*(a*a+4*a+1))
assert s.simplify(3*(1+a*a+b*b)-2*(1+a+b)**2)==0
koide=[]
for aa in [.01,.2,1.,4.,20.]:
    xx=np.array([1.,aa,float(b.subs(a,aa))]);mm=xx**2
    q=mm.sum()/xx.sum()**2
    assert abs(q-2/3)<1e-14
    koide.append({'a':aa,'mass_ratios':list(mm/mm.sum()),'Koide':q})

# General exact differential, finite differences, and sharp range bound.
# gamma_i = d(log m_i)/dt; universal gamma cancels exactly.
rng=np.random.default_rng(20260911);derivative_checks=[]
for _ in range(40):
    m=np.exp(rng.uniform(-5,5,3));g=rng.normal(size=3)
    p=m/m.sum();q=np.sqrt(m)/np.sqrt(m).sum()
    analytic=float((p-q)@g)
    def logQ(t):
        z=m*np.exp(g*t);return math.log(z.sum()/np.sqrt(z).sum()**2)
    h=1e-5;fd=(logQ(h)-logQ(-h))/(2*h)
    bound=float((g.max()-g.min())*abs(p-q).sum()/2)
    assert abs(analytic-fd)<2e-9
    assert abs(analytic)<=bound+1e-14
    extremal=np.where(p>=q,1.,-1.)
    assert abs((p-q)@extremal)-abs(p-q).sum()<1e-14
    derivative_checks.append({'derivative':analytic,'difference_error':abs(analytic-fd),'sharp_range_bound':bound})
x=s.symbols('x0:3',positive=True)
numerator=sum(xx**6 for xx in x)*sum(x)-sum(xx**2 for xx in x)*sum(xx**5 for xx in x)
pairwise=sum(x[i]*x[j]*(x[i]-x[j])*(x[i]**4-x[j]**4) for i in range(3) for j in range(i+1,3))
assert s.expand(numerator-pairwise)==0

# F05: full mass matrices have exactly the same singular masses (m,M,M)
# and zero active-active entry, for every allowed total active-heavy mixing.
# O first row is v; other rows are only a sterile-coordinate completion.
isospectral=[]
for m,M in [(1.,100.),(.05,49000.)]:
    lower=m/(M+m)
    for t in [lower,10*lower,.01,.2,.8]:
        if t<lower or t>=1:continue
        q0=1-t;qplus=(t-(m/M)*(1-t))/2;qminus=(t+(m/M)*(1-t))/2
        assert qplus>=-1e-15
        v=np.sqrt([q0,max(0,qplus),qminus])
        O=np.vstack([v,null_space(v[None,:]).T])
        signed=np.diag([m,M,-M]);mass=O@signed@O.T
        vals,V=np.linalg.eigh(mass);order=np.argsort(abs(vals));vals=vals[order];V=V[:,order]
        measured_t=float(np.sum(V[0,1:]**2))
        # Independent spectral projector, a polynomial in the full matrix.
        Plight=(mass@mass-M*M*np.eye(3))/(m*m-M*M)
        projected_t=1-float(Plight[0,0])
        error=float(np.max(abs(np.sort(abs(vals))-np.array([m,M,M]))))
        assert error<1e-8
        assert abs(mass[0,0])<2e-10
        assert abs(measured_t-t)<2e-12 and abs(projected_t-t)<2e-12
        assert np.linalg.norm(mass@mass@mass-m*mass@mass-M*M*mass+m*M*M*np.eye(3))/M**3<1e-12
        isospectral.append({'m':m,'M':M,'t':t,'t_diagonalization':measured_t,'t_projector':projected_t,
                            'zero_active_block_residual':float(abs(mass[0,0])),'mass_error':error})

# Leading effective seesaw lower bound, with exact complex-orthogonal boosts.
# Theta = i sqrt(d_m) R sqrt(D_M)^(-1); R R^T=I.
boosts=[]
dm=np.diag([1.,2.]);DM=np.diag([100.,100.])
for y in [0.,.5,1.,2.,4.]:
    R=np.array([[math.cosh(y),1j*math.sinh(y)],[-1j*math.sinh(y),math.cosh(y)]])
    theta=1j*np.sqrt(dm)@R@np.diag([.1,.1])
    light=-theta@DM@theta.T
    assert np.max(abs(light-dm))<1e-10
    t=float(np.linalg.norm(theta,'fro')**2)
    closed=.03*math.cosh(2*y)
    assert abs(t-closed)<1e-11
    boosts.append({'boost':y,'effective_total_mixing':t,'closed':closed,'effective_light_error':float(np.max(abs(light-dm)))})

# Independent exact multi-active examples verify the all-order norm inequality.
# Real signed symmetric eigenvectors can be made a Takagi matrix by phases.
general=[]
for _ in range(30):
    D=rng.normal(size=(3,4))*.05;H=rng.normal(size=(4,4));H=H@H.T+np.eye(4)
    mass=np.block([[np.zeros((3,3)),D],[D.T,H]])
    val,U=np.linalg.eigh(mass);order=np.argsort(abs(val));val=val[order];U=U[:,order]
    ml=abs(val[:3]);MH=abs(val[3:]);A=U[:3,:3].astype(complex);B=U[:3,3:].astype(complex)
    A[:,val[:3]<0]*=1j;B[:,val[3:]<0]*=1j
    t=float(np.linalg.norm(B,'fro')**2);eta=float(np.linalg.norm(B,2)**2)
    lhs=(1-eta)*ml.sum();rhs=float(np.sum(MH*np.sum(abs(B)**2,axis=0)))
    assert lhs<=rhs+1e-12
    assert t>=ml.sum()/(MH.max()+ml.sum())-1e-12
    assert np.linalg.norm(A@np.diag(ml)@A.T+B@np.diag(MH)@B.T)<1e-11
    general.append({'sum_light':float(ml.sum()),'Mmax':float(MH.max()),'t':t,'eta':eta,
                    'exact_lower_bound':float(ml.sum()/(MH.max()+ml.sum())),'strong_bound_margin':float(rhs-lhs)})

print(json.dumps({'branches':['F04','F05'],
 'Koide':{'positive_mass_global_range':'1/3 <= Q <= 1; upper is limiting if every mass is strictly positive',
 'continuous_fixed_scale_family':'sqrt(m) proportional to (1,a,2(1+a)+sqrt(3(a^2+4a+1))), a>0',
 'examples':koide,'exact_log_derivative':'sum_i (m_i/sum m - sqrt(m_i)/sum sqrt(m)) gamma_i',
 'sharp_bound':'abs(d log Q/dt) <= (gamma_max-gamma_min)*sum abs(p_i-q_i)/2',
 'checks':derivative_checks,'monotone_flow':'If gamma_i=A+B*m_i^p with p>0, sign(d log Q/dt)=sign(B) for nondegenerate masses. Proof is sum of positive pair products; symbolic check uses p=2.',
 'scope':'No ACS texture or renormalization prescription inferred. The positive monotone-flow theorem is conditional on its stated beta form, not a claim that generic ACS running has that form.'},
 'exact_seesaw':{'assumptions':'Complex symmetric (n_active+n_heavy)-square mass matrix; zero active-active block; exactly n_active designated light states; Takagi masses positive; full mixing unitary.',
 'bound':'(1-||B||_2^2) sum_light m <= sum_heavy M_I ||B_I||^2 <= Mmax ||B||_F^2; hence t>=sum_light m/(Mmax+sum_light m).',
 'proof_1':'Zero active block gives A d A^T=-B D B^T. Nuclear norm lower bound uses A A*=I-B B* and s_min(A)^2; upper bound uses triangle inequality over rank-one columns. If eta=1 the first bound is trivial; if t>=1 the weak bound is automatic.',
 'proof_2':'Explicit isospectral family reaches the one-active lower bound and spectral projectors independently recover arbitrary larger t.',
 'isospectral_family':isospectral,'general_block_checks':general,
 'fixed_spectrum_family':'signed spectrum (m,+M,-M); first-row squared entries (1-t,(t-(m/M)(1-t))/2,(t+(m/M)(1-t))/2), t in [m/(M+m),1]. Negative signed eigenvalue is a Majorana phase, not a negative physical mass.',
 'effective_boost_family':boosts,
 'scope':'Exact isospectral family is all-order linear algebra. Complex-orthogonal boost family is a low-energy coefficient construction; large mixing points do not claim the leading seesaw expansion is physically accurate. No present-day X-ray or cosmological likelihood or abundance prediction is asserted.'}},indent=2))
