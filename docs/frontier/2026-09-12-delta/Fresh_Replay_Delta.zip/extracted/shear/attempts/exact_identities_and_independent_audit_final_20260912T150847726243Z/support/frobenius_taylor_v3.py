"""Form the real-analytic determinant series before interval evaluation.

This preserves the leading cancellation in D; v1 loses it by multiplying
independently evaluated solution boxes and is retained as a mapped failure.
"""
from fractions import Fraction as Q
import math
from flint import arb,acb,acb_series,ctx
from frobenius_jost_v3 import solution
from frobenius_jost import box
from frobenius_taylor import exact

def determinant_interval(a,b,s,degree=16,radius=Q(1,100),bits=4096):
    a,b,s=Q(a),Q(b),Q(s);center=(a+b)/2;half=(b-a)/2
    assert half<radius
    ctx.prec=128
    kd=acb(arb(exact(center),exact(radius)),arb(0,exact(radius)))
    et=exact(s)/kd;amin=(1+acb(0,1)*et).abs_lower();assert amin>1
    n=int(math.ceil(48/math.log(float(amin))))+200
    fb,vb,bounds=solution(kd,et,n=n,bits=128)
    ef=arb(bounds['f_tail']);ev=arb(bounds['v_tail']);Mf=fb.abs_upper();Mv=vb.abs_upper();Km=exact(center+radius)
    MD=Km*Mf*Mf+Mv*Mf
    ED=Km*(2*Mf*ef+ef*ef)+Mf*ev+Mv*ef+ev*ef
    q=exact(half/radius);ed=ED/(1-q)+MD*q**(degree+1)/(1-q)
    ctx.prec=bits;ctx.cap=degree+2
    K=acb_series([acb(exact(center)),1],prec=degree+1);A=1+acb(0,exact(s))/K
    prev=acb_series([0],prec=degree+1);cur=acb_series([1],prec=degree+1);f=cur;v=prev
    for j in range(n):
        nxt=(((A+2)*j*j+(A+2*K)*j-2)*cur+(-j*j+j+2)*prev)/(2*A*(j+1)*(j+1+K))
        prev,cur=cur,nxt;f+=cur;v+=(j+1)*cur
    fc=acb_series([f[j].conjugate() for j in range(degree+1)],prec=degree+1)
    ds=K*f*fc+v*fc
    x=arb(0,exact(half));d=arb(0)
    for j in range(degree,-1,-1):d=d*x+ds[j].real
    d+=arb(0,ed)
    ctx.prec=128
    return d,{'a':str(a),'b':str(b),'s':str(s),'degree':degree,'radius':str(radius),'terms':n,'bits':bits,'determinant_parameter_and_tail_error':str(ed),'complex_disk_D_bound':str(MD),'complex_disk_D_spatial_tail_bound':str(ED),'D':d.str(60,more=True),'D_lower':d.lower().str(60,more=True),'D_upper':d.upper().str(60,more=True)}
