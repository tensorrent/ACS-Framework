from datetime import datetime,timezone
import hashlib,json,urllib.request,urllib.parse,gzip
from html.parser import HTMLParser
from pathlib import Path
root=Path(__file__).absolute().parent/'primary'
base='https://www-users.cse.umn.edu/~odlyzko/zeta_tables/'
events=[]
def get(url,name):
    start=datetime.now(timezone.utc)
    with urllib.request.urlopen(url,timeout=120) as response:
        data=response.read()
        event={'url':url,'resolved_url':response.url,'status':response.status,'headers':dict(response.headers),'started_utc':start.isoformat(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'path':name}
    (root/name).write_bytes(data);events.append(event)
    (root/'receipt.json').write_text(json.dumps({'events':events},indent=2)+'\n')
    return data
html=get(base,'index.html')
class Links(HTMLParser):
    def __init__(self): super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.links += [v for k,v in attrs if k=='href']
p=Links();p.feed(html.decode())
for name in ['zeros1','zeros2','zeros6.gz']:
    candidates=[urllib.parse.urljoin(base,h) for h in p.links if urllib.parse.urljoin(base,h).endswith('/'+name)]
    assert len(candidates)==1,(name,p.links)
    get(candidates[0],name)
raw=gzip.decompress((root/'zeros6.gz').read_bytes())
(root/'zeros6').write_bytes(raw)
receipt=json.loads((root/'receipt.json').read_text())
receipt['decompressed']={'path':'zeros6','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'downloads':[{'url':e['url'],'bytes':e['bytes'],'sha256':e['sha256']} for e in events],'decompressed':receipt['decompressed']},indent=2))
