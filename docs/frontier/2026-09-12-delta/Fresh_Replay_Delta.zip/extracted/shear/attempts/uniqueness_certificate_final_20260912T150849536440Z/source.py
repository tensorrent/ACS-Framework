"""A continuum certificate: outer exclusion and strict D convexity at fixed s."""
from pathlib import Path
from fractions import Fraction as Q
import os,sys,json,time
root=Path(os.environ.get('ACS_SHEAR_ROOT',Path(__file__).resolve().parents[1]));sys.path.insert(0,str(root/'support'))
from prior_validated_jost_hardened import determinant
from curvature_jost_v2 import determinant_kk
from frobenius_jost_v3 import determinant as independent
from flint import arb,ctx
ctx.prec=112
def b(q):return arb(q.numerator)/q.denominator
def iv(a,z):return arb(b((a+z)/2),b((z-a)/2))
dest=Path(os.environ['ACS_ATTEMPT_DIR']);lower=Q(1897,10000);upper=Q(19,100);left=Q(2,5);right=Q(1,2);high=Q(49,50)
assert 2*high/(1+high)-high**2 < lower**2 and 1/(1+high)**2<high
stack=[(lower,left),(right,high)];accepted=[];inconclusive=[]
while stack:
    a,z=stack.pop();k=iv(a,z);d,details=determinant(k,b(lower)/k)
    row={'lo':str(a),'hi':str(z),'D_at_lower_growth':d.str(60,more=True),'D_lower':d.lower().str(60,more=True),'D_upper':d.upper().str(60,more=True)}
    if d>0:accepted.append(row)
    else:
        inconclusive.append(row);m=(a+z)/2;stack.extend([(m,z),(a,m)])
    if len(accepted)+len(inconclusive)>20000:raise RuntimeError('explicit 20000-cell resource bound')
outer={'accepted':accepted,'inconclusive_parent_cells':inconclusive}
(dest/'outer_exclusion.json').write_text(json.dumps(outer,indent=2));print(json.dumps({'outer_accepted':len(accepted),'outer_inconclusive':len(inconclusive)}),flush=True)
for a,z in [(lower,left),(right,high)]:
    rows=sorted((r for r in accepted if Q(r['lo'])>=a and Q(r['hi'])<=z),key=lambda r:Q(r['lo']))
    assert Q(rows[0]['lo'])==a and Q(rows[-1]['hi'])==z
    assert all(Q(x['hi'])==Q(y['lo']) for x,y in zip(rows,rows[1:]))
curve=[]
for j in range(50):
    a=left+Q(j,500);z=a+Q(1,500)
    d,dk,dkk,details=determinant_kk(iv(a,z),iv(lower,upper),steps=720)
    row={'lo':str(a),'hi':str(z),'s_lo':str(lower),'s_hi':str(upper),'D_kk':dkk.str(60,more=True),'D_kk_lower':dkk.lower().str(60,more=True),'D_kk_upper':dkk.upper().str(60,more=True),'details':details}
    curve.append(row);assert dkk>0
(dest/'curvature_cover.json').write_text(json.dumps(curve,indent=2))
minimum=min(arb(row['D_kk']).lower() for row in curve)
k0=Q(89,200);df,fd=independent(b(k0),b(upper/k0),n=600)
_,dk,_,detail=determinant_kk(b(k0),b(upper),steps=720)
convex_lower=df-dk.abs_upper()**2/(2*minimum)
assert convex_lower>0
dl,ld=independent(b(k0),b(lower/k0),n=600);assert dl<0
out={'status':'certified_conditional_on_inherited_simple_unstable_eigenvalue_theorem','unique_global_maximizer':True,'maximizer_k_interval':['2/5','1/2'],'growth_interval':[str(lower),str(upper)],'outer_accepted':len(accepted),'outer_inconclusive_parent_cells':len(inconclusive),'curvature_cells':len(curve),'uniform_D_kk_lower':str(minimum),'fixed_k':str(k0),'independent_D_lower':str(dl),'independent_D_upper':str(df),'D_k_at_upper':str(dk),'convexity_D_lower_at_upper':str(convex_lower),'logic':'Any maximizer has growth > lower and lies in (2/5,1/2). Strict convexity in k of D(k,s/k) for each fixed s in [lower,upper] forbids two maximizing roots: D would be negative between them, hence there would be higher growth. Strong convexity and the point derivative bound prove D(k,upper/k)>0 throughout the inner interval.','boundary':'The outer exclusion and curvature propagation share the prior Taylor-integrator architecture. The Frobenius point signs use an independent full-half-line series and tail contraction.'}
(dest/'result.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
