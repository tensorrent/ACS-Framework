"""Numerical search over common root shifts for variable-noise boundary pairs."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
import mpmath as mp
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES,kernel,number,exported
from dedekind_feature_certificate import coordinate_audit
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 mp.mp.dps=220;p=json.loads((BASE/'Boundary_Pair_Proposals.json').read_text());s=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text());src=next(x for x in s['matching_cases'] if x['precision_bits']==224)
 c=list(map(F,src['common_observation']));cm=list(map(number,c));seed=p['cases'][-1];free=seed['free_A_indices'];v=seed['feature_difference_direction'];scale=number('1e-10');r=F(p['root_coordinate_error_radius']);critical=F(seed['fixed_A_critical_coordinate'])
 B=list(map(F,seed['fixed_B_coordinates']));w=mp.matrix(list(map(number,seed['A_coordinate_corrections']))+[number(seed['scaled_tau'])]);attempts=[]
 def solve(B,w):
  w=mp.matrix(w);BF=[sum(kernel(spec,number(x)) for x in B) for spec in FEATURES]
  def evaluate(w):
   A=list(cm);A[1]=number(critical)
   for j,i in enumerate(free):A[i]+=w[j]
   f=mp.matrix([sum(kernel(spec,x) for x in A)-BF[k]-2*scale*w[21]*v[k] for k,spec in enumerate(FEATURES)])
   J=mp.matrix([[kernel(spec,A[i],True) for i in free]+[-2*scale*v[k]] for k,spec in enumerate(FEATURES)])
   return A,f,J
  for _ in range(25):
   A,f,J=evaluate(w)
   if max(abs(x) for x in f)<mp.mpf('1e-160'):break
   w-=mp.lu_solve(J,f)
  A,f,J=evaluate(w);return w,A,f,J
 w,A,f,J=solve(B,w)
 for iteration in range(8):
  inv=J**-1;gradient={i:scale*sum(inv[21,k]*kernel(spec,number(B[i]),True) for k,spec in enumerate(FEATURES)) for i in free};direction={}
  for i in free:
   sign=-1 if gradient[i]>0 else 1
   room=min((cm[i]+mp.mpf('.01')-max(A[i],number(B[i]))) if sign>0 else (min(A[i],number(B[i]))-(cm[i]-mp.mpf('.01'))),mp.mpf('.002'))
   direction[i]=sign*max(mp.mpf(0),room)
  accepted=False
  for power in range(9):
   step=mp.mpf('0.8')/2**power;nextB=list(B)
   for i in free:nextB[i]+=F(mp.nstr(step*direction[i],170))
   predictor=mp.matrix(w)
   for j,i in enumerate(free):predictor[j]+=number(nextB[i]-B[i])
   predictor[21]+=sum(gradient[i]*number(nextB[i]-B[i]) for i in free)/scale
   try:nw,nA,nf,nJ=solve(nextB,predictor)
   except (ZeroDivisionError,ValueError,OverflowError) as error:
    attempts.append({'iteration':iteration,'step':str(step),'accepted':False,'error_type':type(error).__name__,'error':str(error)})
    continue
   nr=[F(mp.nstr(x,170)) for x in nA];distance=max(abs(x-y) for coords in [nr,nextB] for x,y in zip(coords,c));converged=max(abs(x) for x in nf)<mp.mpf('1e-160')
   records=coordinate_audit({'radius':r,'boxes_A':[(x,x) for x in nr],'boxes_B':[(x,x) for x in nextB]},s,SOURCE/'Equal_Population_Inputs.zip');feasible=all(x['within_radius'] for x in records)
   accept=converged and feasible and distance<F('1e-2')-F('1e-12') and nw[21]<w[21] and nw[21]>0
   attempts.append({'iteration':iteration,'step':str(step),'numerically_converged':converged,'source_centers_feasible':feasible,'maximum_center_displacement':str(distance),'tau_display':float(scale*nw[21]),'accepted':bool(accept)})
   if accept:B,w,A,f,J=nextB,nw,nA,nf,nJ;accepted=True;break
  if not accepted:break
 inv=J**-1;nr=list(c);nr[1]=critical
 for j,i in enumerate(free):nr[i]+=F(mp.nstr(w[j],170))
 records=coordinate_audit({'radius':r,'boxes_A':[(x,x) for x in nr],'boxes_B':[(x,x) for x in B]},s,SOURCE/'Equal_Population_Inputs.zip')
 case={'status':'numerical_proposal_not_certified','B_correction_scale':'optimized_common_shift_from_3/2','free_A_indices':free,'fixed_A_critical_coordinate':str(critical),'fixed_B_coordinates':list(map(str,B)),
  'A_coordinate_corrections':[mp.nstr(w[j],170) for j in range(21)],'scaled_tau':mp.nstr(w[21],170),'tau_scale':'1/10000000000','feature_difference_direction':v,'preconditioner':exported(inv),
  'tau_proposal':mp.nstr(scale*w[21],170),'tau_display':float(scale*w[21]),'numerically_converged':max(abs(x) for x in f)<mp.mpf('1e-160'),'history':attempts,'maximum_residual':mp.nstr(max(abs(x) for x in f),170),
  'maximum_A_displacement':str(max(abs(x-y) for x,y in zip(nr,c))),'maximum_B_displacement':str(max(abs(x-y) for x,y in zip(B,c))),
  'rational_center_source_constraints_all_pass':all(x['within_radius'] for x in records),'rational_center_coordinate_audit':records,'inside_radius_0p01_at_centers':all(abs(x-y)<F(1,100) for coords in [nr,B] for x,y in zip(coords,c))}
 return {'status':'exploratory_proposals_require_certification','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [BASE/'Boundary_Pair_Proposals.json',SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_proposal.py',CODE/'dedekind_feature_certificate.py']},'mpmath_dps':220,'export_significant_digits':170,'critical_epsilon':p['critical_epsilon'],'root_coordinate_error_radius':p['root_coordinate_error_radius'],'cases':[case],
  'candidate_argument':'Use implicit derivatives of the variable-tau feature equation to propose common root shifts. Backtrack unless root-center source feasibility, strict cube containment and numerical convergence persist and tau decreases. This is a bounded numerical search, not a global optimization proof.',
  'scope':'Separate from frozen checkpoint 29. Exact equalities and root existence need interval certificates and independent audits. Failed trial steps are retained. No optimal threshold or newly published bound is claimed.'}
r=run();(BASE/'Shifted_Pair_Proposals.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'tau_display':r['cases'][0]['tau_display'],'attempts':len(r['cases'][0]['history']),'accepted_steps':sum(x['accepted'] for x in r['cases'][0]['history']),'inside_cube':r['cases'][0]['inside_radius_0p01_at_centers']},indent=2))
