"""Read-only physical review: independent analytic derivative/Cauchy tail.

Uses the exact decimal center already reported, not a new approximate root.
Rewrites barrier propagation with sqrt(20-E), whose enclosing box has positive
real part, instead of relying on the below-cut branch of sqrt(E-20).
Shared trusted arithmetic backend: Arb/python-flint, not an independent kernel.
"""
import json
from flint import acb,arb,ctx
ctx.prec=180
E0=acb(arb('6.4410375858632668291750820163897948'),arb('-0.0022082370285796342710682308196514037'))
r=arb('1e-30');R=arb('0.001')
imaginary_unit=acb(0,1)

def value_and_derivative(E):
    k=E.sqrt();h=(20-E).sqrt()
    u=k.sin()/k;v=k.cos()
    up=(k*k.cos()-k.sin())/(2*k**3);vp=-k.sin()/(2*k)
    C=h.cosh();S=h.sinh()/h;T=h*h.sinh()
    Cp=-h.sinh()/(2*h)
    Sp=-(h*h.cosh()-h.sinh())/(2*h**3)
    Tp=-(h.sinh()+h*h.cosh())/(2*h)
    U=C*u+S*v;V=T*u+C*v
    Up=Cp*u+C*up+Sp*v+S*vp
    Vp=Tp*u+T*up+Cp*v+C*vp
    return V-imaginary_unit*k*U, Vp-imaginary_unit*(U/(2*k)+k*Up)

outer=E0+acb(arb(0,R),arb(0,R))
assert outer.real>0
assert (20-outer).real>0
assert E0.imag+r<0
d0,d1=value_and_derivative(E0)
M=value_and_derivative(outer)[0].abs_upper()
tail=M*r*r/(R*(R-r))
lhs=d0.abs_upper()+tail;rhs=r*d1.abs_lower()
assert lhs<rhs
print(json.dumps({'scope':'Independent analytic formula and Cauchy-tail review of the single rectangular-barrier pole. Same Arb arithmetic backend; no statement about nuclear potentials.',
 'branches':{'outer_E_real':str(outer.real),'outer_20_minus_E_real':str((20-outer).real),'analytic':'Both square-root arguments remain in the open right half-plane over the radius-0.001 enclosing box, so the chosen branches, all divisions and propagated determinant are analytic there.'},
 'determinant':'h=sqrt(20-E), k=sqrt(E); U=cosh(h)*sin(k)/k+sinh(h)/h*cos(k); V=h*sinh(h)*sin(k)/k+cosh(h)*cos(k); D=V-i*k*U.',
 'outer_radius':str(R),'inner_radius':str(r),
 'D_center_upper':str(d0.abs_upper()),'D_prime_center_lower':str(d1.abs_lower()),
 'D_outer_circle_bound':str(M),'Cauchy_tail_upper':str(tail),
 'Rouche_left':str(lhs),'Rouche_right':str(rhs),'strict_inequality':bool(lhs<rhs),'zeros_in_disk':1,
 'proof':'Cauchy estimates on |E-E0|=R give |a_n|<=M/R^n. Summing every Taylor term n>=2 on the inner circle bounds the remainder by M*r^2/[R*(R-r)]. Add |D(E0)| and compare with r*|D_prime(E0)|. The derivative here is analytically differentiated explicitly, with no formal-series jet.'},indent=2))
