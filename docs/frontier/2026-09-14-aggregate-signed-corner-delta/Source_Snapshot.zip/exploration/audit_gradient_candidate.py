"""Independent real-polynomial and exact FLINT audit of an unpublished sign/corner candidate."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import hashlib,json,sys
from flint import arb,arb_mat,fmpq,fmpq_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_weighted_region_audit_v2 import SPECS,gaussian_polys,moment_polys,evaluate,positive_series
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
REGION=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Independent_Weighted_Region_Audit_v2.json'
WEIGHT=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Weighted_Region_Certificate.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def av(x):
 q=F(x);return arb(q.numerator)/arb(q.denominator)
def enc(x):return {'mid':list(map(int,x.mid().man_exp())),'rad':list(map(int,x.rad().man_exp()))}
def run():
 a=json.loads(ANCHOR.read_text());reg=json.loads(REGION.read_text());primary=json.loads(WEIGHT.read_text());old=json.loads((BASE/'Gradient_Sign_Exploration.json').read_text());corner=json.loads((BASE/'Corner_Inverse_Exploration.json').read_text())
 c=list(map(F,a['common_rational_coordinates']));R=[list(map(F,row)) for row in a['full_rank_proposal']['preconditioner']];B=[list(map(F,row)) for row in reg['regions'][0]['independent_48_bit_majorant']];w=list(map(F,primary['regions'][0]['positive_rational_weights']));v=[1 if x>0 else -1 for x in R[1]]
 assert reg['regions'][0]['radius']=='1/100' and all(sum(B[i][j]*w[j] for j in range(22))<w[i]/2 for i in range(22))
 M=fmpq_mat([[fmpq(str(F(int(i==j))-B[i][j])) for j in range(22)] for i in range(22)]);C=M.inv();row=[F(str(C[1,j])) for j in range(22)];assert all(x>=0 for x in row)
 assert all(sum(row[i]*(F(int(i==j))-B[i][j]) for i in range(22))==int(j==1) for j in range(22))
 deviations=[sum((row[i]-int(i==1))*abs(R[i][k]) for i in range(22)) for k in range(22)];assert all(abs(R[1][k])>deviations[k] for k in range(22))
 u0=[sum(R[i][k]*v[k] for k in range(22)) for i in range(22)];h=positive_series(B,list(map(abs,u0)),w);u=[(u0[i]-(h[i]-abs(u0[i])),u0[i]+(h[i]-abs(u0[i]))) for i in range(22)];eta=F(1,100);checks=[]
 for bits in [896,1152]:
  ctx.prec=bits;functions=[]
  for spec in SPECS:
   if spec['kind']=='rational_moment':
    polys=moment_polys(F(9,4),8)
    def fn(x,polys=polys):return [evaluate([av(t) for t in polys[n]],x)/(av('9/4')+x*x)**(n+1) for n in range(9)]
   else:
    aa=av(spec['a']);uu=arb(spec['center']).log();P,Q=gaussian_polys(aa,uu,8)
    def fn(x,aa=aa,uu=uu,P=P,Q=Q):return [2*(-aa*x*x).exp()*(evaluate(P[n],x)*(uu*x).cos()+evaluate(Q[n],x)*(uu*x).sin()) for n in range(9)]
   functions.append(fn)
  point=[[fn(av(x)) for x in c] for fn in functions];high=[[abs(fn(av(x)+arb(0,av(eta).upper()))[8]) for x in c] for fn in functions];cols=[]
  for j in range(22):
   b0=[];radii=[]
   for i in range(22):
    coefficients=[sum((av(R[i][k])*point[k][j][t+2] for k in range(22)),arb(0)) for t in range(6)]
    b0.append(coefficients[0]);radii.append(sum((abs(coefficients[t])*av(eta)**t/factorial(t) for t in range(1,6)),arb(0))+av(eta)**6/factorial(6)*sum((abs(av(R[i][k]))*high[k][j] for k in range(22)),arb(0)))
   perturb=sum((av(row[i]-int(i==1))*(abs(b0[i])+radii[i]) for i in range(22)),arb(0));bound=b0[1]+arb(0,(radii[1]+perturb).upper());asign=1 if bound>0 else -1 if bound<0 else 0;usign=1 if u[j][0]>0 else -1 if u[j][1]<0 else 0
   expected=old['checks'][-1]['columns'][j];assert asign==expected['curvature_sign'] and usign==expected['inverse_direction_sign']
   cols.append({'coordinate':j,'real_polynomial_curvature_bound':enc(bound),'curvature_sign':asign,'inverse_direction_interval':list(map(str,u[j])),'inverse_direction_sign':usign,'candidate_derivative_sign':-asign*usign})
  y=list(map(F,corner['checks'][0]['face_reference_coordinates']));J=arb_mat([[fn(av(x))[1] for x in y] for fn in functions]);Y=J.inv();u12=sum((Y[12,k]*v[k] for k in range(22)),arb(0));assert u12<0
  y[12]=c[12]-eta;J=arb_mat([[fn(av(x))[1] for x in y] for fn in functions]);Z=J.inv();K=sum((abs(Z[1,k]) for k in range(22)),arb(0));assert all((Z[1,k]>0 if v[k]>0 else Z[1,k]<0) for k in range(22))
  checks.append({'precision_bits':bits,'columns':cols,'certified_derivative_signs':sum(x['candidate_derivative_sign']!=0 for x in cols),'face_reference_u12':enc(u12),'candidate_corner_coordinates':list(map(str,y)),'corner_inverse_norm':enc(K),'corner_norm_display':float(K.mid())})
 return {'status':'independent_candidate_checks_passed_not_global_certificate','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [ANCHOR,REGION,WEIGHT,BASE/'Gradient_Sign_Exploration.json',BASE/'Corner_Inverse_Exploration.json',CODE/'dedekind_weighted_region_audit_v2.py']},'critical_inverse_row_signs_certified':22,'own_exact_resolvent_row':list(map(str,row)),'own_positive_series_supersolution':list(map(str,h)),'checks':checks,
  'scope':'Independent real derivative polynomials through order 8, the separately certified 48-bit majorant, exact FLINT matrix inversion and positive-series supersolutions reproduce the 21 sign conclusions and candidate corner value. Both numerical routes share FLINT. The matrix-hull/rank-one/Cramer bridge and complete scientific provenance/adversaries/formalization remain required before a uniform corner bound or next checkpoint publication.'}
r=run();(BASE/'Independent_Gradient_Candidate_Audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'row_signs':r['critical_inverse_row_signs_certified'],'checks':[{k:x[k] for k in ['precision_bits','certified_derivative_signs','corner_norm_display']} for x in r['checks']]},indent=2))
