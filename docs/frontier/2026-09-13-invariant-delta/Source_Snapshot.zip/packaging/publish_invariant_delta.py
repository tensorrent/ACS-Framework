from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

BASE = Path(__file__).absolute().parent
ROOT = BASE.parents[1]/'acs-repo'
CODE = ROOT/'code/frontier_verification'
OUT = ROOT/'docs/frontier/2026-09-13-invariant-delta'
PRIOR = ROOT/'docs/frontier/2026-09-13-local-noise-delta'
OUT.mkdir(exist_ok=True)
now = datetime.now(timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(p): return json.loads(p.read_text())
def write(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
def archive(name, entries):
    with zipfile.ZipFile(OUT/name, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path, entry in entries: z.write(path, entry)

for name in ['Invariant_Predictions.json', 'Invariant_Audit.json', 'Invariant_Adversary.json', 'Source_Acquisition.json', 'Verification_Development.json']:
    (OUT/name).write_bytes((BASE/name).read_bytes())
data = read(BASE/'Invariant_Predictions.json'); audit = read(BASE/'Invariant_Audit.json')
assert data['status']==audit['status']=='passed'
receipts = {p.parent.name: read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==5 and sum(r['returncode']==0 for r in receipts.values())==4
write('Execution_Receipts.json', receipts)
archive('Execution_Artifacts.zip', [(BASE/name/f, name+'/'+f) for name in receipts for f in ['receipt.json', 'stdout.txt', 'stderr.txt']])
write('Invariant_Summary.json', {'recorded_utc': now,
    'theorem': 'Every number field of degree four and absolute field discriminant 125 is isomorphic to Q(zeta_5).',
    'global_invariant_local_factors': 72, 'previous_ambiguous_factors_selected': 48,
    'prior_only_coefficient_predictions': 604, 'held_out_target_matches': 91, 'additional_spectral_observations_used': 0,
    'complete_number_field_proof_formalized': False, 's4_exhaustive_subsets': 130817,
    'subdirect_product_exhaustive_subsets_with_identity': 32768, 'finite_field_factorizations': 564,
    'mutated_transcripts_rejected': 6,
    'interpretation': 'Degree, signature and discriminant already supplied to the explicit formula identify this witness. Earlier local/spectral profile comparisons restrict permissible deductions; their survivor counts and numerical thresholds are not unrestricted actual-field ambiguity or information-theoretic limits.',
    'unchanged_mathematical_scope': 'Earlier numerical enclosures and restricted decoder results stand. No new spectral measurement, improved uncertainty threshold, general field-identification theorem or global completion is claimed.',
    'next_question': 'Construct independently verified nonisomorphic fields sharing every permitted global invariant, with a differing Euler observable, before measuring information added by finite zero data.'})
write('Development_Notes.json', {'recorded_utc': now, 'recorded_commands': 5, 'successful_commands': 4, 'failed_commands': 1,
    'failure': 'The first urllib download received HTTP 406. Its exact source and traceback are retained. Ordinary curl retrieved all six public PDFs successfully without changing authentication or circumventing an access gate.',
    'web_limitations': 'The LMFDB field page displayed a reCAPTCHA, so no database verification is claimed. Web PDF screenshot calls were unavailable. Local Poppler renders were inspected for the Minkowski bound, tame orbit formula and independent published uniqueness statement.',
    'logical_audit': 'The proof eliminates D4 by a quadratic unramified quotient and S4 by a cubic discriminant-five subfield; it then identifies the cyclic quartic through a compositum. It does not assume inertia normal in S4, linear disjointness of quartics, a Galois property of the input field, or correctness of a solver.',
    'independence': 'Generator-closure enumeration is checked by exhaustive subsets. Perfect matchings are checked by cosets. Cyclotomic residue orders are checked by finite-field polynomial factorization, and discriminants by trace Gram determinants. Symbolic factorization and irreducibility checks share SymPy. The number-field premises are cited and reviewed but not formally mechanized.',
    'freeze_boundary': 'The prior-only producer completed before the independent audit read the old arithmetic vector and local ambiguities. Recorded mathematical instruments were not subsequently modified. An initial package verifier compared Python tuples against JSON lists; its source and failure are retained, and the verifier now compares canonical serialization.',
    'history_policy': 'All earlier dated packages and pinned instruments remain byte-identical. Preserve 116 branches and the 373-event prefix, add R15 and five events. The ongoing goal remains active.'})
runtime = read(PRIOR/'Runtime.json'); runtime['recorded_utc'] = now
runtime['scope'] = 'Existing Python 3.12.14 and SymPy 1.14.0, exact Python integers/Fractions. No new packages, optimizer, root computation or Lean compilation in this checkpoint.'
write('Runtime.json', runtime)
acquired = read(BASE/'Source_Acquisition.json')
locators = {
 'Milne_ANT.pdf': ('Theorems 3.34-3.35; 4.3 and 4.9, printed pages 70 and 72; Corollary 7.59', 'Degree sum, ramification support, Minkowski bound and no nontrivial finite-unramified extension of Q, cyclic tame inertia.'),
 'Conrad_Different.pdf': ('Theorems 4.8 and 4.13, printed pages 10 and 12; Example 4.10, printed page 11', 'Discriminant norm, tame different exponent and cyclotomic prime-power field discriminant for the degree/signature control.'),
 'Conrad_Tame_Composita.pdf': ('Theorem 2.1 and section 3, PDF pages 1-2', 'Composita and the unramified base-change fact used for normal closures.'),
 'Conrad_Inertia_Surjectivity.pdf': ('Entire one-page handout', 'Inertia surjects onto the inertia of a Galois subextension.'),
 'Wang_2018.pdf': ('Section 3.1.1, printed page 31, PDF page 40', 'Tame discriminant exponent as permutation index n minus inertia orbits.'),
 'Prasad_Yeung_2007.pdf': ('Printed page 11, Case (a), PDF page 11', 'Independent published corroboration of the unique totally complex quartic of discriminant 125; underlying table enumeration is not rerun.')}
sources = []
for row in acquired['sources']:
    locator, use = locators[row['name']]
    sources.append({**row, 'locator': locator, 'use': use})
write('Primary_Sources.json', {'recorded_utc': now, 'sources': sources, 'scope': 'Public primary source hashes and exact locators. Third-party PDFs and page images remain only in local scratch.'})
renders = []
for pdf, page, stem in [('Milne_ANT.pdf',72,'Milne_Minkowski'),('Wang_2018.pdf',40,'Wang_Inertia'),('Prasad_Yeung_2007.pdf',11,'Prasad_Uniqueness')]:
    renders.append({'source': pdf, 'one_based_pdf_page': page, 'renderer': 'pdftoppm -scale-to 1600 -png -singlefile',
        'page_png_sha256': sha((BASE/'primary'/f'{stem}.png').read_bytes()), 'visually_inspected': True})
write('Source_Visual_Checks.json', {'scope': 'Local rendered pages inspected after web screenshot support was unavailable; images remain in scratch.', 'pages': renders})
q = read(PRIOR/'Research_Queue.json')
q.update(release='Global invariant classification delta 2026-09-13', recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)), baseline_branches=116, branches_total=117,
    new_branches=['R15'], advanced_existing_branches=['R12','R13','R14','K04'],
    replay_scope='Source-reviewed uniqueness derivation, exact groups by two methods, prior-only predictions, polynomial/held-out cross-checks and actual corrupted-transcript replay.',
    next_priority=['R15: construct and independently certify a field pair sharing all permitted global inputs but differing in an Euler observable',
      'R12/R13: retain the restricted numerical-recovery benchmark and investigate wider uncertainty or stronger common-error bounds under declared deduction rules',
      'R14: separate local relaxation feasibility, global field realization and the information in supplied arithmetic invariants',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates', 'K02/K05: private corpus and historical-run identities'])
updates = {
 'R12': ('noise_threshold_interpretation_with_global_input_audit',
   'The supplied degree and discriminant identify Q(zeta_5), independently of ordinate precision. Earlier tested radii remain sufficient bounds for the restricted spectral decoder; they are not information-theoretic limits under every deduction allowed by the inputs.',
   'Continue numerical noise analysis with deduction rules stated explicitly; use a globally nonidentifying input class when testing information added by spectra.'),
 'R13': ('spectral_recovery_distinguished_from_prior_only_identification',
   'A prior-only producer predicts all 604 retained coefficients and all 91 targets from the globally classified field. Independent polynomial factorizations and held-out arithmetic agree. No numerical bound or spectral observation was added in this pass.',
   'Compare the numerical decoder to a baseline using only permitted global inputs, and establish a nontrivial candidate field class before claiming field discovery.'),
 'R14': ('all_original_local_factors_selected_by_global_invariants',
   'Degree four and absolute field discriminant 125 imply Q(zeta_5). All 72 local factors are thereby identified, selecting the 48 earlier local-relaxation ambiguities and predicting their missing square coefficients. The old survivors need not represent alternative actual fields with those invariants.',
   'Audit global realizability and input sufficiency in other fields; restricted local-model identifiability remains distinct from arithmetic classification.'),
 'K04': ('ongoing_delta_with_classification_premises_and_new_benchmark_gate',
   'Preserve all 116 inherited branches and 373 events; add R15 and five events. Five command receipts retain four successes and one HTTP client failure, with primary source hashes and independent finite verification.',
   'Continue evidence-backed deltas and independent challenges across the full queue without global completion or exhaustion.')}
prefix = 'docs/frontier/2026-09-13-invariant-delta/'
for branch in q['branches']:
    branch['prior_delta_evidence'] = branch.get('prior_delta_evidence', []) + branch['new_evidence']
    branch['new_evidence'] = []; branch['assessment_this_pass'] = 'carried_forward_not_newly_audited'
    if branch['id'] in updates:
        status, result, gate = updates[branch['id']]
        branch.update(current_status=status, latest_scoped_result=result, continuation_condition=gate,
                      assessment_this_pass='fresh_global_invariant_and_interpretation_audit')
        branch['new_evidence'] = [prefix+n for n in ['Invariant_Summary.json','Invariant_Predictions.json','Invariant_Audit.json','Invariant_Adversary.json','Primary_Sources.json']]
        branch['verification_routes'] += ['Classical tame ramification and Minkowski derivation', 'Generator closure versus exhaustive subset groups and coset actions',
            'Prior-only predictions versus polynomial factorization and held-out coefficients', 'Actual corrupted-transcript replays and same-degree/signature field control']
        branch['shared_assumptions_and_scope'] = 'Degree four and absolute field discriminant 125 of an actual number field, plus cited classical arithmetic. Full theorem not formally mechanized. Older spectral and local profiles remain restricted deduction systems; this pass uses the global information in those supplied invariants.'
q['branches'].append({'id':'R15',
    'question':'Which spectral arithmetic information is new after accounting for every permitted global invariant, and how can a benchmark certify that its prior inputs leave multiple actual fields possible?',
    'current_status':'nonidentifying_global_input_benchmark_required', 'assessment_this_pass':'new_question_from_verified_input_sufficiency_result',
    'related_branches':['R12','R13','R14','R07','P05'],
    'latest_scoped_result':'The existing quartic discriminant-125 case is globally identified without zeros. A same-degree/signature discriminant-256 control changes c_9, so the discriminant is a substantive input. No pair sharing all global inputs has yet been certified in this checkpoint.',
    'continuation_condition':'Construct two nonisomorphic number fields sharing every allowed global input, independently verify maximal orders, field discriminants and signatures, and exhibit a differing Euler observable. Then freeze the permitted input contract and compare a prior-only baseline with finite certified zero measurements. If the fields have equal zeta data, report the resulting identification obstruction rather than assume spectral separation.',
    'verification_routes':['Exact field-invariant certificates', 'Independent nonisomorphism and Euler-factor checks', 'Explicit input-ablation and prior-only baselines', 'Certified finite spectral measurements when an arithmetic separation exists'],
    'shared_assumptions_and_scope':'A new benchmark gate derived from this classification; existence of a suitable pair, a separating spectral window and general identifiability are not yet established.',
    'prior_delta_evidence':[], 'new_evidence':[prefix+'Invariant_Summary.json',prefix+'Invariant_Audit.json', 'code/frontier_verification/INVARIANT_README.md']})
write('Research_Queue.json', q)
events = (PRIOR/'Branch_Events.jsonl').read_bytes()
last = json.loads(events.splitlines()[-1])['event_sha256']; sequence = 373
for bid in ['R12','R13','R14','K04','R15']:
    branch = next(b for b in q['branches'] if b['id']==bid); sequence += 1
    event = {'sequence':sequence, 'utc':now, 'release':q['release'], 'kind':'global_invariant_evidence_advanced' if bid!='R15' else 'new_benchmark_question',
             'branch_id':bid, 'result':branch['latest_scoped_result'], 'evidence':branch['new_evidence'], 'previous_event_sha256':last}
    last = sha(json.dumps(event,sort_keys=True,separators=(',',':')).encode()); event['event_sha256']=last
    events += (json.dumps(event,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
names = ['dedekind_invariant_classification.py','dedekind_invariant_audit.py','dedekind_invariant_adversary.py','verify_invariant_delta.py','INVARIANT_README.md']
deps = ['verify_local_noise_delta.py','source_requirements.txt']
inventory = {'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},
    'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New classification instruments and preserved acquisition scripts. No earlier instrument changed.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip', [(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+
    [(p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',BASE/'acquire_primary.py',BASE/'acquire_primary_curl.py',Path(__file__).absolute()]]+
    [(p,'source-versions/'+p.name) for p in sorted((BASE/'source-versions').iterdir())])
files = {}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes(); files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for name in names:
    path=CODE/name; raw=path.read_bytes(); files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json', {'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
    'scope':'Manifest and verification output excluded from self-reference; previous checkpoint is checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':117,'events':sequence},indent=2))
