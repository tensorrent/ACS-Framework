"""Run all new checks, preserving every attempt, output and error as a new record."""
import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
timestamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
attempt=ROOT/'attempts'/timestamp
attempt.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,attempt/'run_checks.py')
results=[]
for name in ['information_geometry','transparent_constraints','source_instruments']:
    program=ROOT/'checks'/f'{name}.py';out=attempt/name;out.mkdir()
    shutil.copyfile(program,out/'program.py')
    env=dict(os.environ);env['ACS_FOUNDATIONS_OUTPUT']=str(out);env['PYTHONDONTWRITEBYTECODE']='1'
    proc=subprocess.run([sys.executable,str(program)],cwd=ROOT,env=env,capture_output=True,text=True)
    (out/'stdout.log').write_text(proc.stdout);(out/'stderr.log').write_text(proc.stderr)
    receipt={'check':name,'returncode':proc.returncode,'program_sha256':hashlib.sha256(program.read_bytes()).hexdigest(),'python':sys.version,'command':[sys.executable,str(program)]}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2))
    if proc.returncode==0:
        parsed=json.loads(proc.stdout);(out/'result.json').write_text(json.dumps(parsed,indent=2))
    results.append(receipt)
receipt={'attempt':str(attempt.relative_to(ROOT)),'checks':results,'all_passed':all(r['returncode']==0 for r in results)}
(attempt/'receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
sys.exit(0 if receipt['all_passed'] else 1)
