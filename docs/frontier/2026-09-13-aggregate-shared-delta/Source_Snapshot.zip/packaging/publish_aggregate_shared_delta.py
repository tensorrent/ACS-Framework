from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-shared-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

for name in ['Shared_Audit.json','Local_Audit.json','Adversary_Audit.json']:(OUT/name).write_bytes((BASE/name).read_bytes())
archive('Shared_Local_Certificates.zip',[(BASE/n,n) for n in ['Shared224.json','Shared320.json','Local160.json','Local224.json']])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==7 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
shared=read(BASE/'Shared320.json');local=read(BASE/'Local224.json');la=read(BASE/'Local_Audit.json')
fields=['observation_index','profile','baseline_unique_targets','first_local_unique_targets','joint_unique_targets','joint_unique_support']
write('Aggregate_Shared_Summary.json',{'recorded_utc':now,
    'result':'Common-root error cancellation increases sufficient noise radii, and alternating generic local models with spectral rows recovers all seventeen targets in both aggregate spectra.',
    'inherited_input_contract':['degree four','signature (0,2)','discriminant 576','complete aggregate finite critical-line root intervals through height 20'],
    'additional_local_profiles':['generic sum(e*f)=4 local models','optionally ramification exactly at primes dividing discriminant'],
    'not_decoder_inputs':['Galois group','field candidate catalogue','subfields','defining polynomials','conductor-parity assignment','held-out arithmetic'],
    'new_roots_computed':0,'measurement_rows':17,'generic_coefficients':604,'radius_results':shared['results'],
    'generic_unramified_radius_results':la['shared_radius_with_generic_local_rule'],
    'local_feedback_results':[{k:c[k] for k in fields} for c in local['cases']],
    'largest_tested_generic_box_radii':{'global_rows':['1/100000','1/10000'],'local_rows':['1/10000','1/100'],'shared_roots':['1/500','1/20']},
    'largest_tested_shared_plus_unramified_radii':['1/200','1/20'],
    'stored_leaf_midpoints_checked':39600,'fresh_complex_interval_leaves':47520,'exact_objective_bounds':144,
    'local_exclusions':3162,'spectral_exclusions':190,'independent_displaced_controls':96,'common_error_premise_controls':2,
    'actual_component_mutations_rejected':10,
    'scope':'Tested sufficient frozen-dual radii, not optimal noise limits. All seventeen targets means prime powers through 31, not all 604 support coefficients. Survivors do not prove global realization. Local rules are separately declared. No new field-class enumeration or full analytic formalization.',
    'full_proof_formalized':False,
    'next_gate':'Optimize duals against the actual shared-error objective and audit higher-order/direct nonlinear enclosures; resolve remaining support coefficients or produce constructive ambiguity under an explicit field contract.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':7,'successful_commands':7,'failed_commands':0,
    'recording_scope':'Seven scientific execution receipts; packaging and the fresh recursive verifier are reported separately in Verification.json. No failed scientific execution in this pass. Earlier failed attempts remain intact in preceding checkpoints.',
    'freeze_boundary':'The two shared-bound runs and two local-feedback runs completed before their independent audits. The producer sources have not been edited after these recorded runs. Held-out arithmetic enters only the independent local validation and adversarial true-coefficient control.',
    'new_derivation':'Signed common-root derivatives are combined before absolute bounding; the unknown-zero tail retains the nonnegative sum of row budgets. The moment budget is recomputed over enlarged root intervals, and full residual support is retained.',
    'ablation':'Global rows, localized separate rows, and shared signed derivatives use the same frozen duals. Degree-only and discriminant-aware local profiles are reported separately, with one pass distinguished from repeated local/spectral feedback.',
    'independence':'Trigonometric and complex-exponential interval routes use different precision and subdivision but share FLINT. Exact integer objective and elimination replay, an independently enumerated local catalogue, and 85-digit mpmath displaced sums provide additional checks. Samples do not replace full interval coverage.',
    'zero_radius_encoding':'Zero-radius and zero-multiplier cases have empty derivative leaves and zero placeholders for additional error; these do not assert a nonzero derivative is zero at radius zero.',
    'premise_controls':'Independent errors assigned to the same root in different rows violate the common-input premise and can exceed the shared bound. These are intentionally inconsistent observations, not actual alternative fields.',
    'unresolved':'The shared-only radius grid leaves non-singleton domains at its next points. At full support, 559 A and 567/566 B domains remain unresolved under the two local profiles. Fixed-point survivors are not global field realizability certificates.',
    'history_policy':'Preserve all 117 branches and the 388-event byte prefix; append five events. Earlier dated checkpoints and pinned code remain unchanged. The ongoing goal remains active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Inherited Python 3.12.14 and pinned libraries. Shared bounds at 224/320 bits with 32/48 leaves per active root; fresh complex audit at 384 bits with 96 leaves; local producer at 256 bits on inherited 160/224-bit measurements; outward integer audit at 192 bits and mpmath at 85 digits. No new packages or Lean modules.'
write('Runtime.json',runtime)
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str((PRIOR/n).relative_to(ROOT)):sha((PRIOR/n).read_bytes()) for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Radius_Audit.json','Input_Provenance.json']},
    'scope':'Inputs are extracted from the preceding immutable checkpoint during verification. No new zero extraction, measurement construction, field metadata, or arithmetic truth is supplied to the new inference producers.'})
write('Primary_Sources.json',{'recorded_utc':now,'new_downloads':0,
    'inherited_record':str((PRIOR/'Primary_Sources.json').relative_to(ROOT)),
    'inherited_record_sha256':sha((PRIOR/'Primary_Sources.json').read_bytes()),
    'sources':read(PRIOR/'Primary_Sources.json')['sources'],
    'scope':'Reuses the previously acquired, hash-checked and visually inspected explicit-formula and coefficient-bound references. No new download or fresh page inspection is claimed this pass. Common-root bounds follow the displayed mean-value derivation; local models follow degree partitions and Euler-factor coefficients.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Aggregate shared-error and local-feedback delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],
    advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Common-root dual error bounds with three ablations, generic local/spectral feedback, complex interval and exact integer replay, and targeted proof-component corruption tests.',
    next_priority=['R12/R13: optimize the frozen duals for shared input uncertainty and compare higher-order or direct nonlinear enclosures',
      'R13/R14: resolve remaining support coefficients or construct genuine ambiguity; distinguish local and spectral feasibility from global realization',
      'R15: extend direct aggregate recovery to additional certified fields under an explicit metadata and observation contract',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('shared_root_cancellation_improves_aggregate_noise_certificates',
   'With the same frozen c7 duals, shared finite-root derivative bounds preserve singleton recovery through tested radii 0.002 for A and 0.05 for B, versus global-row baselines 0.00001 and 0.0001. Independent localization accounts for 10x/100x, with cancellation adding 20x/5x. Unknown-zero tails and residual supports are retained.',
   'Optimize multipliers against the actual common-input error bound and compare higher-order or direct nonlinear root enclosures without treating a failed sufficient certificate as an information limit.'),
 'R13':('generic_local_spectral_feedback_recovers_all_seventeen_targets',
   'Both degree-only and degree/discriminant local profiles recover all seventeen prime-power targets through 31 after alternating generic local projections with the inherited spectral rows. Baseline uniqueness 13/9 and one-pass local uniqueness 14/11 or 15/12 are distinguished. All 604 held-out true coefficients survive.',
   'Investigate the remaining 559 A and 567/566 B support domains, strengthen joint deductions, and require constructive feasibility before claiming ambiguity.'),
 'R14':('independent_local_catalogue_and_ramification_ablation',
   'An independent partition/divisor-pair enumeration yields eleven local degree-four models. Eight exact integer replays validate 3162 local and 190 spectral removals. The discriminant profile adds B coefficient 2401 from {2,4} to {4}. Generic unramified c7 excludes three, extending A shared recovery from tested 0.002 to 0.005.',
   'Extend generic local and global realizability comparisons while keeping the extra ramification assumption separate from generic-box and degree-only claims.'),
 'R15':('common_input_and_generic_local_information_contract_audited',
   'Direct aggregate recovery now separates three error models and two generic local-information profiles without a Galois group or field candidate list. Two deliberately inconsistent row-error controls exceed the shared bound, exposing the common-root premise. Ten semantic component mutations are rejected.',
   'Test additional actual fields and explicitly match permitted metadata, completeness and noise assumptions before comparing identification systems.'),
 'K04':('ongoing_delta_with_shared_error_and_local_feedback_audits',
   'Preserve 117 branches and 388 events; append five events. Seven scientific command receipts all succeed. Fresh audits check 39600 stored midpoints, 47520 independent complex interval leaves, 144 integer objective bounds, 3352 local/spectral removals, 96 displaced sums and ten component mutations.',
   'Continue evidence-backed deltas across the full queue with immutable originals, explicit assumptions, unsuccessful attempts, independent checks and exact continuation gates; do not claim global completion or exhaustion.')}
prefix='docs/frontier/2026-09-13-aggregate-shared-delta/'
for branch in q['branches']:
    branch['prior_delta_evidence']=branch.get('prior_delta_evidence',[])+branch['new_evidence'];branch['new_evidence']=[];branch['assessment_this_pass']='carried_forward_not_newly_audited'
    if branch['id'] in updates:
        status,result,gate=updates[branch['id']]
        branch.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_aggregate_shared_and_local_audit')
        branch['new_evidence']=[prefix+n for n in ['Aggregate_Shared_Summary.json','Shared_Audit.json','Local_Audit.json','Adversary_Audit.json','Shared_Local_Certificates.zip','Inherited_Inputs.json']]
        branch['verification_routes']+=['Three error ablations with identical frozen multipliers','Independent complex-exponential interval cover and exact integer objective replay',
            '85-digit common and deliberately inconsistent displaced-root controls','Independent degree partition catalogue and alternating local/spectral replay','Ten semantic proof-component mutations']
        branch['shared_assumptions_and_scope']='Inherited degree four, signature (0,2), discriminant 576 and complete finite critical-line spectrum through 20. Shared-error results preserve common root displacements and finite membership; unknown-zero tails remain unconditional. Local-degree and ramification assumptions are separately declared. No group, field candidate catalogue or held-out truth used by inference. Full analytic proof unformalized; remaining candidates need not be globally realizable.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=388
for bid in q['advanced_existing_branches']:
    branch=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'aggregate_shared_and_local_evidence_advanced','branch_id':bid,
       'result':branch['latest_scoped_result'],'evidence':branch['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Aggregate shared-error and local-feedback delta — 13 September 2026

The existing aggregate spectra now recover all 17 prime-power targets through 31 when generic local-degree rules and spectral inequalities are alternated. Shared root-error bounds also extend the tested sufficient coefficient-seven radii from 0.00001 to 0.002 for A and from 0.0001 to 0.05 for B. These are scoped advances; the ACS investigation remains ongoing.

No new zeros, field templates, Galois groups or held-out arithmetic are supplied to inference. This pass inherits the [preceding measurements and input contract](../2026-09-13-aggregate-delta/README.md). The [derivation and replay guide](../../../code/frontier_verification/AGGREGATE_SHARED_README.md) explains signed derivative cancellation, retained unknown-zero tails and residual support, local-degree models, and the limits of each result.

The radius comparison holds the dual multipliers fixed. Localizing each row derivative alone improves tested radii by 10x and 100x; adding signed cancellation contributes a further 20x and 5x. The generic unramified-prime rule separately excludes coefficient three and extends A's tested radius to 0.005. These are grid-tested sufficient certificates, not optimal noise thresholds or proofs of alternate fields at larger radii.

The baseline recovers 13/9 targets. One generic local pass reaches 14/11 using degree alone or 15/12 using discriminant ramification. Repeating local projections and spectral exclusions reaches 17/17 in both profiles. Full support remains partly unresolved: A has 45 singleton domains out of 604, B has 37 with degree alone and 38 with ramification. Local and spectral survivors need not describe a globally realizable field.

Evidence is preserved in:

- [Results and ablations](Aggregate_Shared_Summary.json), with all tested radius domains and both local profiles.
- [Shared and local certificates](Shared_Local_Certificates.zip), retaining both precision runs, exact interval leaves and every local/spectral iteration.
- [Independent shared-error audit](Shared_Audit.json): 39,600 stored midpoint checks, 47,520 fresh complex interval leaves, 144 exact integer objective bounds and 96 high-precision displaced sums. Two deliberately inconsistent row-error controls demonstrate the common-input premise.
- [Independent local audit](Local_Audit.json): separately enumerated eleven-model catalogue, 3,162 local and 190 spectral removals across eight cases, with all 604 held-out true coefficients retained.
- [Ten actual proof-component mutations](Adversary_Audit.json), each tested against an intact baseline and a semantic rejection predicate.
- [Seven execution receipts](Execution_Receipts.json), [complete outputs](Execution_Artifacts.zip), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json), [reused primary sources](Primary_Sources.json), and [development notes](Development_Notes.json).
- [Manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [393-event ledger](Branch_Events.jsonl), preserving the prior 388 events byte for byte.

Both interval routes share FLINT. Different derivative formulas, subdivisions, exact integer arithmetic, independent local enumeration and mpmath controls provide complementary checks. The finite spectrum's completeness and membership remain assumptions, and the complete analytic/number-field argument is not formalized in Lean. Zero-radius derivative placeholders encode zero additional error, not a claim that the derivative vanishes.

The next gate is to optimize multipliers for shared input error and compare higher-order or direct nonlinear enclosures, while addressing the remaining support coefficients and additional verified fields. Branches not advanced in this pass are carried forward with their existing questions and evidence.
''')
names=['dedekind_aggregate_shared.py','dedekind_aggregate_local.py','dedekind_aggregate_shared_audit.py','dedekind_aggregate_local_audit.py','dedekind_aggregate_shared_adversary.py','verify_aggregate_shared_delta.py','AGGREGATE_SHARED_README.md']
deps=['dedekind_coefficient_recovery.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','dedekind_aggregate_integer_audit.py','verify_aggregate_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},
    'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New shared-error and local-feedback instruments, their direct dependencies, and immutable producer versions used for all seven recorded scientific runs. Earlier dependencies and dated packages are verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+
    [(BASE/n,'packaging/'+n) for n in ['run_recorded.py',Path(__file__).name]])
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
    'scope':'Manifest and Verification excluded from self-reference; preceding checkpoint is checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
