"""Evaluate a candidate inverse-sensitivity maximizing corner; no global bound claim."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_audit import SPECS,jets
from dedekind_weighted_region_certificate import av,enc,dyadic_upper
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inverse(y):
 J=arb_mat([[jets(spec,av(x))[1] for x in y] for spec in SPECS]);det=J.det();assert det>0 or det<0;Y=J.inv();return Y,det

def run():
 a=json.loads(ANCHOR.read_text());g=json.loads((BASE/'Gradient_Sign_Exploration.json').read_text());res=json.loads((BASE/'Signed_Resolvent_Exploration.json').read_text());c=list(map(F,a['common_rational_coordinates']));eta=F(1,100);v=res['critical_sign_vector'];signs=[x['candidate_K_derivative_sign'] for x in g['checks'][-1]['columns']];assert signs.count(0)==1 and signs[12]==0
 y=[x+eta*s for x,s in zip(c,signs)];checks=[]
 for bits in [1024,1536]:
  ctx.prec=bits;Y,det=inverse(y);u12=sum((Y[12,k]*v[k] for k in range(22)),arb(0));assert u12>0 or u12<0;direction=1 if u12>0 else -1
  # The recorded critical-row curvature factor for coordinate 12 is negative.
  assert g['checks'][-1]['columns'][12]['curvature_sign']==-1
  corner=list(y);corner[12]=c[12]+eta*direction;Z,cornerdet=inverse(corner);K=sum((abs(Z[1,k]) for k in range(22)),arb(0));row_signs=[1 if Z[1,k]>0 else -1 if Z[1,k]<0 else 0 for k in range(22)];assert row_signs==v
  ku=dyadic_upper(K,80);gap=F(a['source_threshold_lower'])-(F(a['source_threshold_upper'])-F('1e-8'))
  checks.append({'precision_bits':bits,'face_reference_coordinates':list(map(str,y)),'reference_determinant':enc(det),'reference_u12':enc(u12),'coordinate_12_candidate_direction':direction,
   'candidate_corner_coordinates':list(map(str,corner)),'corner_determinant':enc(cornerdet),'corner_critical_inverse_row':[enc(Z[1,k]) for k in range(22)],'corner_inverse_row_norm':enc(K),'corner_norm_upper':str(ku),'corner_norm_display':float(K.mid()),
   'conditional_noise_guarantee_if_corner_maximum_proved':str(gap/ku),'conditional_noise_guarantee_display':float(gap/ku)})
 return {'status':'candidate_corner_evaluated_not_global_certificate','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [ANCHOR,BASE/'Gradient_Sign_Exploration.json',BASE/'Signed_Resolvent_Exploration.json',CODE/'dedekind_augmented_feature_audit.py',CODE/'dedekind_weighted_region_certificate.py']},'checks':checks,
  'candidate_bridge':'For a mixed/secant matrix M whose columns lie in convex hulls of kernel-derivative curves, replace one column by its maximizing endpoint. The exact inverse difference is rank one: K(M_new)-K(M_old)=-[e1^T M_new^-1*(column_new-column_old)]*(M_old^-1 v)_j. Uniform curvature and inverse-direction signs would make each of 21 replacements nondecreasing. With all other columns fixed, the numerator of (M^-1 v)_12 is independent of column 12 by Cramers rule, and the determinant sign is constant on the connected nonsingular column family, so a single reference sign could resolve the final coordinate. This bridge requires a dedicated complete proof and independent audit.',
  'scope':'Only point inverses and already recorded exploratory factor signs are evaluated. No global or secant-family maximum is claimed. A pointwise maximum alone would not prove finite inverse stability without the explicit matrix-family bridge.'}
r=run();(BASE/'Corner_Inverse_Exploration.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'checks':[{k:x[k] for k in ['precision_bits','coordinate_12_candidate_direction','corner_norm_display','conditional_noise_guarantee_display']} for x in r['checks']]},indent=2))
