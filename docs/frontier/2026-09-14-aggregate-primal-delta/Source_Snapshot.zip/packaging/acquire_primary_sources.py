import hashlib,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).absolute().parent
sources=[]
for stem,title,version,locations in [('FT','Fields and Galois Theory','5.10, September 2022',['Proposition 4.1 and Corollary 4.2, printed pp. 47–48 / PDF pages 47–48']),('ANT','Algebraic Number Theory','3.08, July 2020',['Remark 2.25 and Proposition 2.26, printed p. 34 / PDF page 36','Proposition 2.40, sign of discriminant','Theorem 3.35, ramification criterion','Corollary 8.22 and Theorem 8.23, printed pp. 145–146 / PDF pages 147–148'])]:
 url='https://www.jmilne.org/math/CourseNotes/'+stem+'.pdf'
 with urllib.request.urlopen(url,timeout=60) as response:raw=response.read();final=response.url
 assert raw.startswith(b'%PDF')
 (root/(stem+'.pdf')).write_bytes(raw)
 sources.append({'author':'J. S. Milne','title':title,'version':version,'url':url,'resolved_url':final,'retrieved_utc':datetime.now(timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'locations':locations,'redistributed_in_repository':False})
result={'status':'passed','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'new_downloads':2,'sources':sources,'scope':'Primary source fingerprints and theorem locations. No PDF redistribution. The report supplies its own field-basis and finite-etale derivations and does not apply power-basis factorization at an index prime.'}
(root/'Primary_Sources.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
