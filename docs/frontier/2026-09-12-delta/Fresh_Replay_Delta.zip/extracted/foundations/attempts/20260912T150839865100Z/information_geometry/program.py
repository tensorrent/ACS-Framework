"""New, explicitly scoped instruments derived from the supplied ACS definitions.

No external implementation or physical dynamics are silently supplied.
Two routes are algebraic calculation and separate finite probability/orbit checks.
"""
import itertools, json, math
from collections import defaultdict
from fractions import Fraction as F
import sympy as s


def entropy(law):
    return -sum(float(p)*math.log2(float(p)) for p in law.values() if p)


def marginal(rows, cols):
    out=defaultdict(F)
    for row,p in rows:
        out[tuple(row[i] for i in cols)]+=p
    return out


def cmi_two_routes(rows, ac, bc, cc):
    """I(A;B|C), once through entropy, once through the likelihood ratio."""
    abc=marginal(rows,ac+bc+cc); acm=marginal(rows,ac+cc)
    bcm=marginal(rows,bc+cc); cm=marginal(rows,cc)
    h=entropy(acm)+entropy(bcm)-entropy(cm)-entropy(abc)
    direct=0.
    for row,p in rows:
        a=tuple(row[i] for i in ac); b=tuple(row[i] for i in bc); c=tuple(row[i] for i in cc)
        ratio=abc[a+b+c]*cm[c]/(acm[a+c]*bcm[b+c])
        direct+=float(p)*math.log2(float(ratio))
    assert abs(h-direct)<1e-12
    return {'entropy_identity_bits':h,'conditional_likelihood_bits':direct}


out={}
# I01: reference measure dependence is visible inside the stated formula.
x=s.symbols('x',real=True)
alpha=s.sqrt(2)
# f=(sin x,0), g=(sqrt(2)-sin x,1), f+g irrational translation on T^2.
f=s.Matrix([s.sin(x),0]);g=s.Matrix([alpha-s.sin(x),1])
reference_coefficient=s.integrate(2*s.sin(x)**2-alpha*s.sin(x),(x,0,2*s.pi))/(2*s.pi)
assert s.simplify(reference_coefficient)==1
# Independent Fourier coefficient: 2 sin^2 x=1-cos 2x; all sine/cosine means vanish.
assert s.trigsimp(2*s.sin(x)**2-(1-s.cos(2*x)))==0
e=s.symbols('e',real=True)
# KL Taylor example p_e=(1/2+e,1/2-e), q_e=(1/2,1/2).
kl=(s.Rational(1,2)+e)*s.log(1+2*e)+(s.Rational(1,2)-e)*s.log(1-2*e)
assert s.diff(kl,e).subs(e,0)==0
assert s.diff(kl,e,2).subs(e,0)==4
# The purported Cartan substitution instead yields -Lf^2-Lg^2, algebraically.
L=s.Matrix([[0,1],[0,0]]);M=s.Matrix([[1,0],[0,-1]])
bad_second=L*M+M*L-(L+M)**2
assert bad_second==-L**2-M**2 and bad_second != L*M-M*L
# Correlated binary stationary variables, future=present at lag zero.
rows=[((u,v,v),F(3,8) if u==v else F(1,8)) for u,v in itertools.product(range(2),repeat=2)]
lagzero=cmi_two_routes(rows,(2,),(0,),(1,))
mi=cmi_two_routes(rows,(0,),(1,),())
assert abs(lagzero['entropy_identity_bits'])<1e-12 and mi['entropy_identity_bits']>0.18
out['I01']={
 'reference_measure_test':{'manifold':'T^2, normalized Haar measure mu; irrational translation f+g=(sqrt(2),1)',
 'f':'(sin x,0)','g':'(sqrt(2)-sin x,1)',
 'nu_1':'mu','nu_2':'exp(cos x) mu / integral exp(cos x) dmu',
 'first_coefficient_nu_1':0,'first_coefficient_nu_2':1,
 'routes':['Symbolic integral over the torus','Fourier constant-term identity'],
 'boundary':'This tests the reference-measure dependence of the stated smooth-field formula. It does not assert that this split satisfies every informal ACS-1/2/3 condition. A reference-independent TE cannot equal both RHS values.'},
 'zero_lag':{'actual_TE':lagzero,'KL_joint_vs_product':mi,
 'obstruction':'At epsilon=0 the manuscript Step 1 RHS is mutual information, while zero-lag TE is identically zero; equality requires extra assumptions and a temporal law.'},
 'KL_jet':{'example_nats':str(s.series(kl,e,0,5)),
 'general_coefficient':'If p_e=p0+e*a+O(e^2), q_e=p0+e*b+O(e^2), normalized and p0>0, then KL=e^2/2 sum (a-b)^2/p0+O(e^3). There is no linear term.',
 'proof':'Expand logs; normalization cancels first derivatives and second-derivative mass terms. Both one-sided TEs starting at conditional independence therefore have zero linear coefficient under a smooth two-sided perturbation.'},
 'Cartan_step':{'given_expression':str(bad_second),'actual_commutator':str(L*M-M*L),
 'identity':'Lf Lg + Lg Lf - (Lf+Lg)^2 = -Lf^2-Lg^2; it is not [Lf,Lg].'}}

# I05: the exact monitor can halt on a nonconvergent cycle.
cycle=[(0,0),(0,1),(1,1),(1,0)]
rows=[]
for k,(u,v) in enumerate(cycle):
    un,vn=cycle[(k+1)%4];rows.append(((u,v,un,vn),F(1,4)))
xy=cmi_two_routes(rows,(3,),(0,),(1,));yx=cmi_two_routes(rows,(2,),(1,),(0,))
assert xy['entropy_identity_bits']==yx['entropy_identity_bits']==1
stepnorm=[sum((cycle[(k+1)%4][i]-cycle[k][i])**2 for i in range(2)) for k in range(4)]
assert stepnorm==[1]*4
# A declared contraction actually controls convergence, independently of TE.
T=s.Matrix([[s.Rational(1,4),s.Rational(1,8)],[s.Rational(1,8),s.Rational(1,4)]])
assert sorted(T.eigenvals())==[s.Rational(1,8),s.Rational(3,8)]
assert max(sum(abs(T[i,j]) for j in range(2)) for i in range(2))==s.Rational(3,8)
out['I05']={'PDR_monitor_counterexample':{'transition':'(x,y) -> (y,1-x)','stationary_law':'uniform on the four-cycle',
 'TE_X_to_Y':xy,'TE_Y_to_X':yx,'delta_I_bits':0,'successive_squared_distance':stepnorm,
 'routes':['Exact conditional mutual information from the 4-state joint law','Explicit orbit shows no state limit; each next coordinate requires the opposite current coordinate'],
 'scope':'A counterexample to the PDR generic information-balance halting rule; no claim that this finite cycle satisfies every smooth ACS definition.'},
 'sufficient_replacement':{'operator':str(T),'contraction_factor':'3/8','routes':['Exact eigenvalue/spectral norm','Independent max-row-sum norm'],
 'residual_bound':'For a q-contraction with a fixed point, ||z-z*|| <= ||z-Tz||/(1-q).','missing_bridge':'Derive a complete-space contraction or Lyapunov drift/coercivity condition from the actual update map; a small signed TE difference supplies neither.'}}

# I07: full source history adds information hidden from its current state.
# U=X_(t-2), V=X_(t-1), W=X_t iid fair; Y_t=U, Y_(t+1)=V.
delay=[((u,v,w,u,v),F(1,8)) for u,v,w in itertools.product(range(2),repeat=3)]
cur=cmi_two_routes(delay,(4,),(2,),(3,));hist=cmi_two_routes(delay,(4,),(1,2),(3,))
assert cur['entropy_identity_bits']==0 and hist['entropy_identity_bits']==1
out['I07']={'delayed_copy_process':'X_t iid fair; Y_t=X_(t-2)',
 'current_state_TE':cur,'full_source_history_TE':hist,
 'routes':['Exact joint-law entropy and likelihood calculations','Independence of X_t from X_(t-1), while source history contains Y_(t+1) exactly'],
 'result':'Current-state TE is 0, full-history TE is 1 bit per step. Earlier OU history<=current comparisons are model/conditioning-specific, not a universal ordering.',
 'missing_bridge':'Name target and source sigma-algebras, lag, transition law and observation noise before using either quantity.'}

# D03: use exactly the manuscript O(4) state carrier and valid endomorphisms.
I=s.eye(4);P=s.diag(-1,1,1,1);Q=I
phi=lambda A:A[0,0]**3
comm=P*Q-Q*P
vals=[phi(P),phi(Q)];mean=sum(vals)/2;var=sum((v-mean)**2 for v in vals)/2
assert comm==s.zeros(4) and var==1
R=s.Matrix([[0,-1,0,0],[1,0,0,0],[0,0,1,0],[0,0,0,1]])
S=s.Matrix([[0,0,-1,0],[0,1,0,0],[1,0,0,0],[0,0,0,1]])
assert R.T*R==S.T*S==I
C=R*S-S*R; defect=s.trace(C.T*C)
obs=lambda A:A[3,3]**3
assert defect>0 and obs(R)==obs(S)==obs(R*S)==obs(S*R)==1
assert C.T*C!=I
# Actual finite sheaf completion: functions on a discrete set of three words.
base=(0,1,2);U=(0,1);V=(1,2)
compatible=glued=0
for a in itertools.product(range(2),repeat=2):
 for b in itertools.product(range(2),repeat=2):
  if a[1]!=b[0]:continue
  compatible+=1; global_values=(a[0],a[1],b[1])
  candidates=[z for z in itertools.product(range(2),repeat=3) if tuple(z[i] for i in U)==a and tuple(z[i] for i in V)==b]
  assert candidates==[global_values];glued+=1
out['D03']={'correction_to_prior_catalog':'The manuscript supplies a state carrier O(4)^Gamma, rewrite endomorphisms, Phi and a variance expression. It does not yet supply a topology/restriction/gluing structure for the object called an orbit sheaf, nor a probability law over schemes.',
 'commuting_positive_variance':{'A':'I_4','P':str(P),'Q':'I_4','Phi':'A[0,0]^3','k':1,'scheme_law':'uniform on two schemes','commutator':str(comm),'declared_variance':str(var)},
 'noncommuting_zero_variance':{'R':str(R),'S':str(S),'Phi':'A[3,3]^3','squared_Frobenius_commutator':str(defect),'declared_variance':0,'observable_order_defect':0,'commutator_in_O4':False},
 'routes':['Exact rational matrix products and orthogonality','Direct two-point probability law and observed word evaluations'],
 'correct_order_observable':'delta_ab(A)=Phi(Ra(Rb(A)))-Phi(Rb(Ra(A))); applying Phi to the ambient commutator is generally undefined and, for nonlinear Phi, does not give this expression.',
 'faithfulness_theorem':'If Phi is injective on the reachable orbit, delta_ab(A)=0 iff the two ordered states agree. If Phi is bi-Lipschitz there with lower constant c>0, c||RaRbA-RbRaA|| <= ||delta_ab(A)||. Injectivity does not make Var(Phi(Ra^k A)) a commutator metric.',
 'semigroup_correction':'Actual endomorphisms compose associatively. Adjoining the empty word gives the free-word action a monoid and hence a one-object category; a failed identification R_ab=Ra Rb for preassigned labels does not negate this category.',
 'sheaf_completion':{'base':'discrete set of words through chosen finite depth','F(U)':'all functions U -> measurement alphabet','restriction':'coordinate deletion','distinguished_section':'w -> Phi(R_w A)','finite_boolean_gluing_cases':compatible,'unique_gluings':glued,
 'independent_argument':'Compatible local functions agree at each common word; their pointwise union is the unique global function. This proves arbitrary-cover gluing, beyond the finite check.',
 'boundary':'An explicit optional completion, not an identification of an unstated intended sheaf or physical geometry.'}}

# G04: Z=1 is not the expectation of log degeneracy minus area cost.
p=[F(2,3),F(1,3)];deg=[2,3];areas=[1,2];beta=math.log(3)
balance=sum(float(q)*(math.log(d)-beta*a) for q,d,a in zip(p,deg,areas))
negh=sum(float(q)*math.log(float(q)) for q in p)
assert abs(balance-negh)<1e-15 and balance<0
assert sum(F(d,3**a) for d,a in zip(deg,areas))==1
ms=[-1,0,1];integer_zero_pairs=[(a,b) for a,b in itertools.product(ms,repeat=2) if a+b==0]
z=s.symbols('z');char=s.expand((z**-1+1+z)**2)
assert len(integer_zero_pairs)==char.coeff(z,0)==3
out['G04']={'counting_identity':{'general':'p_j=d_j exp(-gamma a_j)/Z => E[log d_j-gamma a_j] = -H(p)+log Z. At Z=1 this is -H(p), not zero except for a point mass.',
 'exact_finite_example':{'degeneracies':deg,'area_costs':areas,'gamma':'log 3','Z':'1','probabilities':['2/3','1/3'],'expected_form_minus_cost_nats':balance,'negative_entropy_nats':negh},
 'routes':['Gibbs normalization algebra','Independent direct evaluation in a rational two-level distribution'],
 'boundary':'A state-counting root remains valid for its chosen sum. Identifying that root with temporal TE balance requires a separately derived transition/observation law; iid draws from normalized p have both TE rates zero for every gamma.'},
 'projection_claim_test':{'projection_rule':'sum_i m_i=0','two_integer_spin_1_punctures':integer_zero_pairs,'Laurent_character_constant_term':3,
 'routes':['Enumeration of admissible magnetic labels','Constant coefficient of (z^-1+1+z)^2'],
 'result':'The U(1) zero-projection constraint by itself does not exclude integer-j punctures. Excluding them requires an additional rule; this does not adjudicate every physical horizon prescription.'}}

# G05: fixed internal carrier can coexist with inequivalent principal symbols.
wt,k=s.symbols('omega k',real=True);m=s.symbols('m',positive=True)
J=s.diag(1,-1);assert J**2==s.eye(2)
hyper=-wt**2+k**2;ell=wt**2+k**2
assert s.det(s.diag(-1,1))==-1 and s.det(s.eye(2))==1
assert hyper.subs(wt,k)==0 and ell.subs(wt,k)==2*k*k
out['G05']={'same_internal_grading':str(J),
 'admissible_extra_choices':{'hyperbolic_symbol':str(hyper),'elliptic_symbol':str(ell),'massive_dispersion':'omega^2=k^2+m^2 for any specified m>0'},
 'routes':['Principal-symbol inertia/determinant','Real characteristic cone and arbitrary massive dispersion'],
 'scope':'These are explicit completions of an internal involution with chosen spacetime data, not purported ACS actions. The internal involution remains unchanged in both.',
 'no_go':'An internal involution alone cannot distinguish those differential operators or select m. A specified solder map, spacetime signature, action, normalization, constraints, state space and limiting procedure are needed.',
 'constructive_gate':'If an invertible solder map e:TX -> E and internal bilinear form eta are given, g=e^T eta e has eta inertia by Sylvester congruence. That conditional signature theorem does not determine an action or spectrum.'}

print(json.dumps(out,indent=2))
