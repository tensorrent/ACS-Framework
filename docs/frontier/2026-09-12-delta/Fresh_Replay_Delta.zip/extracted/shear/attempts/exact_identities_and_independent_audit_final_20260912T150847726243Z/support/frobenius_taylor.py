"""Centered parameter Taylor models with Cauchy remainders.

Complex k disks bound the entire Frobenius solution and its omitted spatial
tail. A high-precision center series resolves cancellation; Cauchy bounds
make both the finite coefficient errors and the parameter remainder explicit.
"""
from fractions import Fraction as Q
import math
from flint import arb,acb,acb_series,ctx
from frobenius_jost_v2 import solution
from frobenius_jost import box

def exact(q):
    q=Q(q);return arb(q.numerator)/q.denominator

def determinant_interval(a,b,s,degree=16,radius=Q(1,100),bits=4096):
    a,b,s=Q(a),Q(b),Q(s);center=(a+b)/2;half=(b-a)/2
    assert half<radius
    ctx.prec=128
    kd=acb(arb(exact(center),exact(radius)),arb(0,exact(radius)))
    sd=exact(s);et=sd/kd
    amin=(1+acb(0,1)*et).abs_lower()
    assert amin>1
    n=int(math.ceil(48/math.log(float(amin))))+200
    fb,vb,bounds=solution(kd,et,n=n,bits=128)
    ef=arb(bounds['f_tail']);ev=arb(bounds['v_tail'])
    M_f=fb.abs_upper();M_v=vb.abs_upper()
    rr=exact(half/radius);frac=rr**(degree+1)/(1-rr)
    errf=ef/(1-rr)+M_f*frac;errv=ev/(1-rr)+M_v*frac
    # Use the original three-term scalar recurrence, independent of the
    # diagonal-basis recurrence used for the enclosing Cauchy disk.
    ctx.prec=bits;ctx.cap=degree+2
    K=acb_series([acb(exact(center)),1],prec=degree+1)
    A=1+acb(0,exact(s))/K
    prev=acb_series([0],prec=degree+1);cur=acb_series([1],prec=degree+1)
    f=cur;v=prev
    for j in range(n):
        den=2*A*(j+1)*(j+1+K)
        nxt=(((A+2)*j*j+(A+2*K)*j-2)*cur+(-j*j+j+2)*prev)/den
        prev,cur=cur,nxt;f+=cur;v+=(j+1)*cur
    x=arb(0,exact(half));ff=acb(0);vv=acb(0)
    for j in range(degree,-1,-1):ff=ff*x+f[j];vv=vv*x+v[j]
    ff+=box(errf);vv+=box(errv)
    ki=arb(exact(center),exact(half))
    d=(ki*ff*ff.conjugate()+vv*ff.conjugate()).real
    ctx.prec=128
    return d,{'a':str(a),'b':str(b),'s':str(s),'degree':degree,'radius':str(radius),'terms':n,'bits':bits,'f_parameter_and_tail_error':str(errf),'v_parameter_and_tail_error':str(errv),'complex_disk_f_bound':str(M_f),'complex_disk_v_bound':str(M_v),'complex_disk_tail':bounds,'D':str(d)}
