"""Exploratory sampled-error LP; floating objectives are proposals, not certificates."""
import sys,json,time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy import sparse
from flint import arb,ctx
sys.path.insert(0,str(Path(__file__).absolute().parents[2]/'acs-repo/code/frontier_verification'))
from dedekind_coupled_recovery import decode
from dedekind_coupled_dual import inequalities

BASE=Path(__file__).absolute().parent;OLD=BASE.parent/'aggregate-audit';ctx.prec=256
d=json.loads((OLD/'Measurements224.json').read_text());cases=[]
for obs in range(2):
 roots=json.loads((OLD/'inputs'/f'S{obs+1}_224.json').read_text())['positive_root_intervals']
 mids=np.array([float((arb(x['lo'])+arb(x['hi']))/2) for x in roots]);N=len(roots)
 rows=[{'weights':[decode(w) for w in r['weights']],'R':decode(r['observations'][obs]['unwidened']),'B':decode(r['prime_tail'])} for r in d['rows']]
 A,b=inequalities(rows);A=np.array([[float(v) for v in row] for row in A]);b=np.array([float(v) for v in b]);J=len(b);K=A.shape[1]
 scales=np.array([float(decode(r['scale'])) for r in d['rows']]);u=np.log([r['center'] for r in d['rows']]);col=next(i for i,x in enumerate(d['columns']) if x['n']==7)
 for radius in [.001,.002,.005,.01,.02,.03,.05,.1,.2]:
  delta=arb(str(radius));wide=[arb(x['lo']).union(arb(x['hi']))+arb(0,delta) for x in roots]
  U=decode(d['constant_moment_upper'])-sum((3/(arb('9/4')+x*x) for x in wide),arb(0))
  tails=np.array([float((decode(r['scale'])*U*404*arb('-15.99').exp()*(arb(r['center']).log()/2).cosh()).upper()) for r in d['rows']])
  offsets=np.linspace(-radius,radius,33);positions=mids[:,None]+offsets[None,:]
  diffs=-2*scales[None,None,:]*(np.exp(-.04*positions[:,:,None]**2)*np.cos(positions[:,:,None]*u)-np.exp(-.04*mids[:,None,None]**2)*np.cos(mids[:,None,None]*u))
  signed=np.stack([diffs,-diffs],axis=-1).reshape(N*33,J)
  rootrows=sparse.hstack([sparse.csr_matrix(signed),sparse.csr_matrix((N*33,K)),-sparse.kron(sparse.eye(N),np.ones((33,1)),format='csr')],format='csr')
  coefrows=sparse.hstack([-sparse.csr_matrix(A.T),-sparse.eye(K),sparse.csr_matrix((K,N))],format='csr')
  constraints=sparse.vstack([coefrows,rootrows],format='csr');objective=np.r_[b+np.repeat(tails,2),np.full(K,4.),np.ones(N)]
  for sign in [-1,1]:
   right=np.zeros(K+N*33);right[col]=-sign
   started=time.monotonic();r=linprog(objective,A_ub=constraints,b_ub=right,bounds=(0,None),method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
   out={'observation':obs,'radius':radius,'sign':sign,'status':int(r.status),'objective':float(r.fun) if r.success else None,'seconds':time.monotonic()-started}
   if r.success:out['nonzero_multipliers']=[[i,float(v)] for i,v in enumerate(r.x[:J]) if v>1e-10]
   cases.append(out);print(json.dumps(out),flush=True)
(BASE/'Proposal_Probe.json').write_text(json.dumps({'scope':__doc__,'cases':cases},indent=2)+'\n')
