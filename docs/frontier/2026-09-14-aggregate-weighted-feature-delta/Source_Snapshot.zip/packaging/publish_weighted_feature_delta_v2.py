from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta'
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta';CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_weighted_feature_delta_v2 import summarize,FAILURES,ADVANCED

OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)
    assert (OUT/name).stat().st_size<100*1024**2

documents=['Preconditioned_Taylor_Exploration.json','Weighted_Taylor_Exploration.json','Independent_Weighted_Candidate_Audit.json','Weighted_Region_Certificate.json','Feature_Space_Proposals.json','Feature_Space_Certificate.json','Serialized_Endpoint_Diagnosis.json','Independent_Weighted_Region_Audit_v2.json','Lean_Check.json','Independent_Feature_Space_Audit.json','Adversary_Audit.json','Source_Acquisition.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
reports=[read(BASE/n) for n in ['Weighted_Region_Certificate.json','Independent_Weighted_Region_Audit_v2.json','Feature_Space_Certificate.json','Independent_Feature_Space_Audit.json','Adversary_Audit.json','Lean_Check.json','Serialized_Endpoint_Diagnosis.json']]
write('Weighted_Feature_Summary.json',{'recorded_utc':now,'result':'A 300-million-fold larger certified uniqueness radius and exact componentwise stability lead to uniform feature-noise identification guarantees. Actual feature-space inverse roots give an ambiguity upper bound about 13.1% above the smaller-region guarantee.',
    'derived_results':summarize(*reports),'source_premises':'Inherited complete discriminant-576 two-field metadata class and complete 22-entry positive source prefixes below 39/2. Select before independent root-coordinate errors, preserving all entries and multiplicities.',
    'observation_contract':'The preceding ordered 22 finite kernels, fixed root error r=U-1e-8<L, observations inside the specified standard coordinate cube centered at c, and additional independent absolute feature errors. No raw roots, count profile, infinite moment or unknown tail is silently released.',
    'uniqueness_proof':'Order-6 scalar derivative Taylor bounds retain preconditioner cancellation. Positive exact rational weights give a uniform half-defect bound on standard cubes of radius 0.01 and 0.03. The weighted mean-value argument proves injectivity without claiming a large-region self-map.',
    'stability_proof':'Exact rational elimination verifies a componentwise supersolution identity. Independent real derivative polynomials and a positive Neumann series with an exact geometric tail provide a distinct supersolution route. The critical source gap yields the uniform noise-identification bounds.',
    'actual_ambiguity':'Eight inverse roots for four signed feature target pairs are certified. At tau=2.1e-10 and 2e-10 both fields are source-feasible inside radius 0.01 with common release Phi(c). Two smaller-budget signed pairs are excluded in that region; other directions and releases remain open.',
    'decoder_limit':'Field separation below the guarantee is established conditionally; no arbitrary-data decoder is implemented. The noisy report Phi(c) itself inverts to a vector failing both exact source-feasibility tests, although bounded-error inverse observations from both fields exist.',
    'formal_scope':'Six Lean lemmas prove the finite weighted maximum principle, componentwise supersolution consequence and scalar source-gap/noise logic. The full Taylor/mean-value, interval, modular matrix and field/spectral bridges remain written or computational.',
    'open_gates':'Tighten the restricted noise threshold; optimize feature directions and common releases; implement verified bounded-error inverse decoding; validate parameter families; extend global regions or find counterexamples; improve formal bridges and physical acquisition contracts; continue all wider ACS branches.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==14 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean']]+[(CODE/'proofs/WeightedFeatureStability.lean','WeightedFeatureStability.lean')])
write('Development_Notes.json',{'recorded_commands':14,'successful_commands':12,'failed_commands':2,
    'failures':[{'receipt':'independent-weighted-region','result':'The first independent region auditor reconstructs an Arb ball from serialized exact midpoint/radius data before comparing its upper endpoint. Additional rounding falsely rejects a valid stored bound. It emits no audit JSON. A controlled 1024-bit diagnosis finds 108 reconstruction false rejections among 1936 comparisons and zero exact endpoint violations. Separate v2 compares exact rational midpoint-plus-radius endpoints. The certificate and its bounds are unchanged.'},{'receipt':'weighted-feature-final-verification','result':'The first recursive verifier passes the decoder record to the proposal generator, which expects the midpoint/preconditioner record. It fails with KeyError full_rank_proposal before producing verification output. Separate v2 corrects the input argument and reproduces the original error as a control. All scientific certificates are unchanged.'}],
    'canonical_sources':['code/frontier_verification/verify_aggregate_weighted_feature_delta_v2.py','code/frontier_verification/dedekind_weighted_region_audit_v2.py','code/frontier_verification/proofs/WeightedFeatureStability.lean'],
    'source_policy':'Executed sources, the original failed auditor and its actual receipt remain immutable. The final recursive verifier runs after packaging, preserves a separate external receipt and supplies its exact stdout as Verification.json.',
    'runtime':'No package acquisition, version change or new source roots. Existing pinned Python, FLINT and Lean/mathlib environments are reused.',
    'independence':'Complex Hermite jets and real derivative polynomials provide distinct analytic calculations. Exact elimination and positive Neumann sums provide distinct stability constructions. Both interval methods share FLINT; field classification and finite-source premises are inherited.',
    'negative_results':'Larger-radius failed sufficient bounds and two excluded signed inverse target pairs are preserved with their limited meanings. Neither establishes global noninjectivity or a universal noise impossibility threshold.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned numerical packages and Lean/mathlib revision; no runtime acquisition. Six new weighted maximum-principle and noise lemmas compile. Prior acquisitions remain in their original dated records.')
for key,pkg in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(pkg)
write('Runtime.json',runtime)
paths=[SOURCE/'Equal_Population_Inputs.zip',SOURCE/'Equal_Population_Decoder.json',PRIOR/'Verification.json',PRIOR/'Research_Queue.json',PRIOR/'Branch_Events.jsonl',PRIOR/'Augmented_Proposals_Local.json',CLASS/'Full_Quartic_Class.json',CLASS/'Full_Class_Audit.json',PAIR/'Pair_Arithmetic.json',CODE/'verify_aggregate_augmented_feature_delta.py']+[PRIOR/f'Augmented_Certificate_{s}_v2.json' for s in ['Enlarged','Small','Local']]
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'Complete field classification, finite source populations, rational midpoint/preconditioner and earlier collision witnesses are inherited and recursively verified. Both source precision variants and witness containment are freshly audited.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',CLASS/'Primary_Sources.json',PAIR/'Primary_Sources.json']},
    'new_source_record':'Source_Acquisition.json','scope':'Primary Mathlib Taylor and python-flint Arb constructor documentation was retrieved. Exact pinned Taylor and finite-maximum sources match local Git objects and are archived with the mathlib license. Current web pages are not asserted to match the pinned Git revision. New derivative identities and proofs are independently derived and checked.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Weighted uniqueness regions and two-sided feature-noise delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=ADVANCED,
    replay_scope='Higher-order weighted Taylor bounds, exact componentwise stability, independent real-polynomial positive-series audit, eight feature-space inverse roots and independent complex/arithmetic audit, 52 adversaries and six Lean lemmas. All previous branches remain tracked.',
    next_priority=['R12/R13/R14: tighten the restricted noise threshold, optimize directions/releases, and implement a bounded-error inverse decoder','R15: validate parameter families, global region extensions and remaining Taylor/mean-value/formal bridges','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
    'R12':('bounded_root_and_feature_noise_contract_with_local_threshold_bracket','At fixed root error U-1e-8 and within the radius-0.01 coordinate cube, field identity is guaranteed below approximately 1.768500053e-10 feature error, while certified observations from both fields share a release at 2e-10. The report itself need not invert to a source-feasible vector.','Build a verified bounded-error inverse-set decoder and audit physical feature units and acquisition constraints. Extend regions and population/tail contracts explicitly.'),
    'R13':('conditional_robust_arithmetic_recovery_and_actual_noisy_ambiguity','The uniform local feature-noise guarantee identifies the field and its tracked coefficient vector. At the certified common release with tau=2e-10, independent arithmetic still finds 456 fixed and 148 ambiguous coefficients in the complete two-field class.','Determine the exact local ambiguity threshold and robust coefficient domains for arbitrary noisy releases. Extend metadata classes and global recovery domains without equating local separation with a complete decoder.'),
    'R14':('larger_injective_regions_and_two_sided_noise_bounds','The selected 22-feature map is injective on standard coordinate cubes of radii 0.01 and 0.03, the latter containing all 12 earlier collision witnesses. Exact critical-coordinate stability bounds and eight certified inverse roots bracket the smaller-region noise threshold within a ratio of about 1.1309.','Optimize directions and common feature centers, validate continuous parameter families, and tighten the threshold. Explore global injectivity or counterexamples beyond the certified cubes; failed sufficient bounds are not impossibility results.'),
    'R15':('weighted_maximum_principle_and_independent_precision_audits','Complex higher derivatives and independent real derivative polynomials support weighted Taylor estimates; exact elimination and positive Neumann series independently bound critical inverse sensitivity. Fifty-two mutations reject and six Lean lemmas compile. One endpoint-reconstruction failure is preserved and corrected by exact dyadic endpoint comparison.','Formalize the remaining Taylor/mean-value, matrix and spectral bridges; audit interval representations and bounded-error inverse decoding. Retain exact geometry, remainder factors and target-specific exclusion scope.'),
    'K04':('append_only_weighted_stability_and_noise_delta','All 117 branches and 443 previous events are preserved. Five new events link enlarged uniqueness regions, componentwise stability, two-sided noise evidence, independent audits, six formal lemmas and 14 command receipts including two actual failures.','Continue evidence-backed deltas across the full ACS program, preserve originals and exact open gates, and do not claim global completion or exhaustion.')}
prefix=str(OUT.relative_to(ROOT))+'/'
evidence=['Weighted_Feature_Summary.json','Weighted_Region_Certificate.json','Independent_Weighted_Region_Audit_v2.json','Feature_Space_Certificate.json','Independent_Feature_Space_Audit.json','Serialized_Endpoint_Diagnosis.json','Adversary_Audit.json','Lean_Check.json']
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_weighted_stability_and_feature_noise_audit')
        b['new_evidence']=[prefix+n for n in evidence]
        b['verification_routes']+=['Weighted order-6 Taylor bounds with uniform seventh derivative remainder','Independent real derivative polynomials and positive Neumann series with exact tail','Eight inverse-root contraction certificates and independent complex/modular checks','704 scalar source inequalities and 1128 independent polynomial factorizations','52 semantic adversaries plus exact Taylor, geometry and endpoint controls','Six Lean maximum-principle, stability and noise lemmas']
        b['shared_assumptions_and_scope']='Inherited complete two-field metadata class and complete 22-entry finite prefixes selected before coordinate noise. Standard cubes, fixed root radius and independent feature error units are explicit. Uniform local separation and actual local ambiguity bound a restricted threshold; global recovery and a bounded-error decoder remain open. Both interval routes share FLINT.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=443
for bid in ADVANCED:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'weighted_region_componentwise_stability_and_noise_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Larger uniqueness regions and two-sided feature-noise bounds — 14 September 2026

**The certified 22-feature uniqueness radius grows from 1e-10 to 0.03.** More targeted stability estimates and actual inverse-root witnesses place the local ambiguity threshold between approximately 1.768500053e-10 and 2e-10 under one fixed observation contract. The upper/lower ratio is about 1.1309; the exact threshold remains open.

The [proof and reproduction guide](../../../code/frontier_verification/WEIGHTED_FEATURE_README.md) gives the Taylor remainder, weighted maximum principle, componentwise stability and two-stage noise derivations. The [preceding checkpoint](../2026-09-14-aggregate-augmented-feature-delta/README.md) supplied joint-feature collisions and the original smaller uniqueness region.

- [Results and continuation gates](Weighted_Feature_Summary.json).
- Original [preconditioned Taylor exploration](Preconditioned_Taylor_Exploration.json), [weighted exploration](Weighted_Taylor_Exploration.json), and [independent candidate audit](Independent_Weighted_Candidate_Audit.json), including unsuccessful sufficient bounds.
- [Weighted region and componentwise stability certificate](Weighted_Region_Certificate.json) and [independent real-polynomial/positive-series audit](Independent_Weighted_Region_Audit_v2.json).
- [Feature-space proposals](Feature_Space_Proposals.json), [eight certified inverse roots](Feature_Space_Certificate.json), and [independent complex, source and arithmetic audit](Independent_Feature_Space_Audit.json).
- [Endpoint reconstruction diagnosis](Serialized_Endpoint_Diagnosis.json) and [52 adversaries with exact Taylor/geometry controls](Adversary_Audit.json).
- [Six compiled Lean lemmas](Lean_Check.json) and [sources/compiled artifact](Lean_Artifacts.zip).
- [Primary source acquisition](Source_Acquisition.json), [inherited primary sources](Primary_Sources.json), [runtime](Runtime.json), and [inherited inputs](Inherited_Inputs.json).
- [Fourteen execution receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [preserved failure and correction](Development_Notes.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json), and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [448-event append-only ledger](Branch_Events.jsonl), retaining all 443 previous events byte for byte.

The complete inherited class contains two quartic fields with discriminant 576, each with 22 positive source entries below 19.5. Select before independent root errors and preserve all entries. This pass fixes root error r=U-1e-8<L, uses the preceding ordered 22 finite kernels, and adds independent absolute feature errors. Source populations, finite moments and unknown tails are not interchanged.

Order-6 Taylor bounds for the derivative retain cancellations after applying the rational preconditioner. Positive rational weights certify a uniform derivative defect below one half on standard coordinate cubes of radii 0.01 and 0.03. Weighted-norm reasoning does not change their geometry. All 12 preceding collision witnesses lie in the larger cube; 11 lie in the smaller cube. The resulting injectivity is local, with no large-cube fixed-point self-map or global theorem claimed.

Exact componentwise supersolutions bound the critical inverse sensitivity by approximately 56.54509302 and 79.66539048 on the two cubes. Independent real derivative recurrences and a positive Neumann series with an exact tail support those bounds using a different construction. The source gap implies uniform field identification for feature error strictly below approximately 1.768500053e-10 on the smaller cube or 1.255250234e-10 on the larger cube.

Eight exact inverse roots realize four signed feature target pairs around the common report Phi(c). Two pairs, at feature budgets 2.1e-10 and 2e-10, are source-feasible for both fields inside the smaller cube. Two lower-budget signed pairs are excluded there; other targets, directions and reports remain possible. The actual construction at 2e-10 bounds the restricted ambiguity threshold from above, while the uniform separation result bounds it from below. No global optimal threshold or arbitrary-data decoder is claimed.

At the common noisy report, independent arithmetic confirms 456 fixed and 148 ambiguous entries among 604 tracked coefficients, using 1128 polynomial factorizations and 1208 comparisons. Below the uniform guarantee the field and tracked arithmetic vector are unique under the same premises. Inverting only the common report would miss the noisy possibilities: its inverse c fails exact source feasibility for both fields, while bounded-error inverse observations exist for both.

The original independent region auditor falsely rejected a serialized bound after reconstructing an Arb ball. A controlled 1024-bit diagnosis records 108 reconstruction false rejections among 1936 comparisons and zero exact endpoint violations. A separate v2 auditor compares exact rational endpoints; no certificate bound was relaxed. The source, actual failure receipt and correction are preserved. Fourteen development commands contain 12 successes and two failures. The first full verifier also failed after passing a decoder record where the proposal generator expects its midpoint/preconditioner record. Its source and KeyError receipt remain preserved beside a separate v2 verifier; scientific certificates are unchanged.

Fifty-two mutations and exact polynomial, geometry and serialization controls test the proof assumptions. Six Lean lemmas prove the weighted maximum principle, componentwise supersolution and source-gap/noise consequences. The full analytic, interval, modular and inherited field/spectral chain is not entirely formalized. No runtime version changed and no new source roots were computed.

Next: tighten the local threshold, optimize feature directions and common reports, implement bounded-error inverse decoding, validate parameter families, and extend global regions or construct counterexamples. Natural operators, infinite arithmetic/real-part information, topology, physical acquisition models and private-input gates remain active across the wider ACS program. No global completion is claimed.
''')
names=['dedekind_weighted_region_certificate.py','dedekind_weighted_region_audit.py','dedekind_weighted_region_audit_v2.py','dedekind_feature_space_proposal.py','dedekind_feature_space_certificate.py','dedekind_feature_space_audit.py','dedekind_weighted_feature_adversary.py','check_weighted_feature_lean.py','verify_aggregate_weighted_feature_delta.py','verify_aggregate_weighted_feature_delta_v2.py','WEIGHTED_FEATURE_README.md','proofs/WeightedFeatureStability.lean']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
    p=todo.pop()
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for mod in modules:
            d=CODE/(mod+'.py')
            if d.exists() and d not in seen:
                seen.add(d);todo.append(d)
                if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt');mathlib=ROOT.parent/'acs-research/lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/p,'external/'+p) for p in ['Mathlib/Analysis/Calculus/Taylor.lean','Mathlib/Data/Finset/Max.lean']]+[(mathlib/'LICENSE','external/mathlib-LICENSE')]
explorations=[(BASE/n,'exploration/'+n) for n in ['run_recorded.py','capture_sources.py','explore_preconditioned_taylor.py','explore_weighted_taylor.py','audit_weighted_candidate.py','diagnose_serialized_endpoints.py']]
packaging=[(BASE/n,'packaging/'+n) for n in ['publish_weighted_feature_delta.py','publish_weighted_feature_delta_v2.py']]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'exploration_sources':{n:sha(p.read_bytes()) for p,n in explorations},'packaging_sources':{n:sha(p.read_bytes()) for p,n in packaging},'scope':'All 12 new instruments including failed and corrected auditors and verifiers, transitive local Python imports, original explorations/diagnosis/runner/source-capture, packager and pinned Mathlib references with license.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+explorations+external+packaging)
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. Preceding checkpoints are recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
if '2026-09-14-aggregate-weighted-feature-delta/README.md' not in text:text=text.replace(marker,'- [14 September 2026 weighted stability and feature-noise delta](2026-09-14-aggregate-weighted-feature-delta/README.md): larger uniqueness regions, exact componentwise stability, and two-sided local noise bounds.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-augmented-feature-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-weighted-feature-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':14,'successes':12,'failures':2,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
