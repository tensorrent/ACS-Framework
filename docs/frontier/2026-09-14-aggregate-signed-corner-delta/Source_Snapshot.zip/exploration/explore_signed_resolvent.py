"""Exploratory exact signed-resolvent bounds; requires independent bridge and proof audit."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_weighted_region_certificate import solve_exact
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
REGION=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Weighted_Region_Certificate.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 a=json.loads(ANCHOR.read_text());cert=json.loads(REGION.read_text());R=[list(map(F,row)) for row in a['full_rank_proposal']['preconditioner']];v=[1 if x>0 else -1 for x in R[1]];u0=[sum(row[k]*v[k] for k in range(22)) for row in R];results=[]
 for region in cert['regions']:
  B=[list(map(F,row)) for row in region['exact_nonnegative_majorant']];w=list(map(F,region['positive_rational_weights']));M=[[F(int(i==j))-B[i][j] for j in range(22)] for i in range(22)]
  assert all(x>=0 for row in B for x in row) and all(sum(B[i][j]*w[j] for j in range(22))<w[i]/2 for i in range(22))
  row=solve_exact([[M[j][i] for j in range(22)] for i in range(22)],[F(int(i==1)) for i in range(22)])
  assert all(x>=0 for x in row) and all(sum(row[i]*M[i][j] for i in range(22))==int(j==1) for j in range(22))
  delta=[sum((row[i]-int(i==1))*abs(R[i][k]) for i in range(22)) for k in range(22)];assert all(x>=0 for x in delta)
  signed=solve_exact(M,list(map(abs,u0)));assert all(x>0 for x in signed) and all(signed[i]-sum(B[i][j]*signed[j] for j in range(22))==abs(u0[i]) for i in range(22))
  signmargins=[abs(R[1][k])-delta[k] for k in range(22)];flip=2*sum(max(F(0),-x) for x in signmargins);bound=signed[1]+flip;old=F(region['critical_inverse_bound']);gap=F(region['source_threshold_lower'])-F(region['root_coordinate_error_radius'])
  results.append({'radius':region['radius'],'positive_resolvent_critical_row':list(map(str,row)),'critical_inverse_row_deviation_bounds':list(map(str,delta)),
   'critical_inverse_row_sign_margins':list(map(str,signmargins)),'all_critical_row_signs_certified':all(x>0 for x in signmargins),'unresolved_sign_indices':[i for i,x in enumerate(signmargins) if x<=0],
   'signed_R_times_v':list(map(str,u0)),'signed_vector_supersolution':list(map(str,signed)),'sign_flip_penalty':str(flip),'candidate_critical_inverse_bound':str(bound),'candidate_bound_display':float(bound),
   'previous_critical_inverse_bound':str(old),'previous_bound_display':float(old),'candidate_improves_previous':bound<old,'candidate_noise_guarantee':str(gap/bound),'candidate_guarantee_display':float(gap/bound)})
 return {'status':'exact_exploration_requires_independent_proof_audit','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [ANCHOR,REGION,CODE/'dedekind_weighted_region_certificate.py']},'critical_sign_vector':v,'regions':results,
  'candidate_argument':'For any secant matrix with E=I-R*Jbar and |E|<=B, Y=Jbar^-1=(I-E)^-1 R. The positive resolvent bounds each critical-row deviation from R. Bound Y*v by a supersolution for |R*v|. Then sum |Y_1k| <= (Y*v)_1 + 2 sum max(0, deviation_k-|R_1k|), using the exact critical sign vector v. If no sign can flip, the penalty is zero. This uses the entire secant matrix family, not a pointwise derivative inverse bound requiring convex feature images.',
  'scope':'Exact rational linear algebra from the inherited Taylor majorant. The signed-resolvent/positive-matrix and secant-to-stability arguments need dedicated independent verification, adversaries and formalization. No new bound is published in frozen checkpoint 30.'}
r=run();(BASE/'Signed_Resolvent_Exploration.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'regions':[{k:x[k] for k in ['radius','all_critical_row_signs_certified','unresolved_sign_indices','candidate_bound_display','previous_bound_display','candidate_improves_previous','candidate_guarantee_display']} for x in r['regions']]},indent=2))
