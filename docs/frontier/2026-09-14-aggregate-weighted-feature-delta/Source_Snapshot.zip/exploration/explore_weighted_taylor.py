"""Exploratory higher-order bounds; not a published or independently audited certificate."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import hashlib,json,sys
import numpy as np
from flint import arb,acb,arb_mat,ctx

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_audit import SPECS,jets as old_jets
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def av(x):
    q=F(x);return arb(q.numerator)/arb(q.denominator)
def enc(x):return {'mid':list(map(int,x.mid().man_exp())),'rad':list(map(int,x.rad().man_exp()))}
def derivatives(spec,x,order):
    if spec['kind']=='rational_moment':
        z=acb(arb(3)/2,x)
        return [2*(acb(0,-1)**n*factorial(n)/z**(n+1)).real for n in range(order+1)]
    a=av(spec['a']);u=arb(spec['center']).log();v=acb(-2*a*x,u);e=acb(-a*x*x,u*x).exp();poly=[acb(1)]
    if order:poly.append(v)
    for n in range(1,order):poly.append(v*poly[n]-2*a*n*poly[n-1])
    return [2*(p*e).real for p in poly]
def run():
    ctx.prec=896;p=json.loads(SOURCE.read_text());assert p['full_rank_proposal']['features']==SPECS
    c=list(map(F,p['common_rational_coordinates']));R=arb_mat([[av(x) for x in row] for row in p['full_rank_proposal']['preconditioner']]);Rabs=arb_mat([[abs(R[i,j]) for j in range(22)] for i in range(22)])
    center=[ [derivatives(spec,av(x),7) for x in c] for spec in SPECS]
    for i,spec in enumerate(SPECS):
        for j,x in enumerate(c):
            assert all(center[i][j][k].overlaps(y) for k,y in enumerate(old_jets(spec,av(x))))
    coefficient_rows=[];coefficient_matrices=[]
    for t in range(6):
        mat=R*arb_mat([[center[i][j][t+1] for j in range(22)] for i in range(22)])
        if t==0:mat=arb_mat([[int(i==j) for j in range(22)] for i in range(22)])-mat
        coefficient_rows.append([sum((abs(mat[i,j]) for j in range(22)),arb(0)) for i in range(22)])
        coefficient_matrices.append(arb_mat([[abs(mat[i,j]) for j in range(22)] for i in range(22)]))
    tests=[]
    for rad in ['1e-10','1e-9','1e-8','1e-7','1e-6','1e-5','1e-4','1e-3','1e-2','3e-2','1e-1']:
        rho=av(rad);X=[av(x)+arb(0,rho.upper()) for x in c];enclosed=[[derivatives(spec,x,7) for x in X] for spec in SPECS]
        for order in [2,4,6]:
            remainder=Rabs*arb_mat([[abs(enclosed[i][j][order+1]) for j in range(22)] for i in range(22)])
            rows=[]
            for i in range(22):
                value=coefficient_rows[0][i]+sum((rho**t/factorial(t)*coefficient_rows[t][i] for t in range(1,order)),arb(0))+rho**order/factorial(order)*sum((remainder[i,j] for j in range(22)),arb(0))
                rows.append(value)
            bound_matrix=coefficient_matrices[0]+sum((coefficient_matrices[t]*(rho**t/factorial(t)) for t in range(1,order)),arb_mat(22,22))+remainder*(rho**order/factorial(order))
            eigvals,eigvecs=np.linalg.eig(np.array([[float(bound_matrix[i,j].upper()) for j in range(22)] for i in range(22)]))
            which=int(np.argmax(eigvals.real));weights=np.abs(eigvecs[:,which].real);weights/=max(weights)
            assert all(np.isfinite(x) and x>0 for x in weights)
            rational_weights=[F(format(float(x),'.17g')) for x in weights]
            weighted_rows=[sum((bound_matrix[i,j]*av(rational_weights[j]) for j in range(22)),arb(0))/av(rational_weights[i]) for i in range(22)]
            tests.append({'radius':str(F(rad)),'derivative_Taylor_order':order,'rows':[enc(x) for x in rows],'q_max_display':max(float(x.upper()) for x in rows),'all_below_half':all(x<arb(1)/2 for x in rows),'all_below_one':all(x<1 for x in rows),
                'positive_rational_weights':list(map(str,rational_weights)),'weighted_rows':[enc(x) for x in weighted_rows],'weighted_q_max_display':max(float(x.upper()) for x in weighted_rows),'weighted_all_below_half':all(x<arb(1)/2 for x in weighted_rows),'weighted_all_below_one':all(x<1 for x in weighted_rows)})
    return {'status':'exploratory_bounds_require_independent_proof_audit','source_sha256':sha(Path(__file__)),'inputs_sha256':{SOURCE.name:sha(SOURCE),'dedekind_augmented_feature_audit.py':sha(CODE/'dedekind_augmented_feature_audit.py')},
        'precision_bits':896,'orders':[2,4,6],'common_coordinates':p['common_rational_coordinates'],'features':SPECS,
        'half_minimum_coordinate_spacing':str(min(y-x for x,y in zip(c,c[1:]))/2),
        'preconditioned_center_coefficient_row_maxima_display':[max(float(x.upper()) for x in row) for row in coefficient_rows],
        'center_first_two_derivatives_agree_with_preceding_complex_auditor':True,'radius_tests':tests,
        'candidate_argument':'Taylor-expand each derivative column about its rational coordinate center. Apply R before absolute values to point coefficients, retaining cancellations; bound only the highest-order remainder using |R| times interval derivative magnitudes. Positive rational weights are proposed by a binary64 eigenvector calculation and then checked by Arb row sums; no floating eigensolver result is used as a proof. A separate proof and independently implemented audit are required before treating these as certified neighborhoods.',
        'scope':'Exploration separate from frozen checkpoint 28; no global injectivity, optimal neighborhood or publication claim.'}
r=run();(BASE/'Weighted_Taylor_Exploration.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'coefficient_maxima':r['preconditioned_center_coefficient_row_maxima_display'],'radius_tests':[{k:x[k] for k in ['radius','derivative_Taylor_order','q_max_display','weighted_q_max_display','weighted_all_below_half','weighted_all_below_one']} for x in r['radius_tests']]},indent=2))
