"""High-precision local slice proposal, not a rigorous feature-collision certificate."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as Q
import hashlib,json
import numpy as np
from scipy.linalg import qr
import mpmath as mp
BASE=Path(__file__).absolute().parent
SOURCE=BASE.parent/'aggregate-equal-population-audit/Equal_Population_Decoder.json'
data=json.loads(SOURCE.read_text());m=next(c for c in data['matching_cases'] if c['precision_bits']==224)
mp.mp.dps=120
def mf(q):q=Q(q);return mp.mpf(q.numerator)/q.denominator
centers=[mf(x) for x in m['common_observation']];indices=[2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31];u=[mp.log(n) for n in indices];a=mp.mpf(1)/25
def feature(x,t):return 2*mp.exp(-a*x*x)*mp.cos(t*x)
def derivative(x,t):return 2*mp.exp(-a*x*x)*(-2*a*x*mp.cos(t*x)-t*mp.sin(t*x))
allowed=[i for i in range(22) if i!=1]
J=np.array([[float(derivative(centers[i],t)) for i in allowed] for t in u]);_,_,pivots=qr(J,pivoting=True,mode='economic');selected=[allowed[int(i)] for i in pivots[:17]]
epsilon=mp.mpf('1e-12');A=list(centers);B=list(centers);A[1]+=epsilon;B[1]-=epsilon
w=mp.matrix([0]*17);history=[]
def residual(w):
    values=list(A)
    for j,i in enumerate(selected):values[i]+=w[j]
    return mp.matrix([sum(feature(x,t) for x in values)-sum(feature(x,t) for x in B) for t in u])
def jacobian(w):return mp.matrix([[derivative(A[i]+w[j],t) for j,i in enumerate(selected)] for t in u])
for iteration in range(8):
    f=residual(w);history.append({'iteration':iteration,'max_residual':mp.nstr(max(abs(x) for x in f),110),'max_correction':mp.nstr(max(abs(x) for x in w),110)})
    if max(abs(x) for x in f)<mp.mpf('1e-100'):break
    w-=mp.lu_solve(jacobian(w),f)
for j,i in enumerate(selected):A[i]+=w[j]
R=jacobian(w)**-1
radius=Q(m['radius_upper'])-Q(1,10**12)
margins=[]
for name,values in [('A',A),('B',B)]:
    for i,x in enumerate(values):
        endpoints=[mf(v) for v in m['pairs'][i][name+'_interval']]
        margins.append(mf(radius)-max(abs(x-v) for v in endpoints))
out={'status':'high_precision_proposal_not_interval_certified','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
     'centers':indices,'gaussian_a':'1/25','critical_index':1,'critical_split_epsilon':'1/1000000000000','common_rational_coordinates':m['common_observation'],'selected_A_variable_indices':selected,'radius':str(radius),
     'source_threshold_lower':m['radius_lower'],'proposed_radius_below_L':radius<Q(m['radius_lower']),'mpmath_dps':mp.mp.dps,'iterations':history,
     'corrections':[mp.nstr(x,110) for x in w],'preconditioner':[[mp.nstr(R[i,j],110) for j in range(17)] for i in range(17)],
     'max_residual':mp.nstr(max(abs(x) for x in residual(w)),110),'max_correction':mp.nstr(max(abs(x) for x in w),110),'minimum_computed_endpoint_margin':mp.nstr(min(margins),110),
     'scope':'Acritical coordinate is raised by epsilon and Bcritical lowered by epsilon from the common rational center. Seventeen noncritical A coordinates are adjusted. Arbitrary-precision Newton arithmetic gives a proposal only. Exact critical endpoint margins may be zero by design; rigorous enclosure and self-map bounds are still required.'}
(BASE/'Local_Slice_Proposal.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['status','selected_A_variable_indices','proposed_radius_below_L','max_residual','max_correction','minimum_computed_endpoint_margin']}))
