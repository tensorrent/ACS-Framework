from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

base=Path(__file__).absolute().parent
mathlib=base.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip()
assert revision=='be865aa50cc0364be66c3941a6dc0c845a2c2ceb'
records=[]
for relative in ['Mathlib/Analysis/Calculus/MeanValue.lean','Mathlib/Analysis/Normed/Group/Basic.lean']:
    raw=(mathlib/relative).read_bytes()
    assert raw==subprocess.check_output(['git','show','HEAD:'+relative],cwd=mathlib)
    records.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'matches_pinned_git_object':True})
out={'status':'passed','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
     'mathlib_revision':revision,'pinned_sources':records,
     'retrieved_primary_documentation':{'url':'https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Calculus/MeanValue.html',
         'retrieval':'Successfully opened with the web tool on 14 September 2026.',
         'relevant_results':['Convex.norm_image_sub_le_of_norm_hasFDerivWithin_le','Convex.norm_image_sub_le_of_norm_fderiv_le','Convex.norm_image_sub_le_of_norm_fderiv_le\''],
         'use':'Primary documentation for the derivative-bound to Lipschitz step. The current web page is not asserted to be the exact pinned runtime revision.'},
     'runtime_change':'No package acquisition or version changes. The new generic Lean lemmas use the already available normed-group and tactic modules; the full vector mean-value bridge remains a written derivation.',
     'scope':'Exact local reference sources are compared to their pinned Git objects and archived with the existing mathlib license. Current primary documentation supplements, rather than replaces, the pinned source evidence.'}
(base/'Source_Acquisition.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
