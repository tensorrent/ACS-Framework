"""Validated k derivatives at fixed growth s, through second order.

This extends the prior Taylor ODE architecture; it is not the independent
Frobenius route. All parameter coefficients are normalized Taylor coefficients.
"""
from flint import arb,acb,acb_series,ctx
from prior_validated_jost import box,horner

def potential(y,k,s,N):
    p=acb_series([acb(y),1],prec=N+1);e=(2*p).exp();u=(e-1)/(e+1)
    u2=-2*u*(1-u*u);den=k*u-acb(0,s)
    return [u2*k/den,-acb(0,s)*u2/den**2,acb(0,s)*u*u2/den**3]

def jet(W,k,f,v,N):
    fs=[[acb(z)] for z in f];vs=[[acb(z)] for z in v]
    for j in range(N):
        for p in range(3):
            fs[p].append(vs[p][j]/(j+1))
            z=sum((W[q][l]*fs[p-q][j-l] for q in range(p+1) for l in range(j+1)),acb(0))
            vs[p].append((z-2*k*vs[p][j]-(2*vs[p-1][j] if p else 0))/(j+1))
    return fs,vs

def determinant_kk(k,s,steps=360,tail=18,order=16,bits=112):
    ctx.prec=bits;ctx.cap=order+2;k=arb(k);s=arb(s);h=arb(tail)/steps
    # Complex k disk of radius r: Re(k)>0 and Re(s/k)>0.
    # |W| <= |U''|/Re(s/k), integral |U''| <=4 exp(-2L).
    r=arb('0.05');kl=k.lower()-r;ku=k.upper()+r
    assert kl>0 and s>0
    etamin=s.lower()*kl/(ku*ku+r*r)
    at=4*arb(-2*tail).exp()/etamin;bd=(at/(2*kl)).exp()
    fe=bd-1;ve=at*bd
    f=[1+box(fe),box(fe/r),box(fe/r**2)]
    v=[box(ve),box(ve/r),box(ve/r**2)]
    maxrem=arb(0)
    for step in range(steps):
        y=-arb(tail)+step*h;yb=y+arb(h/2,h/2)
        W=potential(y,k,s,order);Wr=potential(yb,k,s,order)
        L=max(arb(1),sum((w[0].abs_upper() for w in Wr),arb(0))+2*k.abs_upper()+2)
        B=(h*L).exp();rf,rv=jet(Wr,k,[box(B)]*3,[box(B)]*3,order)
        remf=[box(rf[p][order].abs_upper()*h**order) for p in range(3)]
        remv=[box(rv[p][order].abs_upper()*h**order) for p in range(3)]
        maxrem=max(maxrem,*[z.abs_upper() for z in remf+remv])
        a,b=jet(W,k,[1,0,0],[0,0,0],order-1)
        c,d=jet(W,k,[0,0,0],[1,0,0],order-1)
        m00=[horner(a[p],h)+remf[p] for p in range(3)]
        m01=[horner(c[p],h)+remf[p] for p in range(3)]
        m10=[horner(b[p],h)+remv[p] for p in range(3)]
        m11=[horner(d[p],h)+remv[p] for p in range(3)]
        f,v=[sum((m00[q]*f[p-q]+m01[q]*v[p-q] for q in range(p+1)),acb(0)) for p in range(3)],[sum((m10[q]*f[p-q]+m11[q]*v[p-q] for q in range(p+1)),acb(0)) for p in range(3)]
    ff=[sum((f[q]*f[p-q].conjugate() for q in range(p+1)),acb(0)) for p in range(3)]
    vf=[sum((v[q]*f[p-q].conjugate() for q in range(p+1)),acb(0)) for p in range(3)]
    D=[(k*ff[p]+vf[p]+(ff[p-1] if p else 0)).real for p in range(3)]
    return D[0],D[1],2*D[2],{'f':[str(x) for x in f],'v':[str(x) for x in v],'tail_f_0_error':str(fe),'tail_v_0_error':str(ve),'cauchy_k_radius':str(r),'max_local_remainder':str(maxrem),'steps':steps,'tail':tail,'order':order,'bits':bits}
