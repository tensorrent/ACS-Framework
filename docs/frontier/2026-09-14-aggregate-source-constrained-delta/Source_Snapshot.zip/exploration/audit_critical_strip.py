"""Independent real-polynomial/Cramer audit of the unpublished critical-strip candidate."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,zipfile
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_signed_corner_audit import real_functions,determinant_ratio,av,enc,validate_exact
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    report=BASE/'Critical_Strip_Exploration.json';certpath=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta/Signed_Corner_Certificate.json';cert=json.loads(certpath.read_text());p=json.loads(report.read_text())
    anchor=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
    region=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Weighted_Region_Certificate.json'
    upper=ROOT/'docs/frontier/2026-09-14-aggregate-variable-noise-delta/Variable_Noise_Certificate.json'
    c,R,v=validate_exact(cert,*[json.loads(x.read_text()) for x in [anchor,region,upper]])
    src=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta/Equal_Population_Inputs.zip'
    with zipfile.ZipFile(src) as z:
        aa=json.loads(z.read('E1_224.json'))['positive_root_intervals'][1];bb=json.loads(z.read('E2_224.json'))['positive_root_intervals'][1]
    r=F(p['root_error_radius']);a=F(aa['lo'])-r;b=F(bb['hi'])+r;gap=(a-b)/2
    T=F(cert['inherited_ambiguity_upper_endpoint']);K=F(cert['corner_uniform_inverse_bound']);cap=2*T*K
    assert gap>0 and F(p['assumed_common_report_budget_at_most'])==T and F(p['inherited_secant_inverse_bound'])==K and F(p['critical_difference_cap'])==cap
    assert list(map(F,p['A_critical_outer_interval']))==[a,b+cap] and list(map(F,p['B_critical_outer_interval']))==[a-cap,b]
    lo,hi=a-cap,b+cap;assert c[1]-F(1,100)<lo<hi<c[1]+F(1,100) and list(map(F,p['critical_secant_coordinate_interval']))==[lo,hi]
    directions=[x['endpoint_direction'] for x in cert['uniform_curvature_checks'][0]['columns']];ref=[x+F(1,100)*s for x,s in zip(c,directions)];ref[1]=hi
    checks=[]
    for bits in [896,1152]:
        ctx.prec=bits;functions=real_functions();J=arb_mat([[fn(av(x))[1] for x in ref] for fn in functions]);u,n,d=determinant_ratio(J,12,v);assert u<0
        corner=list(ref);corner[12]=c[12]-F(1,100);J=arb_mat([[fn(av(x))[1] for x in corner] for fn in functions]);row=[]
        for k in range(22):
            value,_,_=determinant_ratio(J,1,[int(i==k) for i in range(22)]);assert (value>0 if v[k]>0 else value<0);row.append(value)
        norm=sum(map(abs,row),arb(0));claimed=max(F(x['candidate_inverse_bound']) for x in p['checks']);assert norm<av(claimed)
        lower=gap/claimed;assert F(cert['uniform_identification_strictly_below'])<lower<T
        assert all(F(x['candidate_strict_lower_guarantee'])==gap/F(x['candidate_inverse_bound']) for x in p['checks'])
        checks.append({'precision_bits':bits,'face_Cramer_numerator':enc(n),'face_determinant':enc(d),'face_direction_12':enc(u),'corner_inverse_row':[enc(x) for x in row],
            'corner_norm':enc(norm),'claimed_bound_independently_enclosed':True,'conditional_lower':str(lower),'conditional_lower_display':float(lower)})
    return {'status':'independent_exploratory_checks_passed_not_published','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [report,certpath,anchor,region,upper,src,CODE/'dedekind_signed_corner_audit.py']},
        'checks':checks,'source_outer_intervals_rederived':True,'restricted_column_family_is_subset_of_previous_family':True,
        'scope':'Independent exact source endpoints and real-polynomial Cramer ratios support the critical-strip lower candidate. The budget hypothesis tau<=T and the final lower<T check make the proposed bootstrap noncircular, but a dedicated full proof, adversaries, canonical program and recursive verification are required before publication. Numerical routes share FLINT. Checkpoint 31 remains frozen.'}
r=run();(BASE/'Independent_Critical_Strip_Audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'checks':[{'precision_bits':x['precision_bits'],'conditional_lower_display':x['conditional_lower_display']} for x in r['checks']]},indent=2))
