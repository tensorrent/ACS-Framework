"""Independent real-polynomial audit of one unpublished weighted Taylor candidate."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import hashlib,json
import sympy as s
from flint import arb,ctx

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo'
PROPOSAL=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
EXPLORE=BASE/'Weighted_Taylor_Exploration.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def av(x):
    q=F(x);return arb(q.numerator)/arb(q.denominator)
def enc(x):return {'mid':list(map(int,x.mid().man_exp())),'rad':list(map(int,x.rad().man_exp()))}
def add(p,q):return [(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))]
def scale(p,a):return [a*x for x in p]
def deriv(p):return [i*p[i] for i in range(1,len(p))] or [0]
def evaluate(p,x):
    value=0
    for coefficient in reversed(p):value=value*x+coefficient
    return value
def gaussian_polys(a,u,order):
    P=[[1]];Q=[[0]]
    for n in range(order):
        P.append(add(add(deriv(P[n]),[0]+scale(P[n],-2*a)),scale(Q[n],u)))
        Q.append(add(add(deriv(Q[n]),[0]+scale(Q[n],-2*a)),scale(P[n],-u)))
    return P,Q
def moment_polys(d,order):
    P=[[3]]
    for n in range(order):P.append(add(add(scale(deriv(P[n]),d),[0,0]+deriv(P[n])),[0]+scale(P[n],-2*(n+1))))
    return P
def symbolic():
    x,a,u,d=s.symbols('x a u d',real=True);P,Q=gaussian_polys(a,u,7);M=moment_polys(d,7)
    for n in range(8):
        g=2*s.exp(-a*x*x)*(evaluate(P[n],x)*s.cos(u*x)+evaluate(Q[n],x)*s.sin(u*x))
        assert s.simplify(s.diff(2*s.exp(-a*x*x)*s.cos(u*x),x,n)-g)==0
        assert s.factor(s.diff(3/(d+x*x),x,n)-evaluate(M[n],x)/(d+x*x)**(n+1))==0
    return {'orders':list(range(8)),'Gaussian_real_polynomial_identities':'passed','moment_rational_polynomial_identities':'passed'}
def bound(proposal,candidate,bits):
    ctx.prec=bits;specs=proposal['full_rank_proposal']['features'];c=list(map(F,proposal['common_rational_coordinates']));rho=F(candidate['radius']);order=candidate['derivative_Taylor_order'];assert order==6 and rho==F(3,100)
    assert len(specs)==len(c)==22 and specs[17]=={'kind':'rational_moment','numerator':3,'offset':'9/4'}
    assert [x['center'] for x in specs if x['kind']=='gaussian']==[2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31,37,2,41,43]
    assert all(x['a']==('1/24' if i==19 else '1/25') for i,x in enumerate(specs) if x['kind']=='gaussian')
    R=[list(map(F,row)) for row in proposal['full_rank_proposal']['preconditioner']];weights=list(map(F,candidate['positive_rational_weights']));assert len(weights)==22 and all(w>0 for w in weights)
    assert len(R)==22 and all(len(row)==22 for row in R);assert all(x+rho<y-rho for x,y in zip(c,c[1:]))
    point=[];highest=[]
    for spec in specs:
        if spec['kind']=='rational_moment':
            M=moment_polys(F(9,4),7)
            def jets(x):return [evaluate([av(t) for t in M[n]],x)/(av('9/4')+x*x)**(n+1) for n in range(8)]
        else:
            a=av(spec['a']);u=arb(spec['center']).log();P,Q=gaussian_polys(a,u,7)
            def jets(x):return [2*(-a*x*x).exp()*(evaluate(P[n],x)*(u*x).cos()+evaluate(Q[n],x)*(u*x).sin()) for n in range(8)]
        point.append([jets(av(x)) for x in c]);highest.append([abs(jets(av(x)+arb(0,av(rho).upper()))[7]) for x in c])
    rows=[]
    for i in range(22):
        bound_sum=arb(0)
        for j in range(22):
            value=abs(arb(int(i==j))-sum((av(R[i][k])*point[k][j][1] for k in range(22)),arb(0)))
            for t in range(1,6):
                coefficient=sum((av(R[i][k])*point[k][j][t+1] for k in range(22)),arb(0))
                value+=av(rho)**t/factorial(t)*abs(coefficient)
            value+=av(rho)**6/factorial(6)*sum((abs(av(R[i][k]))*highest[k][j] for k in range(22)),arb(0))
            bound_sum+=value*av(weights[j])/av(weights[i])
        assert bound_sum<arb(1)/2
        rows.append({'row':i,'weighted_defect_bound':enc(bound_sum)})
    C=2*max(weights)*max(sum(abs(x) for x in row)/weights[i] for i,row in enumerate(R))
    return {'precision_bits':bits,'rows':rows,'maximum_bound_display':max(float(arb(arb(tuple(x['weighted_defect_bound']['mid'])),arb(tuple(x['weighted_defect_bound']['rad']))).upper()) for x in rows),
            'unweighted_inverse_bound_from_weighted_norm':str(C),'bound_approx_display':float(C),'weight_ratio':str(max(weights)/min(weights))}
p=json.loads(PROPOSAL.read_text());e=json.loads(EXPLORE.read_text());candidate=next(x for x in e['radius_tests'] if F(x['radius'])==F(3,100) and x['derivative_Taylor_order']==6)
assert candidate['weighted_all_below_half'] is True and e['inputs_sha256'][PROPOSAL.name]==sha(PROPOSAL)
identities=symbolic();results=[bound(p,candidate,bits) for bits in [768,1024]]
out={'status':'independent_candidate_audit_passed_not_published','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [PROPOSAL,EXPLORE]},
     'candidate_radius':'3/100','derivative_Taylor_order':6,'symbolic_derivative_identities':identities,'independent_real_polynomial_bounds':results,
     'scope':'Independent real sine/cosine polynomial jets and exact rational moment numerator recurrence reproduce the weighted bound using scalar loops at two precisions. This is separate from frozen checkpoint 28. A complete source/provenance, adversarial and mathematical bridge audit is still required for the next published checkpoint.'}
(BASE/'Independent_Weighted_Candidate_Audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'candidate_radius':out['candidate_radius'],'bounds':[x['maximum_bound_display'] for x in results],'inverse_constant_approx':results[0]['bound_approx_display']},indent=2))
