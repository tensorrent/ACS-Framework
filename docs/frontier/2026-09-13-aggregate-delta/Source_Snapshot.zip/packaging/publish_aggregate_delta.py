from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

for name in ['Integer_Audit.json','Analytic_Audit.json','Radius_Audit.json','Adversary_Audit.json','Source_Recheck.json']:
    (OUT/name).write_bytes((BASE/name).read_bytes())
(OUT/'Input_Provenance.json').write_bytes((BASE/'inputs/Input_Provenance.json').read_bytes())
archive('Aggregate_Inputs.zip',[(BASE/'inputs'/f'{code}_{bits}.json',f'{code}_{bits}.json') for bits in [160,224] for code in ['S1','S2']])
archive('Measurements_Recovery.zip',[(BASE/f'{kind}{bits}.json',f'{kind}{bits}.json') for kind in ['Measurements','Recovery'] for bits in [160,224]])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==11 and sum(r['returncode']==0 for r in receipts.values())==10
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
recovered=read(BASE/'Recovery224.json');integer=read(BASE/'Integer_Audit.json');noise=read(BASE/'Radius_Audit.json');analytic=read(BASE/'Analytic_Audit.json')
summary=[]
for obs in [0,1]:
    result=recovered['results'][obs];bounds=next(r for r in integer['results'] if r['measurement_file']=='Measurements224.json' and r['observation_index']==obs)
    c7=next(r for r in bounds['dual_bounds'] if r['n']==7)
    summary.append({'observation_index':obs,'held_out_field':['A','B'][obs],'monotone_unique_targets':result['monotone_unique_targets'],
                    'continuous_dual_unique_targets':result['dual_unique_targets'],'target_count':17,'coefficient_at_7':c7,
                    'monotone_target_domains':[r for r in result['monotone_exclusion']['domains'] if r['n']<=31],
                    'frozen_c7_radius_results':[{k:r[k] for k in ['radius','c7_candidates']} for r in noise['results'] if r['observation_index']==obs]})
write('Aggregate_Summary.json',{'recorded_utc':now,
    'result':'Direct coefficient-seven recovery from aggregate finite spectra and shared degree/signature/discriminant, without field candidates or local arithmetic seeds.',
    'input_contract':['degree four','signature (0,2)','field discriminant 576','complete aggregate positive critical-line root intervals through height 20'],
    'not_decoder_inputs':['field candidate list','Galois group','defining polynomials','quadratic subfields','character labels','conductor-parity assignment','local-power relations','neighboring coefficients'],
    'new_roots_computed':0,'measurement_rows':17,'gaussian_a':'1/25','center_limit':31,'prime_cutoff':4096,'generic_coefficients':604,
    'results':summary,'exact_exclusions':184,'exact_dual_bounds':136,'radius_exact_dual_bounds':24,'independent_factorizations':1128,
    'independent_weight_checks':20536,'finite_formula_cases':34,'alternate_gamma_integrals':17,
    'actual_input_proof_mutations_rejected':12,'formula_mutations_tested':170,'formula_mutations_detected':112,
    'formula_mutation_rejection_counts':analytic['mutation_rejection_counts'],'displaced_sum_controls':408,
    'scope':'Thirteen and nine of seventeen target coefficients are recovered by integer row deductions; standalone continuous duals recover twelve and nine. This establishes arithmetic information from the spectra without enumerated field templates. Remaining candidates are conservative, and frozen-certificate radius limits are not optimal or information-theoretic.',
    'full_proof_formalized':False,'next_gate':'Combine Gaussian measurements before bounding their shared ordinate errors, audit possible cancellation, and compare certified radii with this rowwise-error baseline.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':11,'successful_commands':10,'failed_commands':1,
    'failure':'The first primary-source recheck used Path.with_suffix on a stem containing a dotted arXiv identifier, producing the wrong PNG filename. The renderer succeeded, but reading the wrong name failed. The initial script and traceback are preserved; appending .png to the full stem corrected the recheck. Mathematical instruments and outputs were unchanged.',
    'data_boundary':'The extractor writes four files containing only degree, discriminant, signature, cutoff and aggregate intervals. The producer imports only the field-independent gamma/kernel/sieve functions from the older recovery instrument. The generic inequality and dual helpers do not read field data. This boundary is inspected and exercised with metadata mutations, not formally proven noninterference or claimed blindness.',
    'freeze_boundary':'Both precision measurement and recovery runs completed before the independent integer/polynomial auditor ran. The independent source and analytic audits read held-out arithmetic afterward. All instruments used by recorded runs are preserved; the failed source-recheck version is archived separately.',
    'method_comparison':'Integer propagation may exceed continuous LP uniqueness because integrality is used between rounds. Neither monotone fixed points nor surviving LP domains prove joint feasibility. The previous count selector uses a complete field class, while this decoder uses generic coefficient inequalities.',
    'uncertainty_scope':'The six tested radii widen the inherited brackets while retaining the certified finite population and cutoff. Separate global derivative bounds are applied before combining rows, making this a conservative sufficient certificate. A larger-radius failure does not imply an indistinguishable field or an optimal noise limit.',
    'negative_controls':'Five formula variants produce 170 altered intervals; 112 are detected against held-out arithmetic. Small discriminant/normalization perturbations remain inside some error budgets and are retained as undetected. Twelve separate input/proof mutations are rejected.',
    'history_policy':'Preserve all 117 branches and the 383-event byte prefix; append five events. Earlier dated checkpoints and pinned code remain unchanged. The ongoing goal remains active.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['scope']='Existing Python 3.12.14, python-flint 0.9.0 / FLINT 3.6.0, mpmath 1.3.0, SymPy 1.14.0, NumPy 2.3.5 and SciPy 1.17.0. Measurements at 160/224 bits, interval dual/radius validation at 224/256 bits, 192-bit outward integer replay and 85-digit independent sums. No new packages, roots or Lean modules.'
write('Runtime.json',runtime)
sources=read(BASE/'Source_Recheck.json')
locators={'Belabas_Friedman_1305.0035.pdf':('Section 2, equations (1)-(2), printed/PDF page 3','General explicit formula, degree/signature normalization and complex zero parameters.'),
          'Grenie_Molteni_1407.1375.pdf':('Section 2, equations (2.1)-(2.7), printed/PDF page 4','Coefficient bound and unconditional preliminary logarithmic-derivative/zero-moment identities; later GRH estimates are not used.')}
write('Primary_Sources.json',{'recorded_utc':now,'sources':[{**r,'locator':locators[r['filename']][0],'use':locators[r['filename']][1],'rendered_page_visually_inspected':True} for r in sources['sources']],
    'scope':'Reuses primary PDFs acquired in the explicit-formula checkpoint, rechecks their exact hashes, and freshly renders and inspects the relevant pages. Third-party PDFs and images remain in scratch.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Direct aggregate-spectrum arithmetic delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],
    advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Aggregate-only explicit-formula constraints, two precision recovery, exact integer certificates, held-out polynomial arithmetic, independent sums/gamma integrals, radius and corruption audits.',
    next_priority=['R12/R13: combine measurements before bounding shared ordinate errors and compare against frozen rowwise-error radii',
      'R13/R15: improve unresolved coefficient domains, audit sufficiency versus constructive ambiguity and extend direct recovery to additional verified fields',
      'R14/R15: enlarge field classes under an explicit metadata contract and separate local models from global realization',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('direct_recovery_frozen_dual_radius_baseline',
   'Under widened ordinate brackets and retained finite membership, the direct c7 certificates remain singleton through tested radius 1e-5 for A and 1e-4 for B. Exact integer replay checks 24 radius bounds and 408 independent displaced sums. These sufficient frozen-dual bounds are not optimal information limits.',
   'Combine the shared ordinate error across Gaussian measurements before taking absolute bounds; revalidate tail moments and compare the resulting radius certificates with the independent-row baseline.'),
 'R13':('direct_shared_invariant_euler_recovery_without_field_templates',
   'Seventeen Gaussian measurements from each complete aggregate spectrum through 20 directly force c7=4 and c7=0. Every one of 604 coefficients starts in {0,1,2,3,4}; no field class, group or local relations are supplied. Integer propagation recovers 13 and 9 of 17 targets; continuous duals recover 12 and 9.',
   'Improve noise tolerance and unresolved target domains using stronger certified measurement combinations, and determine whether remaining candidates are feasible before claiming ambiguity.'),
 'R14':('held_out_local_arithmetic_confirms_direct_recovery',
   'Independent polynomial factorization at all 564 primes through 4096 for both fields verifies 1128 local models and all 604 held-out coefficient values against every recovery run. Order-index primes use alternate primitive elements. The recovery producer never reads this arithmetic.',
   'Extend local and global realizability checks to new field classes while preserving the boundary between arithmetic validation and spectral inference.'),
 'R15':('spectral_arithmetic_information_recovered_without_candidate_enumeration',
   'The shared-invariant benchmark now yields c7 directly from aggregate spectra via a general explicit-formula identity, without the earlier two-field selector. Degree/signature/discriminant alone leave both verified values possible. Twelve input/proof mutations and 170 formula variants audit the boundary and normalization.',
   'Extend the explicit input contract to additional actual fields, compare observation/deduction systems fairly, and preserve completeness and uncertainty premises when investigating general identification.'),
 'K04':('ongoing_delta_with_integer_analytic_and_input_boundary_audits',
   'Preserve 117 branches and 383 events; append five events. Eleven command receipts retain ten successes and one source-render filename failure. Fresh audits check 184 exclusions, 160 total exact dual bounds, 20536 weight comparisons, 34 finite formula cases and 17 alternate gamma integrals.',
   'Continue evidence-backed deltas across the full queue, preserving originals, negative controls, unsuccessful attempts and exact continuation conditions without global completion or exhaustion.')}
prefix='docs/frontier/2026-09-13-aggregate-delta/'
for branch in q['branches']:
    branch['prior_delta_evidence']=branch.get('prior_delta_evidence',[])+branch['new_evidence'];branch['new_evidence']=[];branch['assessment_this_pass']='carried_forward_not_newly_audited'
    if branch['id'] in updates:
        status,result,gate=updates[branch['id']]
        branch.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_direct_aggregate_arithmetic_audit')
        branch['new_evidence']=[prefix+n for n in ['Aggregate_Summary.json','Integer_Audit.json','Analytic_Audit.json','Radius_Audit.json','Adversary_Audit.json','Input_Provenance.json']]
        branch['verification_routes']+=['Aggregate-only schema and exact provenance extraction','Generic Gaussian inequalities with unconditional tails','Outward dyadic conversion and exact integer exclusion/dual replay',
            'Held-out index-aware polynomial arithmetic','Independent mpmath sums and alternate digamma integrals','Frozen-dual radius study and actual malformed-input controls']
        branch['shared_assumptions_and_scope']='Degree four, signature (0,2), discriminant 576 and a complete certified finite critical-line spectrum through 20. No field candidate class, group, local-power relations or arithmetic seeds used in inference. Analytic identities and interval enclosures remain premises; full proof not formalized. Remaining domains and failed radius certificates do not prove alternate fields.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=383
for bid in q['advanced_existing_branches']:
    branch=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'direct_aggregate_arithmetic_evidence_advanced','branch_id':bid,
       'result':branch['latest_scoped_result'],'evidence':branch['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
names=['dedekind_aggregate_'+n+'.py' for n in ['inputs','measurements','recovery','integer_audit','analytic_audit','radius','adversary']]+['verify_aggregate_delta.py','AGGREGATE_README.md']
deps=['dedekind_coefficient_recovery.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','dedekind_explicit_crosscheck.py','dedekind_inputs.py','verify_biquadratic_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},
    'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New direct-recovery instruments, pinned dependencies and preserved source-recheck versions. Previous dated checkpoints and instruments are unchanged.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+
    [(BASE/n,'packaging/'+n) for n in ['run_recorded.py','recheck_sources.py',Path(__file__).name]]+
    [(p,'source-versions/'+p.name) for p in sorted((BASE/'source-versions').iterdir())])
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
    'scope':'Manifest and Verification excluded from self-reference; preceding checkpoint is checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
