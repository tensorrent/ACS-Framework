"""Branch-aware interval algebra and frozen-grid identifiability analysis."""
import hashlib,json,math,os
from decimal import Decimal,getcontext
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
ROOT=Path(os.environ.get('ACS_PHYSICAL_ROOT',Path(__file__).resolve().parents[1]))
getcontext().prec=60
grid=json.loads((ROOT/'support/nuclear_grid.json').read_text())['results']
nodes=json.loads((ROOT/'support/nuclear_nodes.json').read_text())['results']
assert len(grid)==18 and len(nodes)==32
node_thresholds=[]
for row in nodes:
    if row['tolerance']!=2e-11:continue
    ratio=row['required_preformation_if_this_single_channel']
    node_thresholds.append({'isotope':row['isotope'],'radial_nodes':row['radial_nodes'],
                           'provisional_P':ratio,'max_branch_fraction_for_P_le_1':min(1.,1/ratio)})
assert len(node_thresholds)==16
analyses=[]
for iso in ['212Po','214Po']:
    rows=[r for r in grid if r['isotope']==iso]
    assert len(rows)==9
    # The preserved Q is fixed within each isotope. Depth is separately fitted.
    assert len(set(r['Q_MeV'] for r in rows))==1
    feasible=[r for r in rows if r['required_preformation_if_this_single_channel']<=1]
    allr=[r['required_preformation_if_this_single_channel'] for r in rows]
    rr=[r['required_preformation_if_this_single_channel'] for r in feasible]
    ratio=max(rr)/min(rr)
    # Exact observational equivalence after choosing P_i=Gamma_obs/Gamma_sp_i.
    targets=[]
    for r in feasible:
        p=r['required_preformation_if_this_single_channel'];g=r['width_MeV']
        targets.append(p*g)
        # Independent Decimal identity using T_sp and width rather than r.
        Tsp=Decimal(str(r['preformation_one_half_life_s']))
        Ttarget=Decimal('2.944e-7') if iso=='212Po' else Decimal('.00016347')
        p2=Tsp/Ttarget
        assert abs(float(p2)-p)<2e-15
    assert max(targets)/min(targets)-1<3e-15
    center=next(r for r in rows if r['radius_coefficient_fm']==1.2 and r['diffuseness_fm']==.55)
    def logwidth(r0,aa):
        return math.log(next(r['width_MeV'] for r in rows if r['radius_coefficient_fm']==r0 and r['diffuseness_fm']==aa))
    radius_secant=(logwidth(1.25,.55)-logwidth(1.15,.55))/.1
    diffuse_secant=(logwidth(1.2,.6)-logwidth(1.2,.5))/.1
    x=np.array([[r['radius_coefficient_fm']-1.2,r['diffuseness_fm']-.55] for r in rows])
    z=np.log([r['width_MeV']/center['width_MeV'] for r in rows])
    slope,*_=np.linalg.lstsq(x,z,rcond=None)
    # Different numerical methods share the frozen finite inputs.
    slopes_normal=np.linalg.solve(x.T@x,x.T@z)
    assert np.max(abs(slope-slopes_normal))<1e-12
    thresholds=[]
    for r in rows:
        pp=r['required_preformation_if_this_single_channel']
        thresholds.append({'r0_fm':r['radius_coefficient_fm'],'a_fm':r['diffuseness_fm'],
                           'provisional_P':pp,'max_within_alpha_branch_fraction_for_P_le_1':min(1.,1/pp)})
    analyses.append({'isotope':iso,'Q_MeV':rows[0]['Q_MeV'],'all_grid_P_range':[min(allr),max(allr)],
      'single_channel_compatible_grid_count':len(feasible),'compatible_P_range':[min(rr),max(rr)],
      'compatible_P_ratio':ratio,'two_point_minimax_log_P_error_lower_bound':math.log(ratio)/2,
      'two_point_minimax_multiplicative_factor':math.sqrt(ratio),
      'observationally_identical_width_product':targets[0],
      'center_log_width_sensitivity_secants_per_fm':{'radius_coefficient':radius_secant,'diffuseness':diffuse_secant},
      'grid_least_squares_log_width_slopes_per_fm':slope.tolist(),
      'max_log_width_linear_reconstruction_error':float(max(abs(x@slope-z))),
      'thresholds':thresholds,
      'interpretation':'Finite family with equal fitted Q and the same total width after separately adjusted P. The minimax statement assumes only these shared decay observations, not independent potential information. Grid range is not an empirical uncertainty interval.'})

# Independent channels: possible total widths form the entire interval [0,sum g].
# Fixed branching vector reduces feasibility to one bound per channel.
rng=np.random.default_rng(20260911);feasibility=[]
for _ in range(40):
    g=np.exp(rng.uniform(-3,3,5));total=float(g.sum()*rng.uniform(0,1.4))
    lp=linprog(np.zeros(5),A_eq=g[None,:],b_eq=[total],bounds=[(0,1)]*5,method='highs')
    analytic=total<=g.sum()
    assert lp.success==analytic
    beta=rng.dirichlet(np.ones(5));p=beta*total/g
    branch_ok=bool(np.all(p<=1))
    direct=linprog(np.zeros(5),A_eq=np.diag(g),b_eq=beta*total,bounds=[(0,1)]*5,method='highs')
    assert direct.success==branch_ok
    feasibility.append({'total':total,'capacity_sum':float(g.sum()),'analytic_feasible':bool(analytic),
                        'LP_feasible':bool(lp.success),'fixed_branch_feasible':branch_ok})

# A common preformation is identifiable from absolute scale only after the
# potential is fixed; ratios cancel it and can independently falsify shape.
g=np.array([1.,3.,7.]);P=.17;obs=P*g
assert np.allclose(obs/obs.sum(),g/g.sum())
wrong=np.array([1.,4.,6.]);best=float(wrong@obs/(wrong@wrong))
shape_residual=float(np.linalg.norm(obs-best*wrong))
assert shape_residual>.1

# Isotope-specific nuisance intercepts span all observations: adding a geometric
# predictor produces a rank deficiency and cannot establish predictive value.
n=8;feature=np.linspace(-1,1,n)**3
design=np.column_stack([np.eye(n),feature])
null=np.r_[-feature,1.]
assert np.linalg.norm(design@null)<1e-14
assert np.linalg.matrix_rank(design)==n

print(json.dumps({'branches':['N02','N03','N04','N07','N08','N09'],
 'branch_conversion':{'exact':'Gamma_i=b_i*hbar*ln(2)/T_total; T_partial_i=T_total/b_i; P_i=b_i*T_sp_i/T_total.',
   'alpha_conditional':'If r=T_sp/T_alpha and beta_i is a fraction within alpha decays, P_i=beta_i*r; compatibility is beta_i<=min(1,1/r). If f_alpha is given relative to all decays, b_i=f_alpha*beta_i.',
   'new_data':'No branch intensities substituted. New LNHB source discovery did not yield usable data; old failed endpoints were not retried.'},
 'frozen_grid_analysis':analyses,
 'frozen_node_branch_thresholds':node_thresholds,
 'sharp_partial_identification':{'given_g_interval_and_branch_interval':'For independent allowed intervals g in [gL,gU], b in [bL,bU], T in [TL,TU], P lies in [bL*kappa/(TU*gU), bU*kappa/(TL*gL)] intersect [0,1], where kappa=hbar ln2. Sharp only if interval combinations are jointly attainable.',
 'correlated_differential':'d log P=d log b-d log T-d log Gamma_sp; variance is the full quadratic form v^T Cov(log b,log T,log Gamma_sp) v, v=(1,-1,-1). Marginal intervals alone do not determine this covariance.',
 'fitted_Q_sensitivity':'For simple real matching constraint F(Q,D,p)=0, D_p=-F_p/F_D and total partial_p log Gamma=partial_p log Gamma-(partial_D log Gamma) F_p/F_D. Requires F_D nonzero and an independently defined potential parameter p.',
 'profile_likelihood':'With freely chosen P_i in [0,1], every potential satisfying Gamma_sp_i>=Gamma_obs_i gives an exact width fit. Equality to Q and widths therefore cannot select those potentials.'},
 'multichannel':{'theorem':'Independent 0<=P_i<=1 make exactly [0,sum Gamma_sp_i] attainable. Given branches b_i, feasibility iff every b_i*Gamma_total<=Gamma_sp_i.',
 'proof_1':'Necessity is summing interval bounds; sufficiency sets all P_i=Gamma_total/sum Gamma_sp_i. Fixed branches use P_i=b_i Gamma_total/Gamma_sp_i.',
 'proof_2':'Independent constrained linear programs on 40 cases.', 'checks':feasibility,
 'shared_P_falsification':{'correct_branch_ratios':(obs/obs.sum()).tolist(),'wrong_shape_best_P':best,'wrong_shape_absolute_residual':shape_residual}},
 'geometric_overlap_identifiability':{'saturated_nuisance_rank':int(np.linalg.matrix_rank(design)), 'columns':design.shape[1],
 'null_vector':null.tolist(),'consequence':'One free log preformation per isotope absorbs any fixed geometric offset exactly. To test N03, constrain preformation before data and validate branch ratios or frozen held-out widths. This algebra does not overturn the earlier retrospective holdout result.'},
 'provenance':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'support').glob('nuclear_*.json'))}},indent=2))
