"""Unpublished fixed-critical-coordinate feature-separation proposals; no certified threshold."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
import mpmath as mp
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES,kernel,number,exported
from dedekind_feature_certificate import coordinate_audit
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 mp.mp.dps=220;p=json.loads((PRIOR/'Feature_Space_Proposals.json').read_text());s=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text())
 common=list(map(F,p['common_root_center']));c=list(map(number,common));r=F(p['root_coordinate_error_radius']);v=p['feature_direction'];epsilon=F('1e-8')+F('1e-16');free=[i for i in range(22) if i!=1]
 anchor=next(x for x in p['cases'] if F(x['feature_error_bound'])==F('2e-10'));initialA=list(map(number,anchor['A']['corrections']));initialB=list(map(F,anchor['B']['corrections']));scale_tau=mp.mpf('1e-10');cases=[]
 for scale in ['1/2','1','3/2']:
  B=[common[i]+F(scale)*initialB[i] for i in range(22)];B[1]=common[1]-epsilon;Bm=list(map(number,B));BF=[sum(kernel(spec,x) for x in Bm) for spec in FEATURES]
  variables=mp.matrix([initialA[i]+(1-number(scale))*number(initialB[i]) for i in free]+[2]);history=[]
  def evaluate(w):
   A=list(c);A[1]+=number(epsilon)
   for j,i in enumerate(free):A[i]+=w[j]
   residual=mp.matrix([sum(kernel(spec,x) for x in A)-BF[k]-2*scale_tau*w[21]*v[k] for k,spec in enumerate(FEATURES)])
   J=mp.matrix([[kernel(spec,A[i],True) for i in free]+[-2*scale_tau*v[k]] for k,spec in enumerate(FEATURES)])
   return A,residual,J
  for iteration in range(25):
   A,f,J=evaluate(variables);res=max(abs(x) for x in f);history.append({'iteration':iteration,'residual':mp.nstr(res,170)})
   if res<mp.mpf('1e-160'):break
   variables-=mp.lu_solve(J,f)
  A,f,J=evaluate(variables);tau=scale_tau*variables[21];rationalA=list(common);rationalA[1]+=epsilon
  for j,i in enumerate(free):rationalA[i]+=F(mp.nstr(variables[j],170))
  records=coordinate_audit({'radius':r,'boxes_A':[(x,x) for x in rationalA],'boxes_B':[(x,x) for x in B]},s,SOURCE/'Equal_Population_Inputs.zip')
  cases.append({'status':'numerical_proposal_not_certified','B_correction_scale':scale,'free_A_indices':free,'fixed_A_critical_coordinate':str(common[1]+epsilon),'fixed_B_coordinates':list(map(str,B)),
   'A_coordinate_corrections':[mp.nstr(variables[j],170) for j in range(21)],'scaled_tau':mp.nstr(variables[21],170),'tau_scale':'1/10000000000','feature_difference_direction':v,
   'preconditioner':exported(J**-1),'tau_proposal':mp.nstr(tau,170),'tau_display':float(tau),'numerically_converged':max(abs(x) for x in f)<mp.mpf('1e-160'),
   'history':history,'maximum_residual':mp.nstr(max(abs(x) for x in f),170),'maximum_A_displacement':str(max(abs(x-y) for x,y in zip(rationalA,common))),'maximum_B_displacement':str(max(abs(x-y) for x,y in zip(B,common))),
   'rational_center_source_constraints_all_pass':all(x['within_radius'] for x in records),'rational_center_coordinate_audit':records,
   'inside_radius_0p01_at_centers':all(abs(x-y)<F(1,100) for coords in [rationalA,B] for x,y in zip(coords,common))})
 return {'status':'exploratory_proposals_require_certification','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [PRIOR/'Feature_Space_Proposals.json',SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_proposal.py',CODE/'dedekind_feature_certificate.py']},
  'mpmath_dps':220,'export_significant_digits':170,'critical_epsilon':str(epsilon),'root_coordinate_error_radius':str(r),'cases':cases,
  'candidate_argument':'Fix both critical root coordinates just inside their source-feasibility boundaries. Fix B other coordinates by rationally scaling a previous proposal. Solve for the other 21 A coordinates and a variable signed feature separation 2*tau*v. The common release becomes the feature midpoint of the two observations; it is not constrained to Phi(c).',
  'scope':'Only numerical proposals and exact rational center source checks. Exact feature equality, correction-box source feasibility and existence need new primary and independent certificates. No sharp threshold or improved published bound is claimed. Separate from frozen checkpoint 29.'}
r=run();(BASE/'Boundary_Pair_Proposals.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'cases':[{k:x[k] for k in ['B_correction_scale','tau_display','numerically_converged','inside_radius_0p01_at_centers','rational_center_source_constraints_all_pass']} for x in r['cases']]},indent=2))
