from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
base=Path(__file__).absolute().parent;mathlib=base.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip();assert revision=='be865aa50cc0364be66c3941a6dc0c845a2c2ceb'
records=[]
for relative in ['Mathlib/LinearAlgebra/Matrix/NonsingularInverse.lean','Mathlib/LinearAlgebra/Matrix/Adjugate.lean','Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean','Mathlib/Data/Matrix/Mul.lean','Mathlib/Basic/Real/Basic.lean']:
    raw=(mathlib/relative).read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+relative],cwd=mathlib)
    records.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'matches_pinned_git_object':True})
r={'status':'passed','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mathlib_revision':revision,'pinned_sources':records,
    'retrieved_primary_documentation':[{'url':'https://leanprover-community.github.io/mathlib4_docs/Mathlib/LinearAlgebra/Matrix/'+p+'.html','retrieval':'Successfully opened with the web tool on 14 September 2026.','scope':'Current primary documentation is distinct from pinned runtime source evidence.'} for p in ['NonsingularInverse','Adjugate']],
    'relevant_results':['Matrix.inv_sub_inv','Matrix.det_smul_inv_mulVec_eq_cramer','Matrix.cramer_apply','Matrix.mulVec_mulVec','Matrix.sub_mulVec'],
    'runtime_change':'No package acquisition, version change or new source roots. Existing Python/FLINT and Lean/mathlib are reused.',
    'scope':'Pinned matrix inverse, determinant, Cramer, multiplication and real-number sources match local Git objects and are archived with their license. The new closed-hull/secant proof is derived explicitly; compiled generic lemmas do not formalize its full analytic assembly.'}
(base/'Source_Acquisition.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
