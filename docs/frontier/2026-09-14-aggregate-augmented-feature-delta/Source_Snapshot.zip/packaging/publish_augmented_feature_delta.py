from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-feature-delta'
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta';CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_augmented_feature_delta import summarize,FAILURES,ADVANCED

OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)
    assert (OUT/name).stat().st_size<100*1024**2

documents=[f'Augmented_Proposals_{s}.json' for s in ['Enlarged','Small','Local']]+[f'Augmented_Certificate_{s}_v2.json' for s in ['Enlarged','Small','Local']]+['Independent_Augmented_Audit.json','Feature_Noise_Boundary.json','Adversary_Audit.json','Lean_Check.json','Lean_Check_v2.json','Source_Acquisition.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
certs={s:read(BASE/f'Augmented_Certificate_{s}_v2.json') for s in ['Enlarged','Small','Local']}
checked,noise,adv,formal=[read(BASE/n) for n in ['Independent_Augmented_Audit.json','Feature_Noise_Boundary.json','Adversary_Audit.json','Lean_Check_v2.json']]
summary=summarize(certs,checked,noise,adv,formal)
write('Augmented_Feature_Summary.json',{'recorded_utc':now,'result':'Actual-source collisions survive joint observables through dimension 21; a certified local 22-feature map is injective, yet bounded feature measurement error restores ambiguity in the same neighborhood.',
    'derived_results':summary,'source_premises':'Inherited complete discriminant-576 two-field metadata class and complete 22-entry positive source prefixes below 39/2. Source selection precedes coordinate errors; every entry and multiplicity remains.',
    'joint_features':'Seventeen original finite Gaussians, then the finite rational moment, center 37, changed-width center 2, center 41 and center 43. No raw roots, counts or unknown tails are implicitly included.',
    'existence_proof':'Twelve rational correction boxes are strict self-mapping contractions by real interval Jacobians and independent complex Taylor bounds. Modular preconditioner nonsingularity and exact source inclusions make the exact feature equalities feasible for both actual fields.',
    'local_result':'The selected 22-feature map is injective on the closed infinity-norm box of radius 1e-10 about the rational midpoint list. All epsilon=1e-18 collisions are inside it; the 21-feature witness is distinguished by the final feature.',
    'measurement_noise':'At tau=5e-18, use the exact first 21 B features and the last B feature minus 4.5e-18. Both actual fields realize this noisy 22-feature release inside the local neighborhood. Root-coordinate and feature-measurement errors are distinct stages.',
    'formal_scope':'Six new Lean lemmas check the local defect-to-injectivity/stability logic and scope controls. The vector mean-value/row-norm, interval, modular matrix, field and spectral bridges remain written/computational.',
    'open_gates':'Global injectivity over admissible observation sets, sharp root/feature noise tradeoffs, validated parameter families, stronger neighborhoods and conditioning, physical precision and acquisition contracts, and broader ACS branches remain open.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==13 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check_v2.json','Lean_Check_v2.olean']]+[(CODE/'proofs'/n,n) for n in ['AugmentedFeatureLocal.lean','AugmentedFeatureLocal_v2.lean']])
write('Development_Notes.json',{'recorded_commands':13,'successful_commands':11,'failed_commands':2,
    'failures':[{'receipt':'augmented-certificate-enlarged','result':'The first certificate source reaches the local-radius sweep then raises TypeError because Arb does not directly compare to Python Fraction. No certificate JSON is emitted. Separate v2 compares against an Arb enclosure of 1/2; all scientific formulas and input files remain unchanged.'},
                {'receipt':'augmented-feature-lean','result':'The first proof uses the reserved Lean keyword prefix as a binder. Five lemmas check, but the compilation fails and no successful artifact is claimed. Separate v2 renames that binder and all six lemmas compile.'}],
    'canonical_sources':['code/frontier_verification/dedekind_augmented_feature_certificate_v2.py','code/frontier_verification/proofs/AugmentedFeatureLocal_v2.lean'],
    'source_policy':'Executed source versions and failures remain immutable. The final recursive verifier runs after packaging and preserves its own external receipt. Its exact stdout becomes Verification.json.',
    'runtime':'No package acquisition, version changes or new source roots. Existing pinned Python, FLINT and Lean/mathlib environments are reused.',
    'shared_infrastructure':'Independent real and complex formulations share FLINT and inherited source premises. Exact rational inclusions and modular determinants provide distinct arithmetic routes.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned numerical packages and Lean/mathlib revision; no new runtime acquisition. Six new local-injectivity and scope lemmas compile. Prior runtime acquisitions remain in their original dated records.')
runtime.pop('new_compiled_module',None);runtime.pop('module_olean_sha256',None)
for key,pkg in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(pkg)
write('Runtime.json',runtime)
paths=[SOURCE/'Equal_Population_Inputs.zip',SOURCE/'Equal_Population_Decoder.json',PRIOR/'Verification.json',PRIOR/'Research_Queue.json',PRIOR/'Branch_Events.jsonl',CLASS/'Full_Quartic_Class.json',CLASS/'Full_Class_Audit.json',PAIR/'Pair_Arithmetic.json',CODE/'verify_aggregate_feature_delta.py']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'Complete field classification, finite source populations, coefficient predictions and the preceding checkpoint chain are inherited; both source precision variants are freshly used.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',CLASS/'Primary_Sources.json',PAIR/'Primary_Sources.json']},
    'new_source_record':'Source_Acquisition.json','scope':'Primary Mathlib mean-value documentation was retrieved. Exact pinned MeanValue and normed-group source files match their local Git objects and are archived with the mathlib license. New derivative identities and proof arguments are independently derived and checked.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Joint finite features, local injectivity and measurement-noise delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=ADVANCED,
    replay_scope='Twelve joint-feature collision certificates, independent complex Taylor/rank/arithmetic audits, local injectivity and explicit noisy 22-feature ambiguity, 45 mutations and six Lean lemmas. All previous branches remain tracked.',
    next_priority=['R12/R13/R14: global injectivity over admissible observations, validated parameter families and joint root/feature noise tradeoffs','R15: larger certified neighborhoods, conditioning and fuller vector-calculus/matrix formalization','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
    'R12':('joint_observable_and_two_stage_noise_contracts_certified','Different actual-source witnesses match the original Gaussian features jointly with the finite moment, center 37, a changed width and center 41. Root-coordinate noise and feature-measurement noise are specified separately; an explicit noisy 22-feature common release is certified.','Audit physical measurement/precision models and any infinite-tail contracts. Study global identification and joint root-coordinate/feature-measurement tradeoffs without treating an omitted statistic as automatically sufficient.'),
    'R13':('arithmetic_ambiguity_survives_joint_moment_and_kernel_release','Twelve exact finite-feature collisions through dimension 21 retain exactly 148 ambiguous and 456 fixed coefficients in the complete two-field class. A locally injective 22-feature map becomes ambiguous again under the stated bounded feature error. Independent polynomial factorizations verify the arithmetic vectors.','Determine global recovery domains and robust coefficient identification under expanded feature sets, precision constraints and larger metadata classes. Keep exact local recovery separate from noisy or global recovery.'),
    'R14':('certified_local_transition_and_precision_boundary','Ranks 18 through 21 admit actual-source collisions; the selected 22-feature map is injective on a radius-1e-10 coordinate box containing the smallest collisions. Real and complex derivative bounds give an inverse stability constant, and tau=5e-18 admits an explicit common 22-feature release there.','Validate parameterized families and tighter quantitative bounds. Prove or refute global injectivity over admissible observations; improve collision radii and local neighborhoods without interpreting failed sufficient bounds as impossibility.'),
    'R15':('independent_joint_feature_rank_and_scope_audits','Independent complex Taylor bounds, modular matrix determinants and 2112 scalar coordinate inequalities certify 12 witnesses. Forty-five mutations reject; six Lean lemmas establish generic local injectivity/stability and scope controls. The initial certificate type error and Lean reserved-keyword failure are preserved.','Formalize the vector mean-value/row-norm and modular matrix bridges. Audit robust precision thresholds and global extensions with counterexamples, preserving exact-versus-noisy and local-versus-global distinctions.'),
    'K04':('append_only_delta_with_joint_observation_and_precision_evidence','All 117 branches and 438 earlier events are preserved; five new events link joint-feature collisions, local injectivity, noisy releases, independent audits and actual failure receipts. Thirteen recorded commands include 11 successes and two preserved implementation failures.','Continue evidence-backed deltas across the full ACS program, maintain original inputs and precise open gates, and do not claim global completion or exhaustion.')}
prefix=str(OUT.relative_to(ROOT))+'/'
evidence=['Augmented_Feature_Summary.json','Augmented_Certificate_Enlarged_v2.json','Augmented_Certificate_Local_v2.json','Augmented_Certificate_Small_v2.json','Independent_Augmented_Audit.json','Feature_Noise_Boundary.json','Adversary_Audit.json','Lean_Check_v2.json']
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_joint_feature_and_local_precision_audit')
        b['new_evidence']=[prefix+n for n in evidence]
        b['verification_routes']+=['Twelve real interval self-mapping contraction certificates','Independent complex Taylor and modular matrix rank audits','2112 direct scalar source-to-observation inequalities','Explicit noisy 22-feature common release at two precisions and two analytic formulations','Forty-five adversaries and local/global and exact/noisy controls','Six Lean local-injectivity, stability and scope lemmas']
        b['shared_assumptions_and_scope']='Inherited complete two-field class and complete 22-entry finite source prefixes selected before coordinate noise. Exact finite joint features through dimension 21 remain ambiguous; dimension 22 is injective only on a specific small box. Additional feature error can restore ambiguity there. Shared FLINT and remaining written/computational calculus, arithmetic and spectral premises are explicit.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=438
for bid in ADVANCED:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'joint_feature_local_injectivity_and_noise_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Joint features, local uniqueness, and measurement noise — 14 September 2026

**Actual-source ambiguity survives the moment and extra kernels jointly.** Twelve certified witnesses match 18 through 21 finite measurements. A selected 22-feature extension is injective on a small neighborhood containing the smallest witnesses, yet an explicit feature error of at most 5e-18 restores ambiguity there.

The [proof and reproduction guide](../../../code/frontier_verification/AUGMENTED_FEATURE_README.md) derives the exact collisions, independent complex Taylor bounds, local injectivity and stability, and the two-stage noise contract. The [preceding checkpoint](../2026-09-14-aggregate-feature-delta/README.md) supplied the original 17-feature collision and showed that the added statistics rejected that particular witness.

- [Results and exact continuation gates](Augmented_Feature_Summary.json).
- Proposals and certificates at critical split [1e-8](Augmented_Proposals_Enlarged.json) / [certificate](Augmented_Certificate_Enlarged_v2.json), [1e-12](Augmented_Proposals_Small.json) / [certificate](Augmented_Certificate_Small_v2.json), and [1e-18](Augmented_Proposals_Local.json) / [certificate](Augmented_Certificate_Local_v2.json).
- [Independent complex Taylor, modular rank and polynomial arithmetic audit](Independent_Augmented_Audit.json).
- [Explicit noisy 22-feature common release](Feature_Noise_Boundary.json), keeping root-coordinate and feature-measurement errors separate.
- [Forty-five adversarial mutations and exact scope controls](Adversary_Audit.json).
- [Six compiled Lean lemmas](Lean_Check_v2.json), [preserved first failure](Lean_Check.json), and [proof sources/compiled artifact](Lean_Artifacts.zip).
- [Primary source acquisition](Source_Acquisition.json), [inherited primary sources](Primary_Sources.json), [runtime](Runtime.json), and [inherited inputs](Inherited_Inputs.json).
- [Thirteen recorded executions](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [development failures and corrections](Development_Notes.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json), and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [443-event append-only ledger](Branch_Events.jsonl), retaining all 438 earlier events byte for byte.

The source population is complete below 19.5, selected before bounded coordinate errors, with all 22 entries and multiplicities preserved. The nested measurements consist of the original 17 finite Gaussians, the finite rational moment, center 37, a changed-width center 2, center 41, and finally center 43. No raw roots, count profile or unknown tail is silently added.

For each of 18, 19, 20 and 21 measurements, closed correction boxes of radius 1e-120 contain exact feature-equation roots at three positive critical splits. Direct real interval Jacobians at 640/896 bits and independent complex Taylor bounds at 768 bits establish self-mapping contraction. All 2,112 independent scalar source-to-observation inequalities pass. The largest split is 1e-8, giving root error radius U-1e-8 strictly below L; U-L=2e-30. Full observed root lists and interior counts still differ.

The selected 22-feature map is injective on the coordinate box of radius 1e-10 about the rational midpoint list. A uniform derivative defect at most 1/2 yields an exact rational inverse stability bound, approximately 65.66 million in the specified units. The local 21-feature witness lies inside this region, and center 43 distinguishes it by about 9.02e-18. The conclusion is local; global injectivity and optimal conditioning remain open.

An additional independent feature error of at most 5e-18 admits a common 22-feature release inside that same region: use the fixed B vector through component 21 and subtract 4.5e-18 from its final component. This is compatible with exact local injectivity because the measurement contracts differ. A 1e-18 error cannot hide this witness pair; no global noise threshold is inferred.

Exactly 456 of 604 tracked coefficients remain fixed and 148 ambiguous for the certified exact collisions and the noisy 22-feature common release. Independent arithmetic performs 1,128 factorizations and 1,208 coefficient comparisons. The six Lean lemmas cover the generic local injectivity/stability logic and scope controls; the complete calculus, interval, modular matrix and field/spectral chain is not entirely formalized in Lean.

The initial Arb/Fraction comparison failure and Lean reserved-keyword failure remain preserved beside separate corrected sources. Thirteen recorded commands include 11 successes and two failures. Eight of 16 exact-zero margin controls would be falsely negative in binary64.

Next: global identification over admissible observations, validated parameter families, sharper root/feature noise tradeoffs and stability bounds, physical acquisition/precision models, and fuller formalization. All wider ACS branches and private-input gates remain active; no global completion is claimed.
''')
names=['dedekind_augmented_feature_proposal.py','dedekind_augmented_feature_certificate.py','dedekind_augmented_feature_certificate_v2.py','dedekind_augmented_feature_audit.py','dedekind_augmented_feature_noise.py','dedekind_augmented_feature_adversary.py','check_augmented_feature_lean.py','verify_aggregate_augmented_feature_delta.py','AUGMENTED_FEATURE_README.md','proofs/AugmentedFeatureLocal.lean','proofs/AugmentedFeatureLocal_v2.lean']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
    p=todo.pop()
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for mod in modules:
            d=CODE/(mod+'.py')
            if d.exists() and d not in seen:
                seen.add(d);todo.append(d)
                if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt');mathlib=ROOT.parent/'acs-research/lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/p,'external/'+p) for p in ['Mathlib/Analysis/Calculus/MeanValue.lean','Mathlib/Analysis/Normed/Group/Basic.lean']]+[(mathlib/'LICENSE','external/mathlib-LICENSE')]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'scope':'All new instruments and both failed/corrected certificate and Lean sources, transitive local Python dependencies, runner/source-capture/packaging scripts, and pinned Mathlib reference sources with license.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'exploration/'+n) for n in ['run_recorded.py','capture_sources.py']]+external+[(Path(__file__),'packaging/'+Path(__file__).name)])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. Preceding checkpoints are recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 joint-feature and local precision delta](2026-09-14-aggregate-augmented-feature-delta/README.md): certified collisions through 21 joint features, local injectivity at 22, and an explicit noisy 22-feature common release.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-feature-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-augmented-feature-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':13,'successes':11,'failures':2,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
