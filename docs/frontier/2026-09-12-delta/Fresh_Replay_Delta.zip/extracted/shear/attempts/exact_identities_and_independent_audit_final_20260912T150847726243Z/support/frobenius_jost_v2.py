"""Frobenius certificate with disk-error propagation avoiding rectangle wrapping.

v1 is retained: its rectangle rotations become inconclusive at small eta.
"""
from flint import arb, acb, ctx
from frobenius_jost import tail_bound,box

def mid(z):return acb(z.real.mid(),z.imag.mid())
def radius(z):return (z.real.rad()**2+z.imag.rad()**2).sqrt()

def solution(k,eta,n=600,bits=128):
    ctx.prec=bits;k=acb(k);eta=acb(eta)
    A=1+acb(0,1)*eta;lam=1/A;gap=lam-acb('0.5')
    z=1/gap;t1=mid(z);t2=-t1;err=radius(z)
    f=acb(1);v=acb(0);ferr=arb(0);verr=arb(0)
    for j in range(n):
        den=j+1+k
        e1=-2/(A*den)-k*lam/(A*(j+1)*den*gap)
        e2=(1+k)/(2*den)-k/(2*A*(j+1)*den*gap)
        m11=lam+e1;m12=e2;m21=-e1;m22=acb('0.5')-e2
        row=max(m11.abs_upper()+m12.abs_upper(),m21.abs_upper()+m22.abs_upper())
        u1=m11*t1+m12*t2;u2=m21*t1+m22*t2
        err=row*err+max(radius(u1),radius(u2))
        t1,t2=mid(u1),mid(u2)
        b=lam*t1+t2/2;be=(lam.abs_upper()+arb('0.5'))*err+radius(b)
        b=mid(b);f+=b;v+=(j+1)*b;ferr+=be;verr+=(j+1)*be
    # Reuse the proven scalar tail formula with containing complex boxes.
    ef,ev,rho=tail_bound(k,eta,n,t1+box(err),t2+box(err))
    f=f+box(ferr+ef);v=v+box(verr+ev)
    return f,v,{'terms':n,'bits':bits,'rho':str(rho),'f_tail':str(ef),'v_tail':str(ev),'f_error':str(ferr),'v_error':str(verr),'f':str(f),'v':str(v)}

def determinant(k,eta,n=600,bits=128):
    f,v,details=solution(k,eta,n,bits)
    D=(acb(k)*f*f.conjugate()+v*f.conjugate()).real
    return D,details
