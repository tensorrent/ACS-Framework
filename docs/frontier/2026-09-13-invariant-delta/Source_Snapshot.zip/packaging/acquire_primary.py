from datetime import datetime, timezone
import hashlib, json, urllib.request
from pathlib import Path

base = Path(__file__).absolute().parent
dest = base/'primary'
dest.mkdir(exist_ok=True)
sources = [
 ('Milne_ANT.pdf', 'https://www.jmilne.org/math/CourseNotes/ANT.pdf'),
 ('Conrad_Different.pdf', 'https://kconrad.math.uconn.edu/blurbs/gradnumthy/different.pdf'),
 ('Conrad_Tame_Composita.pdf', 'https://math.stanford.edu/~conrad/676Page/handouts/tamecomp.pdf'),
 ('Conrad_Inertia_Surjectivity.pdf', 'https://math.stanford.edu/~conrad/676Page/handouts/inertiasurj.pdf'),
 ('Wang_2018.pdf', 'https://asset.library.wisc.edu/1711.dl/6NIAB7DW5X5WN8J/R/file-284b7.pdf'),
 ('Prasad_Yeung_2007.pdf', 'https://archive.mpim-bonn.mpg.de/id/eprint/741/1/preprint_2007_70.pdf')]
rows = []
for name, url in sources:
    with urllib.request.urlopen(url, timeout=45) as response:
        raw = response.read()
    assert raw.startswith(b'%PDF'), name
    (dest/name).write_bytes(raw)
    rows.append({'name': name, 'url': url, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
result = {'status': 'passed', 'downloaded_utc': datetime.now(timezone.utc).isoformat(), 'sources': rows,
          'scope': 'Public source PDFs retained only in local scratch. Repository receives URLs, hashes, locators and original derivations, not copies of third-party papers.'}
(base/'Source_Acquisition.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
