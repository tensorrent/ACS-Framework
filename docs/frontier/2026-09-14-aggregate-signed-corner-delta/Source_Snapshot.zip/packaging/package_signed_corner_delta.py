from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-signed-corner-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-variable-noise-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_signed_corner_delta import summarize,ADVANCED,FAILURES
import dedekind_signed_corner_certificate as certificate
import dedekind_signed_corner_audit as audit

OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def archive(n,entries):
    with zipfile.ZipFile(OUT/n,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,name in entries:z.write(p,name)
    assert (OUT/n).stat().st_size<100*1024**2

documents=['Signed_Resolvent_Exploration.json','Gradient_Sign_Exploration.json','Corner_Inverse_Exploration.json','Independent_Gradient_Candidate_Audit.json','Signed_Corner_Certificate.json','Independent_Signed_Corner_Audit.json','Adversary_Audit.json','Lean_Check.json','Lean_v1.json','Lean_v2.json','Source_Acquisition.json','Proof_Audit.md']
for n in documents:(OUT/n).write_bytes((BASE/n).read_bytes())
reports=[read(BASE/n) for n in ['Signed_Corner_Certificate.json','Independent_Signed_Corner_Audit.json','Adversary_Audit.json','Lean_Check.json']]
summary=summarize(*reports)
write('Signed_Corner_Summary.json',{'recorded_utc':now,'result':'A signed convex column-family argument proves a corner maximum for the critical inverse-row norm and improves the local uniform feature-noise guarantee to approximately 1.8011173562984702e-10.',
    'derived_results':summary,'unchanged_contract':reports[0]['contract'],
    'new_argument':'All observation secants belong to the product of closed convex derivative-column hulls. The inherited weighted defect excludes singularity there. Uniform curvature and inverse-direction signs permit 21 nondecreasing column replacements. A constant Cramer numerator and determinant orientation resolve the remaining face coordinate. The final corner norm bounds every secant.',
    'independence':'Primary complex derivatives and exact rational elimination are checked by real derivative polynomials, an independently certified 48-bit majorant, exact FLINT rational inversion and finite positive Neumann series. Cramer determinants independently verify every corner inverse-row entry. Both interval routes share FLINT and inherited source premises.',
    'formal_scope':'Eight generic algebra, Cramer, sign-transfer, convex-combination and replacement-chain lemmas compile without sorryAx. The full analytic/closed-hull/connectedness assembly remains written or computational.',
    'scope':'The corner maximizes an outer matrix-family norm; this need not be a source-feasible pair or sharp source-constrained noise threshold. Strictly subthreshold feature errors preserve field identity and its tracked coefficients. The inherited actual ambiguity upper endpoint leaves a ratio about 1.01714.',
    'open_gates':['Source-feasible lower/upper threshold refinement','Arbitrary-report bounded-error inverse-set decoding','Larger and global domains or counterexamples','Complete analytic formalization','Natural operator, infinite arithmetic, real-part, topology, physical acquisition and private-input branches remain active']})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==12 and sorted(n for n,r in receipts.items() if r['returncode'])==FAILURES
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check.olean']]+[(CODE/'proofs/SignedCornerStability.lean','SignedCornerStability.lean')])
write('Development_Notes.json',{'recorded_commands':12,'successful_commands':10,'failed_commands':2,
    'failures':[{'receipt':'lean-draft-v1','result':'A direct draft compiler launch used the repository cwd with an incorrect relative Lean source path; the file was not opened. The actual missing-file error is preserved. The subsequent checker uses explicit absolute source, project and runtime paths.'},
        {'receipt':'lean-proof-v1','result':'The original proof draft omitted the real-number import and called an unimported noncomm_ring tactic. Compilation failed with unknown-tactic and typeclass errors. The failed source and output are preserved; error recovery mentions sorryAx, which is not accepted as a proof. A separate v2 adds the real import, disables autoImplicit, uses distributivity, and corrects quotient-sign cases. All eight lemmas compile. The separate canonical file uses the current Mathlib.Basic.Real.Basic import to remove a deprecation warning.'}],
    'positive_delta':'Both canonical numerical programs and all 28 adversarial mutations pass. Nine exact matrix/algebra controls expose invalid shortcuts. The final eight-lemma canonical Lean source has no errors, warnings or sorryAx.',
    'source_policy':'All executed scientific sources, exploratory reports and actual logs are preserved; corrections use new versions. The four original reports retain their exploratory status while later certificates and the written proof establish the new scoped result.',
    'runtime':'No package acquisition, runtime version change or new source roots.',
    'audit_scope':'The written Proof_Audit.md is an implementing-investigator audit, not a separate agent or human review. Numerical methods differ but share FLINT. The complete assembled theorem remains partly written.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Same pinned Python/FLINT and Lean/mathlib runtime. Eight new generic matrix/Cramer/endpoint lemmas compile; no acquisition.')
for key,pkg in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(pkg)
write('Runtime.json',runtime)
paths=[ROOT/p for p in [certificate.ANCHOR,certificate.REGION,certificate.UPPER,certificate.INPUTS,audit.OWN,audit.SOURCE+'/Equal_Population_Decoder.json',audit.CLASS,audit.ARITH]]+[PRIOR/n for n in ['Verification.json','Research_Queue.json','Branch_Events.jsonl']]+[CODE/'verify_aggregate_variable_noise_delta.py']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'All source selection, field classification, feature units, coordinate center, root-error and actual ambiguity upper premises are inherited unchanged and recursively verified. The lower guarantee and signed region bounds are improved.'})
write('Primary_Sources.json',{'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [PRIOR/'Primary_Sources.json',ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Primary_Sources.json']},'new_source_record':'Source_Acquisition.json',
    'scope':'Current primary Mathlib nonsingular inverse and adjugate documentation was retrieved. Five exact pinned local source files match Git objects and are archived with their license. The closed-hull and secant implications are explicitly derived in the guide and written audit.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Signed resolvent and convex column-family corner delta 2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=ADVANCED,
    replay_scope='Four original explorations, exact signed resolvents, uniform eighth-derivative signs, independent real polynomials and Cramer corner checks, 28 premise mutations, nine exact controls and eight Lean lemmas. Both setup and proof failures are preserved; the semantic proof failure is reproduced.',
    next_priority=['R12/R13/R14: source-feasible stability and ambiguity threshold refinements and arbitrary-report inverse-set decoding','R15: full analytic formalization, parameter families and global region counterexamples','R04/R05/R06/R08/R10: natural operator and infinite arithmetic/real-part bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
    'R12':('uniform_feature_noise_guarantee_strengthened_by_secant_corner','The local uniform guarantee increases to approximately 1.8011173562984702e-10 under the unchanged source and feature-error contract. A closed convex column family contains all secants and has a rigorously bounded corner maximum.','Exploit source-feasible restrictions beyond the outer family; implement bounded-error inverse sets for arbitrary reports and connect exact feature units to physical acquisition.'),
    'R13':('field_and_coefficient_recovery_range_strengthened','The stronger feature separation identifies the inherited two-field class and its tracked 604-column coefficient vector below the strict lower budget. Independent arithmetic repeats 1128 factorizations and 1208 comparisons; inherited ambiguous reports retain 456 fixed and 148 ambiguous domains.','Tighten the source-constrained threshold, extend metadata classes and robust coefficient domains, and avoid conflating a finite tracked vector with full infinite arithmetic recovery.'),
    'R14':('corner_maximum_on_outer_secant_family_proved','Uniform signs allow 21 nondecreasing column replacements; a constant Cramer numerator and determinant orientation settle the remaining face coordinate. The critical inverse bound is approximately 55.5210906442615; the actual ambiguity upper/lower ratio drops to 1.0171405175.','Determine whether source constraints improve the lower bound further; improve actual upper pairs and develop a bounded-error decoder. The outer-family corner need not be source feasible or threshold sharp.'),
    'R15':('independent_signed_corner_and_generic_formal_audit','Independent real derivative polynomials and Cramer determinant ratios verify complex interval signs and corner inverses. Twenty-eight mutations and nine exact counterexamples audit proof premises. Eight generic Lean lemmas compile; a failed draft is preserved and replayed.','Formalize the complete Neumann/Taylor/integral/closed-hull/connectedness assembly and concrete theorem; extend to larger domains or find counterexamples while keeping scope explicit.'),
    'K04':('append_only_signed_corner_evidence_delta','All 117 branches and 453 preceding events are preserved. Five new events link the uniform lower-bound improvement, written convex-family proof, independent numerical audit, 28 adversaries, nine exact controls, eight Lean lemmas and twelve command receipts including two failures.','Continue evidence-backed deltas across the whole ACS research program; preserve source versions, failed attempts, inherited dependencies and private-input gates. No global completion or exhaustion claim.')}
prefix=str(OUT.relative_to(ROOT))+'/'
evidence=['Signed_Corner_Summary.json','Signed_Corner_Certificate.json','Independent_Signed_Corner_Audit.json','Proof_Audit.md','Adversary_Audit.json','Lean_Check.json','Development_Notes.json']
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_signed_corner_and_secant_family_audit')
        b['new_evidence']=[prefix+n for n in evidence]
        b['verification_routes']+=['Exact positive resolvent identities and signed row penalties','Complex Hermite versus independent real eighth-derivative bounds','Interval matrix inverses versus Cramer determinant ratios','28 premise mutations and nine exact algebraic controls','Eight generic Lean matrix/Cramer/endpoint lemmas']
        b['shared_assumptions_and_scope']='Inherited complete finite two-field class, source populations and feature/root error contract. The written proof covers the convex column family containing every local secant. This outer-family maximum need not be source feasible or threshold sharp. Numerical routes share FLINT; the assembled analytic theorem is not fully Lean formalized.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=453
for bid in ADVANCED:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'signed_corner_secant_family_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# A signed corner proof strengthens uniform feature-noise tolerance — 14 September 2026

**The uniform local guarantee increases to approximately 1.8011173562984702e-10.** The preceding actual ambiguity upper endpoint remains approximately 1.831989439894397e-10, giving a ratio of 1.0171405175170667 and a remaining gap of about 1.7%. The exact source-feasible threshold remains open.

The [proof and reproduction guide](../../../code/frontier_verification/SIGNED_CORNER_README.md) derives the full convex column-family argument. The [written proof audit](Proof_Audit.md) checks its hypotheses and scope. The [preceding checkpoint](../2026-09-14-aggregate-variable-noise-delta/README.md) supplies the unchanged actual ambiguity examples.

- [Results and continuation gates](Signed_Corner_Summary.json).
- [Canonical signed resolvent and corner certificate](Signed_Corner_Certificate.json) and [independent real-polynomial/Cramer/arithmetic audit](Independent_Signed_Corner_Audit.json).
- Preserved exploratory [signed resolvent](Signed_Resolvent_Exploration.json), [gradient signs](Gradient_Sign_Exploration.json), [corner inverse](Corner_Inverse_Exploration.json), and [independent candidate audit](Independent_Gradient_Candidate_Audit.json).
- [28 adversarial mutations and nine exact counterexample controls](Adversary_Audit.json).
- [Eight compiled Lean lemmas](Lean_Check.json) and [source/compiled artifact](Lean_Artifacts.zip).
- [Twelve command receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [failed attempts and scope notes](Development_Notes.json), [failed original proof report](Lean_v1.json), and [successful separate proof draft](Lean_v2.json).
- [Primary source acquisition](Source_Acquisition.json), [inherited sources](Primary_Sources.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json), [source inventory](Source_Inventory.json), [source snapshot](Source_Snapshot.zip), [manifest](Manifest.json), and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [458-event ledger](Branch_Events.jsonl), preserving all 453 earlier events byte for byte.

All observation secants lie in a product of closed convex hulls of derivative columns. The inherited weighted matrix defect excludes singularity on that whole family. Exact signed resolvent bounds certify all 22 critical inverse-row signs. Uniform eighth-derivative bounds certify every curvature factor and 21 inverse-direction signs, permitting 21 nondecreasing endpoint column replacements. On the remaining coordinate-12 face, Cramer's numerator is constant and the determinant has fixed orientation. A rigorously negative reference quotient settles the last endpoint. The resulting corner maximizes the critical inverse-row norm over the outer family and yields the uniform finite-difference bound.

Primary complex derivatives at 896/1152 bits are independently checked using real derivative polynomials and a separately certified 48-bit majorant. Point interval inverses at 1024/1536 bits are checked by 22 Cramer determinant ratios at 896/1152 bits. The critical bound is approximately 55.5210906442615. Both interval routes share FLINT; the independent exact residual and positive-series routes are described explicitly. The simpler signed bound also improves the radius-.03 result, retaining a penalty for four unresolved signs; no corner theorem for that larger region is claimed.

The complete inherited two-field class, 22-entry positive source prefixes below 39/2, source selection before noise, root error r=U-1e-8<L, radius-.01 standard coordinate cube and ordered 22 finite feature definitions are unchanged. Independent arithmetic repeats 1128 factorizations and 1208 comparisons. The lower guarantee preserves field identity and its tracked coefficients. The inherited ambiguous reports retain 456 fixed and 148 ambiguous domains among 604 coefficients.

Eight generic Lean algebra/Cramer/endpoint lemmas compile without proof placeholders. The complete Taylor/Neumann/closed-hull/integral/connectedness assembly remains written or computational. One setup path error and one failed proof draft are preserved; a separate corrected draft and canonical proof pass. No runtime version changed and no new source roots were computed.

Next: source-constrained threshold refinements, improved actual pairs, arbitrary-report bounded-error decoding, larger/global regions or counterexamples, and complete analytic formalization. Natural operators, infinite arithmetic and real-part information, topology, physical acquisition and private-input gates remain active. No global completion or exhaustion is claimed.
''')
names=['dedekind_signed_corner_certificate.py','dedekind_signed_corner_audit.py','dedekind_signed_corner_adversary.py','check_signed_corner_lean.py','verify_aggregate_signed_corner_delta.py','SIGNED_CORNER_README.md','proofs/SignedCornerStability.lean']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
    p=todo.pop()
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for mod in modules:
            d=CODE/(mod+'.py')
            if d.exists() and d not in seen:
                seen.add(d);todo.append(d)
                if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
mathlib=BASE.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
external=[(mathlib/e['path'],'external/'+e['path']) for e in read(BASE/'Source_Acquisition.json')['pinned_sources']]+[(mathlib/'LICENSE','external/mathlib-LICENSE')]
explorations=[(BASE/n,'exploration/'+n) for n in ['run_recorded.py','capture_sources.py','create_lean_checker.py','explore_signed_resolvent.py','explore_gradient_signs.py','explore_corner_inverse.py','audit_gradient_candidate.py','SignedCornerStability_v1.lean','SignedCornerStability_v2.lean']]
packaging=[(Path(__file__),'packaging/'+Path(__file__).name)]
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},
    'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},
    'external_runtime_sources':{n:sha(p.read_bytes()) for p,n in external},'exploration_sources':{n:sha(p.read_bytes()) for p,n in explorations},'packaging_sources':{n:sha(p.read_bytes()) for p,n in packaging},
    'scope':'Seven new instruments; transitive imported local Python dependencies; four original explorations; both proof drafts; runner, source capture and checker generator; packager and pinned Mathlib references with license. The preceding verifier is pinned in inherited inputs and recursively executed.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+explorations+external+packaging)
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh recursive replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
        raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. The preceding evidence chain is recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 signed corner and uniform noise delta](2026-09-14-aggregate-signed-corner-delta/README.md): a convex column-family proof strengthens the lower guarantee and reduces the local threshold bracket to about 1.7%.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-variable-noise-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-signed-corner-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':12,'successes':10,'failures':2,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
