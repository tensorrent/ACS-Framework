"""Audit the supplied comparison checker and immutable local evidence only."""
import ast, hashlib, importlib.util, json, os, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SUPPORT=ROOT/'support'
SOURCES=SUPPORT/'source'
OUTPUT=Path(os.environ.get('ACS_FOUNDATIONS_OUTPUT','.'))
manifest=json.loads((SUPPORT/'source_manifest.json').read_text())
for entry in manifest:
    p=SUPPORT/entry['copy']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
checker=SOURCES/'scripts/ym_comparison_checker.py'
spec=importlib.util.spec_from_file_location('pinned_ym_checker',checker)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
rows=[];fixtures={}
for key,pred in module.PREDICTIONS.items():
    vocabulary='; '.join(pred['must_have']+pred['should_have'])
    positive='The proof establishes the following: '+vocabulary+'.'
    negative='The proof does not establish any of the following: '+vocabulary+'. These assertions are false; no theorem has been proved.'
    fixtures[key]={'positive':positive,'negative':negative}
    a=module.analyze_matches(positive)[key];b=module.analyze_matches(negative)[key]
    def direct_score(text):
        lower=text.casefold()
        required=sum(t.casefold() in lower for t in pred['must_have'])
        optional=sum(t.casefold() in lower for t in pred['should_have'])
        return .6*required/len(pred['must_have'])+.4*optional/len(pred['should_have'])
    independent=[direct_score(positive),direct_score(negative)]
    assert a['score']==b['score']==independent[0]==independent[1]==1
    assert a['verdict']==b['verdict']=='MATCH'
    rows.append({'prediction':key,'positive_score':a['score'],'negative_score':b['score'],
      'independent_keyword_scores':independent,'positive_verdict':a['verdict'],'negative_verdict':b['verdict']})

# Tail-window omission is a separate directly reproducible implementation defect.
tail=' '.join(['neutral']*150)+' '+fixtures['C4']['positive']
tail_result=module.analyze_matches(tail)['C4']
assert tail_result['score']==0 and tail_result['verdict']=='MISS'
words=re.sub(r'\s+',' ',tail).split(' ')
vocabulary=module.PREDICTIONS['C4']
last_window=' '.join(words[-150:]).lower()
last_score=.6*sum(t.lower() in last_window for t in vocabulary['must_have'])/len(vocabulary['must_have'])+.4*sum(t.lower() in last_window for t in vocabulary['should_have'])/len(vocabulary['should_have'])
assert last_score==1
tree=ast.parse(checker.read_text())
sealed_refs=[n for n in ast.walk(tree) if isinstance(n,ast.Attribute) and n.attr=='sealed_spec']
assert not sealed_refs
OUTPUT.mkdir(parents=True,exist_ok=True)
(OUTPUT/'comparison_adversarial_fixtures.json').write_text(json.dumps(fixtures,indent=2))
(OUTPUT/'comparison_tail_fixture.txt').write_text(tail)

# These are source receipts and scope checks, not theorem-kernel execution.
lean_dir=SOURCES/'code/constraint_projection/lean'
lean_files=sorted(lean_dir.rglob('*.lean'))
lean_inventory=[]
for p in lean_files:
    text=p.read_text()
    # Strip nested /- -/ comments, then line comments, before token census.
    chars=[];depth=0;i=0
    while i<len(text):
        if text[i:i+2]=='/-':depth+=1;i+=2
        elif depth and text[i:i+2]=='-/':depth-=1;i+=2
        else:
            if not depth:chars.append(text[i])
            i+=1
    stripped=re.sub(r'--[^\n]*','',''.join(chars))
    lean_inventory.append({'file':str(p.relative_to(SOURCES)),
        'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
        'theorem_declarations':len(re.findall(r'\btheorem\s+',stripped)),
        'sorry_admit_tokens':re.findall(r'\b(?:sorry|admit)\b',stripped),
        'axiom_declarations':re.findall(r'(?m)^\s*axiom\s+[^\n]+',stripped)})

prior=json.loads((SUPPORT/'prior/formal_runtime_result.json').read_text())
access=json.loads((SUPPORT/'prior/Access_Receipt.json').read_text())
lock=json.loads((lean_dir/'withMathlib/lake-manifest.json').read_text())
toolchain=(lean_dir/'withMathlib/lean-toolchain').read_text().strip()
print(json.dumps({'source_identity':{'pinned_files':len(manifest),'all_hashes_verified':True},
 'K01_nomenclature':{'production_CDCL':'Constraint-Driven Consensus Layer',
 'standard_CDCL':'Conflict-Driven Clause Learning (SAT)',
 'exact_source':'docs/Cross_Repo_Glossary_Extract.md:51',
 'contract_boundary':'The glossary explicitly says the production component is not a SAT solver. The Boolean reference instrument is an optional test sublanguage only; a production semantic audit requires the actual constraints, dispositions and proof rules.'},
 'K02':{'source_availability_note':'papers/later_FF06_series/The_Reversible_Flattening_Process_Record.tex:339-342 explicitly says engineering-side live AISO/OmniForge source, kernel whitepaper and production merge path are private and absent from this repository.',
 'public_benchmark_present':'code/benchmark_efficiency.py measures scoped public script wall time/throughput. Its existence does not provide the private AISO workload or implementation.',
 'routes':['Pinned public implementation/path inventory','Independent manuscript availability declaration and public benchmark scope docstring'],
 'disposition':'Private performance claims remain evidence-unavailable; no new speed ratio is inferred.'},
 'K03':{'actual_checker':'scripts/ym_comparison_checker.py, copied byte-identically',
 'positive_negative_tests':rows,
 'tail_window_test':{'words':len(words),'actual_score':tail_result['score'],'actual_verdict':tail_result['verdict'],'independent_complete_last_window_score':last_score},
 'sealed_spec_argument_dereferences':len(sealed_refs),
 'routes':['Execute the actual unchanged checker on paired fixtures','Independent score reconstruction and AST/control-flow inspection'],
 'disposition':'Exact limitations and one boundary-scanning bug verified in the available comparison instrument. Full external proof unavailable; these tests say nothing about its truth.',
 'missing_bridge':'Supply complete proof/dependencies and precise theorem; keyword confidence is neither logical entailment nor a calibrated probability. The declared sealed_spec flag is parsed but unused.'},
 'C05':{'lean_source_inventory':lean_inventory,'toolchain':toolchain,
 'lock_packages':[{'name':p.get('name'),'rev':p.get('rev'),'url':p.get('url')} for p in lock.get('packages',[])],
 'historical_runtime_status':prior['status'],'historical_startup_attempts':prior['startup_attempts'],
 'new_runtime_attempts':0,'new_kernel_passes':0,
 'routes':['Source-level theorem/dependency census with content hashes','Preserved independent prior startup receipts for two supported versions'],
 'scope':'No sorry/admit token findings would be static evidence only, not proof verification. AxiomIII.lean explicitly leaves the topological lifting input external.',
 'next_gate':'In a working supported matching runtime, check unchanged files; print theorem axioms; require failure of a separate false-statement fixture. Preserve the dependency lock. Do not patch runtime/access controls.'},
 'K05':{'prior_access_receipt':access,'unchanged_access_retries':0,
 'source_inventory_path':'support/source_inventory.json','status':'Access/runtime boundary retained, with portable pinned audit materials and an executable independent reference instrument.',
 'missing_bridge':'An authorized accessible production revision and a working supported proof runtime, each with declared dependencies.'}},indent=2))
