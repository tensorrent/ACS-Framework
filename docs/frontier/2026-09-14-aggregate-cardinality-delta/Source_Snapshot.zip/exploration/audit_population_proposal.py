"""Independent finite dynamic-programming audit of the single-deletion proposal."""
import hashlib,json,zipfile
from fractions import Fraction as F
from pathlib import Path
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo'
ARCHIVE=ROOT/'docs/frontier/2026-09-13-aggregate-delta/Aggregate_Inputs.zip'
PROPOSAL=BASE/'Population_Observation_Proposal.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def points(z,n):return [(F(x['lo']),F(x['hi'])) for x in json.loads(z.read(n))['positive_root_intervals']]
def pair_cost(a,b,mode):
    if mode=='lower':return max([F(0),a[0]-b[1],b[0]-a[1]])/2
    if mode=='upper':return (max(a[1],b[1])-min(a[0],b[0]))/2
    raise ValueError(mode)
def next_states(state,n,m):
    i,j,da,db=state;out=[]
    if i<n and j<m:out.append(((i+1,j+1,da,db),'match'))
    if i<n and da<1:out.append(((i+1,j,da+1,db),'delete_A'))
    if j<m and db<1:out.append(((i,j+1,da,db+1),'delete_B'))
    return out
def minimax(a,b,mode):
    n,m=len(a),len(b);costs={(0,0,0,0):F(0)};parents={}
    for total in range(n+m+1):
        for state in sorted(k for k in costs if k[0]+k[1]==total):
            i,j,da,db=state
            assert i-da==j-db
            for nxt,move in next_states(state,n,m):
                cost=costs[state] if move!='match' else max(costs[state],pair_cost(a[i],b[j],mode))
                if nxt not in costs or cost<costs[nxt]:costs[nxt]=cost;parents[nxt]=(state,move)
    terminals=[s for s in costs if s[0]==n and s[1]==m]
    assert terminals==[(n,m,1,0)]
    end=terminals[0];bound=costs[end];moves=[]
    while end!=(0,0,0,0):
        prev,move=parents[end];moves.append({'move':move,'a_index':prev[0],'b_index':prev[1]});end=prev
    return bound,list(reversed(moves)),len(costs)
def threshold(a,b,mode,radius):
    todo=[(0,0,0,0)];seen=set(todo);n,m=len(a),len(b)
    while todo:
        state=todo.pop();i,j,da,db=state
        if i==n and j==m:return True
        for nxt,move in next_states(state,n,m):
            if nxt in seen:continue
            if move=='match' and pair_cost(a[i],b[j],mode)>radius:continue
            seen.add(nxt);todo.append(nxt)
    return False
def main():
    proposed=json.loads(PROPOSAL.read_text());results=[]
    with zipfile.ZipFile(ARCHIVE) as z:
        for case in proposed['cases']:
            bits=case['precision_bits'];a=points(z,'S1_'+str(bits)+'.json');b=points(z,'S2_'+str(bits)+'.json')
            assert [len(a),len(b)]==[23,22]
            lower,lp,ls=minimax(a,b,'lower');upper,up,us=minimax(a,b,'upper')
            assert lower==F(case['optimal_radius_lower']) and upper==F(case['constructive_radius_upper'])
            assert lower<=upper and upper-lower<F(1,10**30)
            eps=F(1,10**100)
            for mode,cost in [('lower',lower),('upper',upper)]:
                assert threshold(a,b,mode,cost) and not threshold(a,b,mode,cost-eps)
            omit=case['best_omitted_A_index_zero_based'];retained=a[:omit]+a[omit+1:];observed=list(map(F,case['common_observation']))
            assert len(observed)==22 and all(0<x<20 for x in observed) and all(x<y for x,y in zip(observed,observed[1:]))
            checks=0
            for roots in [retained,b]:
                for t,(lo,hi) in zip(observed,roots):
                    assert t-upper<=lo<=hi<=t+upper;checks+=2
            rows=case['all_single_deletion_cases'];assert {r['omitted_A_index_zero_based'] for r in rows}==set(range(23)) and len(rows)==23
            replayed=0
            for r in rows:
                deleted=r['omitted_A_index_zero_based'];ar=a[:deleted]+a[deleted+1:]
                assert len(r['pairs'])==22
                actual_lower=[];actual_upper=[]
                for pa,pb,p in zip(ar,b,r['pairs']):
                    assert list(map(F,p['a_interval']))==list(pa) and list(map(F,p['b_interval']))==list(pb)
                    lo=pair_cost(pa,pb,'lower');hi=pair_cost(pa,pb,'upper');center=(min(pa[0],pb[0])+max(pa[1],pb[1]))/2
                    assert F(p['radius_lower'])==lo and F(p['radius_upper'])==hi and F(p['common_ordinate'])==center
                    actual_lower.append(lo);actual_upper.append(hi);replayed+=1
                assert max(actual_lower)==F(r['radius_lower']) and max(actual_upper)==F(r['radius_upper'])
            results.append({'precision_bits':bits,'DP_lower':str(lower),'DP_upper':str(upper),'bound_gap':str(upper-lower),
                            'DP_states':[ls,us],'lower_path':lp,'upper_path':up,'endpoint_inclusions':checks,'pair_rows_replayed':replayed,
                            'threshold_boundary_checks':4,'all_actual_root_intervals_contained_in_common_observation_boxes':True})
    result={'status':'finite_audit_passed_general_matching_proof_pending','source_sha256':sha(Path(__file__)),
            'inputs_sha256':{str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else p.name:sha(p) for p in [PROPOSAL,ARCHIVE]},
            'cases':results,'scope':'Dynamic programming independently obtains the rational bounds without choosing a deleted index in advance. Boolean reachability tests both boundaries. Explicit common observations contain both actual source interval sets after the declared deletion. A general uncrossing proof, fixed-population classifier audit and semantic adversary are still required before packaging a new research checkpoint.'}
    (BASE/'Population_Proposal_Audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'cases':[{'bits':c['precision_bits'],'states':c['DP_states'],'pair_rows':c['pair_rows_replayed'],'endpoint_checks':c['endpoint_inclusions'],'gap_below_1e_minus_30':F(c['bound_gap'])<F(1,10**30)} for c in results]},indent=2))
if __name__=='__main__':main()
