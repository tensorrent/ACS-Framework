from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).absolute().parent
name=sys.argv[1];cwd=Path(sys.argv[2]).absolute();command=sys.argv[3:]
out=root/name;out.mkdir(exist_ok=False)
start=datetime.now(timezone.utc)
inputs={str(Path(x).absolute()):hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in command if x.endswith('.py') and Path(x).is_file()}
with (out/'stdout.txt').open('w') as stdout,(out/'stderr.txt').open('w') as stderr:
 try:
  proc=subprocess.run(command,cwd=cwd,text=True,stdout=stdout,stderr=stderr,timeout=900,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1'})
  rc=proc.returncode;timed_out=False
 except subprocess.TimeoutExpired:
  rc=124;timed_out=True
r={'started_utc':start.isoformat(),'elapsed_seconds':(datetime.now(timezone.utc)-start).total_seconds(),'cwd':str(cwd),'command':command,'returncode':rc,'timed_out':timed_out,'input_sources_sha256':inputs,'stdout_sha256':hashlib.sha256((out/'stdout.txt').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'stderr.txt').read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print((out/'stdout.txt').read_text()[-2000:]);print((out/'stderr.txt').read_text()[-2000:]);raise SystemExit(rc)
