"""Exploratory signs of inverse sensitivity derivatives over the full matrix enclosure."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import hashlib,json,sys
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_weighted_region_certificate import derivatives,av,enc
from dedekind_augmented_feature_audit import SPECS
ANCHOR=ROOT/'docs/frontier/2026-09-14-aggregate-augmented-feature-delta/Augmented_Proposals_Local.json'
REGION=ROOT/'docs/frontier/2026-09-14-aggregate-weighted-feature-delta/Weighted_Region_Certificate.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 a=json.loads(ANCHOR.read_text());s=json.loads((BASE/'Signed_Resolvent_Exploration.json').read_text());c=list(map(F,a['common_rational_coordinates']));R=[list(map(F,row)) for row in a['full_rank_proposal']['preconditioner']];record=s['regions'][0];eta=F(1,100);row=list(map(F,record['positive_resolvent_critical_row']));u0=list(map(F,record['signed_R_times_v']));h=list(map(F,record['signed_vector_supersolution']));ud=[h[i]-abs(u0[i]) for i in range(22)];uintervals=[(u0[i]-ud[i],u0[i]+ud[i]) for i in range(22)];assert all(x>=0 for x in ud)
 results=[]
 for bits in [896,1152]:
  ctx.prec=bits;RR=arb_mat([[av(x) for x in r] for r in R]);absR=arb_mat([[abs(RR[i,j]) for j in range(22)] for i in range(22)]);point=[[derivatives(spec,av(x),8) for x in c] for spec in SPECS]
  coefficient=[RR*arb_mat([[point[k][j][t+2] for j in range(22)] for k in range(22)]) for t in range(6)]
  highest=arb_mat([[abs(derivatives(spec,av(x)+arb(0,av(eta).upper()),8)[8]) for x in c] for spec in SPECS]);remainder=absR*highest*av(eta)**6/factorial(6)
  cols=[]
  for j in range(22):
   radius=[sum((abs(coefficient[t][i,j])*av(eta)**t/factorial(t) for t in range(1,6)),arb(0))+remainder[i,j] for i in range(22)]
   inverse_variation=sum((av(row[i]-int(i==1))*(abs(coefficient[0][i,j])+radius[i]) for i in range(22)),arb(0))
   bound=coefficient[0][1,j]+arb(0,(radius[1]+inverse_variation).upper());ulo,uhi=uintervals[j];usign=1 if ulo>0 else -1 if uhi<0 else 0;asign=1 if bound>0 else -1 if bound<0 else 0
   cols.append({'coordinate':j,'critical_row_times_second_derivative':enc(bound),'curvature_sign':asign,'inverse_direction_interval':[str(ulo),str(uhi)],'inverse_direction_sign':usign,'candidate_K_derivative_sign':-asign*usign,'curvature_center_display':float(coefficient[0][1,j].mid()),'curvature_radius_display':float((radius[1]+inverse_variation).upper())})
  results.append({'precision_bits':bits,'columns':cols,'certified_derivative_signs':sum(x['candidate_K_derivative_sign']!=0 for x in cols)})
 return {'status':'exploratory_bounds_require_independent_audit','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [ANCHOR,REGION,BASE/'Signed_Resolvent_Exploration.json',CODE/'dedekind_weighted_region_certificate.py']},'region_radius':'1/100','checks':results,
  'candidate_argument':'For K=e_1^T J^-1 v with certified fixed critical-row signs, dK/dy_j=-(e_1^T J^-1 g_second(y_j))*(J^-1 v)_j. Exact resolvent bounds enclose the second factor. The first factor retains R*g_second Taylor cancellations before bounding the inverse perturbation. A monotonicity conclusion requires all relevant factor signs and a proof applying to the appropriate matrix/observation family.',
  'scope':'Exploratory sign enclosures only. No corner extremum, new globally valid stability constant or published lower guarantee is claimed. Pointwise inverse bounds alone do not give finite-difference inverse stability on a nonconvex feature image; a secant or matrix-hull bridge is necessary.'}
r=run();(BASE/'Gradient_Sign_Exploration.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'certified_sign_counts':[x['certified_derivative_signs'] for x in r['checks']],'columns':[{k:x[k] for k in ['coordinate','curvature_sign','inverse_direction_sign','candidate_K_derivative_sign','curvature_center_display','curvature_radius_display']} for x in r['checks'][-1]['columns']]},indent=2))
