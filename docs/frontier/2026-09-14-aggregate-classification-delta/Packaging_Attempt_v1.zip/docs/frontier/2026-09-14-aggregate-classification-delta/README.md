# Complete quartic classification and count information — 14 September 2026

Degree four, signature (0,2) and absolute field discriminant **576 determine exactly two fields**, A=Q(sqrt(2),sqrt(-3)) and B=Q(sqrt(-2),sqrt(-3)). The V4 group is derived from those metadata, closing the earlier non-V4 classification gap. A certified aggregate positive-zero count then selects the field and its Euler coefficient formula. All 604 tracked coefficients are independently checked.

The [proof and reproduction guide](../../../code/frontier_verification/FULL_QUARTIC_CLASS_README.md) gives the full arithmetic argument, source references, actual-field controls and count contracts. The general proof is written mathematics, **not yet formalized in Lean**.

- [Results and next gates](Classification_Summary.json), with the [four-field metadata input](Metadata.json).
- [Complete field classification](Full_Quartic_Class.json) and [independent audit](Full_Class_Audit.json): generator closure versus all 2,048 identity-containing A4 subsets; square-class planes versus all 256 sign-valued functions modulo 24.
- [Two actual A4 controls](A4_Field_Controls.json), of field discriminants 3136 and 5184: integral orders, exact trace discriminants, 470 projective maximality checks covering 2,510 nonzero residue cosets, Newton trace agreement and independent round_two lattices.
- [Count-only arithmetic decoder](Complete_Class_Count_Decode.json) and [independent count/arithmetic audit](Complete_Count_Audit.json): twenty cases, sixteen unique selections, 1,128 polynomial factorizations and 1,208 coefficient comparisons.
- [Thirteen semantic mutations](Adversary_Audit.json), with eight interval-certified half-radius count-ambiguity controls in the independent audit.
- [Seven successful execution receipts](Execution_Receipts.json), [full execution logs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited input hashes](Inherited_Inputs.json) and [primary source fingerprints](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [frozen source snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [423-event ledger](Branch_Events.jsonl), preserving the previous 418 events byte for byte.

Square signed discriminant restricts the normal-closure group to V4 or A4. In the A4 case its cyclic cubic quotient cannot ramify at two; ramification at three would force a wild cubic local factor and a discriminant exponent at least three, contradicting two. The quotient would be everywhere unramified at finite primes, contradicting Minkowski. The remaining V4 case has seven possible quadratic-subfield planes, of which precisely two have the specified invariants.

The exact complete count through height 20 is 23 for A and 22 for B. The count below 7/3 also distinguishes them for every allowed independent ordinate displacement of size at most **1/3**. At radius 1/2 both fields can yield either count zero or one: this is ambiguity of this statistic, not a claim about the full spectrum. Completeness through 20 alone does not justify a noisy count at height 20; the robust result uses an interior gate with a checked margin.

Metadata alone fixes **456 of 604 coefficients and 12 of 17 targets**. The distinguishing count resolves the other 148 coefficients, including target indices 3,7,19,27,31. No new roots or measurement rows are computed. The classifier reads no group label, catalogue, polynomial or spectrum; the count selector receives no field label or individual ordinates. Candidate templates use inherited certified roots, and arithmetic vectors appear only in downstream independent checks.

The actual A4 controls demonstrate the need for the hypotheses: discriminant 3136 permits an extra ramified prime seven, while discriminant 5184 permits wild exponent four at three. All seven recorded source/scientific commands succeed. Earlier dated evidence, failed attempts and stronger scoped certificates remain unchanged in the [preceding checkpoint](../2026-09-14-aggregate-primal-delta/README.md).

The next benchmark should match degree, signature, discriminant and finite zero counts, or declare explicit restrictions on prior information and decoder. Earlier Gaussian recovery remains valid under its stated method and assumptions; its sufficient radii are not optimal limits for the richer decoder here. Arithmetic formalization, broader field classes, natural operators, infinite arithmetic, topology and private-input gates remain active. No global completion or exhaustion is claimed.
