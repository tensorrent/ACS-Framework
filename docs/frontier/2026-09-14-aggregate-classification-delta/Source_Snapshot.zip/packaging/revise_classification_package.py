from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
assert not (OUT/'Packaging_Attempt_v1.zip').exists()
oldmanifest=read(OUT/'Manifest.json')
oldfiles=sorted(set([ROOT/p for p in oldmanifest['files']]+list(OUT.iterdir())))
archive('Packaging_Attempt_v1.zip',[(p,str(p.relative_to(ROOT))) for p in oldfiles])
(OUT/'Verification_Diagnosis.json').write_bytes((BASE/'Verification_Diagnosis.json').read_bytes())
attempts={n:read(BASE/n/'receipt.json') for n in ['final-recursive-verification','verification-diagnosis']}
assert attempts['final-recursive-verification']['returncode']==1 and attempts['verification-diagnosis']['returncode']==0
write('Verification_Attempts.json',attempts)
archive('Verification_Attempt_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in attempts for f in ['receipt.json','stdout.txt','stderr.txt']])
notes=read(OUT/'Development_Notes.json')
notes['verification_attempts']={'failed_recursive_verification':1,'successful_diagnoses':1,'cause':'Integer-key subgroup counts become string-key JSON objects; numerical versus lexical sort order made the first byte comparison fail despite identical data. The preceding recursive checkpoint replay had succeeded.',
 'correction':'Separate v2 verifier normalizes through JSON before comparison and rejects colliding keys. Four controls accept representation equivalence and reject changed values/key collisions. Original scientific instruments, their outputs and all seven scientific/source receipts are unchanged.',
 'preservation':'Original verifier, proof guide and packager remain unchanged. Packaging_Attempt_v1.zip preserves the entire first package and manifest-bound code. Failed verification, successful diagnosis and their sources/logs are retained separately.',
 'rerun':'The v2 verifier checks new science/provenance before repeating the complete prior recursive replay. Final verification receipt remains separate from the seven scientific/source commands.'}
write('Development_Notes.json',notes)
text=(OUT/'README.md').read_text().replace('FULL_QUARTIC_CLASS_README.md','FULL_QUARTIC_CLASS_README_v2.md')
text=text.replace('- [Source inventory]', '- [Preserved verification attempts](Verification_Attempts.json), [attempt logs](Verification_Attempt_Artifacts.zip), [exact diagnosis](Verification_Diagnosis.json) and [original package snapshot](Packaging_Attempt_v1.zip).\n- [Source inventory]')
text=text.replace('All seven recorded source/scientific commands succeed.', 'All seven recorded source/scientific commands succeed. The first final verifier completed the inherited replay but failed on integer-versus-string JSON key ordering in the regenerated subgroup-count audit. A recorded diagnosis establishes complete document equality after JSON normalization. The separate v2 verifier corrects that comparison, checks four representation/corruption controls and retains the original failed version and package. Scientific sources and outputs are unchanged.')
(OUT/'README.md').write_text(text)
inventory=read(OUT/'Source_Inventory.json');names=[Path(p).name for p in inventory['instruments']]+['verify_aggregate_classification_delta_v2.py','FULL_QUARTIC_CLASS_README_v2.md']
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
inventory.update(instruments={str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},dependencies={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},scope='Original and v2 verifier/guide retained with all scientific instruments and transitive local Python imports. Separate diagnosis and packaging sources are archived. Prior checkpoints are recursively verified; the arithmetic proof is written, not a Lean theorem.')
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py','acquire_classification_inputs.py','diagnose_verification_replay.py','publish_aggregate_classification_delta.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'The first verifier failed on JSON key ordering; v2 is pending. This is not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':datetime.now(timezone.utc).isoformat(),'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; the first package is preserved in Packaging_Attempt_v1.zip and preceding checkpoints are verified recursively.'})
print(json.dumps({'status':'revised_package_ready','manifest_files':len(files),'scientific_receipts':7,'preserved_failed_verifications':1,'diagnoses':1,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
