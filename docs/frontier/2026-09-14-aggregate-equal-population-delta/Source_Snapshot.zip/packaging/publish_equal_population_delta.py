from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.metadata,json,platform,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta';PRIOR=ROOT/'docs/frontier/2026-09-14-aggregate-cardinality-delta'
CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta';PAIR=ROOT/'docs/frontier/2026-09-13-biquadratic-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_equal_population_delta import summarize
OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
 assert (OUT/name).stat().st_size<100*1024**2
documents=['Input_Provenance.json','Equal_Population_Decoder.json','Equal_Population_Audit.json','Adversary_Audit.json','Cutoff_Plateau.json','Lean_Check.json','Lean_Check_v2.json','Lean_Check_v3.json']
for name in documents:(OUT/name).write_bytes((BASE/name).read_bytes())
provenance,decoded,checked,adv,cutoffs,formal=[read(BASE/n) for n in ['Input_Provenance.json','Equal_Population_Decoder.json','Equal_Population_Audit.json','Adversary_Audit.json','Cutoff_Plateau.json','Lean_Check_v3.json']]
summary=summarize(provenance,decoded,checked,adv,cutoffs,formal)
write('Equal_Population_Summary.json',{'recorded_utc':now,'result':'Equal total counts do not remove the strongest binary information in a finite source list: one interior count has the same sharp theoretical separation threshold as the complete list under preserved-population absolute coordinate errors.',
 'derived_results':summary,'mathematical_argument':'For sorted equal-length lists choose a maximum-gap index k and its true midpoint height. Below half that gap, at most k entries of one list and at least k+1 of the other can lie below the gate. The ordered midpoint list is common at the half-gap threshold. Strict interval dominance identifies the second positive roots as the critical pair in this actual field class.',
 'rational_vs_symbolic':'The implemented rational height uses certified box endpoints. It guarantees separation for r<L. The true-root midpoint need not equal that rational height. Overlapping closed-box count envelopes at L are epistemic and do not establish actual-field ambiguity there; the rational uniform common witness at U does.',
 'input_contract':'Complete source selection below39/2 precedes coordinate perturbation. All22entries and multiplicities remain, including any noisy points outside the original window. No post-noise censoring or edit allowance is used.',
 'cutoff_continuum':'The identical source lists occur for every cutoff in the certified open plateau, approximately(19.086441660064803,19.724015324441552). Endpoint inequalities prove the continuum result; eighteen interior cutoff controls supplement it.',
 'scope':'Known benchmark, complete two-field metadata class inherited from a source-backed written argument, inherited complete finite spectra, no new zeros or Gaussian budgets. Eight constituent Lean lemmas pass; full arithmetic and spectral bridges remain written/computational.',
 'next_gate':'Define and audit a feature-only Gaussian observation contract with actual-source perturbations, explicit errors and tail treatment; prove actual feasibility or separation with validated analysis. Maintain the broader117branch ACS program, natural operators, infinite information, topology, physical interpretation and private-input gates. No global completion.'})
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==8 and sum(r['returncode']==0 for r in receipts.values())==6
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/n/f,n+'/'+f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
archive('Equal_Population_Inputs.zip',[(p,p.name) for p in sorted((BASE/'inputs').glob('*.json'))])
archive('Lean_Artifacts.zip',[(BASE/n,n) for n in ['Lean_Check.json','Lean_Check_v2.json','Lean_Check_v3.json','Lean_Check_v3.olean']]+[(CODE/('proofs/'+n),n) for n in ['InteriorCount.lean','InteriorCount_v2.lean','InteriorCount_v3.lean']])
write('Development_Notes.json',{'recorded_commands':8,'successful_commands':6,'failed_commands':2,
 'failures':[{'receipt':'interior-count-lean','source':'code/frontier_verification/proofs/InteriorCount.lean','cause':'Mathlib.Tactic.Omega is unavailable in the pinned runtime.','correction':'A separate v2 source imports the existing Lean.Elab.Tactic.Omega module.'},
             {'receipt':'interior-count-lean-v2','source':'code/frontier_verification/proofs/InteriorCount_v2.lean','cause':'The identifier prefix is a reserved Lean keyword; parsing fails and downstream declarations remain unproved. The failed output is not a kernel success.','correction':'A separate v3 source renames that variable pre. All eight declarations then compile with only the reported standard axioms and no sorryAx.'}],
 'canonical_Lean_source':'code/frontier_verification/proofs/InteriorCount_v3.lean','source_policy':'Original executed Python and Lean sources and every recorded result remain unchanged. The final recursive verifier runs after packaging and has its own external receipt and final report. New mathematical instruments passed on their first recorded runs.',
 'boundary_findings':'The equal-population examples are complete restricted source lists, not a blinded study. r=L box overlap is not actual-field ambiguity. Exact radii separated by2e-100 can coincide in binary64. The strict and closed counts of the same common observation differ.'})
runtime=read(PRIOR/'Runtime.json');runtime.update(recorded_utc=now,python=sys.version,executable=sys.executable,platform=platform.platform(),scope='Fresh exact Fraction/count/matching and polynomial computations on the inherited environment. Eight new interior-count lemmas compile under the pinned Lean/mathlib versions. No new dependency installation or zero computation.')
for key,package in [('python_flint','python-flint'),('sympy','sympy'),('numpy','numpy'),('scipy','scipy'),('mpmath','mpmath'),('pytest','pytest'),('clarabel','clarabel'),('cffi','cffi'),('pycparser','pycparser')]:runtime[key]=importlib.metadata.version(package)
write('Runtime.json',runtime)
paths=[INPUTS/'Aggregate_Inputs.zip',PAIR/'Pair_Spectra.zip',PAIR/'Pair_Arithmetic.json',CLASS/'Full_Quartic_Class.json',CLASS/'Full_Class_Audit.json',PRIOR/'Verification.json',PRIOR/'Research_Queue.json',PRIOR/'Branch_Events.jsonl']
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},'scope':'Complete metadata classification and all finite zero/completeness certificates are inherited and recursively verified. New prefix membership is checked independently against both parent source arrays and the separately stored factor aggregate.'})
write('Primary_Sources.json',{'new_downloads':0,'inherited_source_records_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [CLASS/'Primary_Sources.json',PAIR/'Primary_Sources.json']},'scope':'Inherited primary-source premises are preserved. The new finite-list interior-count theorem and cutoff restriction are derived in the proof guide and supported by exact arithmetic and the stated Lean lemmas.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Equal populations and sharp interior-count delta2026-09-14',recorded_utc=now,parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],replay_scope='Fresh source restriction, count-only decisions, independent arithmetic/attainable sets/bipartite matching, actual common observations, cutoff continuum,36mutations and8Leanlemmas.',
 next_priority=['R12/R13/R14: precisely define a feature-only observation and certify actual-source ambiguity or separation with explicit noise/tail assumptions','R15: generalize equal-population classes and fully formalize source-rank and arithmetic bridges','R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges','S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('equal_population_inputs_with_certified_cutoff_continuum','Complete restriction to19.5 yields22roots perfield, preserving four anonymous metadata/root payloads and separate provenance. Every cutoff in the certified open plateau selects the same lists. Total count retains both fields; interior count still separates them.','Define actual observables for a feature-only release. Distinguish preselected entries from post-noise censoring, preserve completeness provenance, and derive any new tail budgets.'),
 'R13':('sharp_interior_count_recovers_arithmetic_despite_equal_totals','For the binary field class, a rational interior count gate certifies all604tracked coefficients whenever0<=r<L. At the common actual observation atU,456arefixed and148ambiguous.1128independent polynomial factorizations verify both604-value vectors.','Extend to larger metadata classes and feature-only measurements. Do not identify a method-specific Gaussian bound with an information-theoretic bound.'),
 'R14':('general_binary_count_threshold_and_actual_equal_population_witness','For sorted equal-length lists, a count at a maximum-gap midpoint separates below half the maximum gap, while the ordered midpoint list is common at that threshold. Here the second-root gap dominates and gives the same exact symbolic threshold as the full list, with a2e-30numeric enclosure.','Investigate other observables, norms and classes. Certify actual-source feature collisions or separation; numerical small residuals alone are not existence proofs.'),
 'R15':('independent_count_matching_boundary_and_formal_checks','Independent attainable sets and unrestricted bipartite matching replay32count cases and8boundary searches;176witness endpoint checks,42strict comparisons and32016literal finite matchings support the theorem.36mutations reject, and8Leanlemmas pass after2preserved syntax/import failures.','Formalize the full bridge from indexed source ranks and spectral certificates to the finite-list hypotheses, and test equal-count benchmarks with larger candidate classes.'),
 'K04':('ongoing_delta_with_equal_count_provenance_and_failure_history','Preserve117branches and428events, appendfive. Eight recorded runs include6successes and2preserved Lean failures with a separate canonicalv3. Scientific computations, proof scope and exact numerical boundary distinctions remain explicit.','Continue verified research deltas and justified expansions without global completion; preserve every prior branch, assumption, failure, receipt and actionable input gate.')}
prefix=str(OUT.relative_to(ROOT))+'/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_equal_population_interior_count_audit')
  b['new_evidence']=[prefix+n for n in ['Equal_Population_Summary.json','Input_Provenance.json','Equal_Population_Inputs.zip','Equal_Population_Decoder.json','Equal_Population_Audit.json','Adversary_Audit.json','Cutoff_Plateau.json','Lean_Check_v3.json']]
  b['verification_routes']+=['Exact cutoff membership against parent and independent factor aggregate','Attainable-count DP and independent modular polynomial arithmetic','Unrestricted bipartite matching and32016literal finite matchings','Actual rational common observation with176endpoint inclusions','Eight Lean scalar/list lemmas and36semantic mutations']
  b['shared_assumptions_and_scope']='Inherited complete two-field metadata class and finite source spectra; complete22-entry populations selected before coordinate errors, allentries/multiplicities preserved. Rational count guarantee r<L, symbolic true-root threshold delta_star, actual common witness U. Box overlap at L does not prove actual ambiguity. No new Gaussian budgets or infinite-spectrum conclusion.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=428
for bid in q['advanced_existing_branches']:
 b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'equal_population_interior_count_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Equal populations and a sharp interior count — 14 September 2026

Both actual benchmark fields now supply **22 complete source ordinates below19.5**. Total population no longer identifies them. A single interior cumulative count still separates them below the sharp theoretical full-list ambiguity threshold: half the difference of their second positive ordinates, approximately **0.5732773345123776**.

The [proof and reproduction guide](../../../code/frontier_verification/INTERIOR_COUNT_README.md) derives the general binary finite-list result and its interval-certified application. The [previous checkpoint](../2026-09-14-aggregate-cardinality-delta/README.md) preserves the distinct population/deletion/window models. This checkpoint preselects the22source entries, then preserves all of them and their multiplicities under independent bounded coordinate errors.

- [Results, scope and next gates](Equal_Population_Summary.json).
- [Four anonymous equal-population inputs](Equal_Population_Inputs.zip) and [full cutoff provenance](Input_Provenance.json):90parent intervals partitioned,88retained, no new roots computed.
- [Count decoder and actual common observations](Equal_Population_Decoder.json):32cases,20uniformly unique; the rational gate guarantees r<L, and both actual fields share the stored22entry observation atU.
- [Independent arithmetic/count/matching audit](Equal_Population_Audit.json):1128polynomial factorizations,1208coefficient comparisons,176endpoint inclusions,42strict noncritical inequalities, and8unrestricted bipartite matching boundary checks using1936pair costs.
- [Adversary audit](Adversary_Audit.json):32semantic mutations,1741finite multiset pairs,32016literal indexed matchings and1672positive-gap count gates. Exact boundary radii can round to the same binary64 number.
- [Certified continuum of equivalent cutoffs](Cutoff_Plateau.json):an open interval approximately(19.086441660064803,19.724015324441552),162exact checks,18interior cutoff controls and4additional mutations.
- [Eight successful Lean lemmas](Lean_Check_v3.json), [first failed attempt](Lean_Check.json), [second failed attempt](Lean_Check_v2.json), and [all sources/compiled evidence](Lean_Artifacts.zip).
- [Eight execution receipts](Execution_Receipts.json), [full logs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json), and [inherited primary sources](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [frozen source snapshot](Source_Snapshot.zip), [manifest](Manifest.json), and [fresh recursive verification](Verification.json).
- [All117research branches](Research_Queue.json) and [433-event ledger](Branch_Events.jsonl), preserving the preceding428events byte for byte.

The count theorem applies to a known binary class of equal-length sorted real lists: a maximum-gap midpoint height separates cumulative counts for every radius below half that gap. The ordered midpoint list is common at the threshold, proving sharpness. The rational implemented height uses certified box endpoints; it is not asserted to equal the true-root midpoint. The radius enclosure still has width2e-30. Overlapping closed-box count envelopes atL do not establish actual-field ambiguity there. The explicit rational witness atU does.

Unique count selection fixes all604tracked Euler coefficients. At the actual common observation, exactly456remain fixed and148are ambiguous, including targets3,7,19,27,31. The metadata class and complete finite spectra retain their inherited written/computational premises. Eight constituent scalar/list lemmas are Lean-checked; the full arithmetic/spectral bridge is not claimed fully formalized.

The anonymous files are known synthetic benchmark inputs. Their parent labels and population sizes remain outside decoder input, and a count cannot certify its own completeness. All preselected entries remain even if noisy coordinates leave the original window. No Gaussian tail/moment budgets transfer automatically to the new cutoff.

Next, define a feature-only measurement contract and certify actual-source feasibility or separation with explicit noise and tail assumptions. The broader ACS program remains active, including natural operators, infinite information, topology, physical interpretation, formalization and private-input gates. This is a research delta, with no global completion claim.
''')
names=sorted({p.name for p in CODE.glob('dedekind_equal_population_*.py')}|{'check_interior_count_lean.py','verify_aggregate_equal_population_delta.py','INTERIOR_COUNT_README.md','proofs/InteriorCount.lean','proofs/InteriorCount_v2.lean','proofs/InteriorCount_v3.lean'})
deps=set();todo=[CODE/n for n in names if n.endswith('.py')];seen=set(todo)
while todo:
 p=todo.pop()
 for node in ast.walk(ast.parse(p.read_text())):
  modules=[node.module] if isinstance(node,ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node,ast.Import) else []
  for mod in modules:
   d=CODE/(mod+'.py')
   if d.exists() and d not in seen:
    seen.add(d);todo.append(d)
    if d.name not in names:deps.add(d)
deps.add(CODE/'source_requirements.txt')
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(deps)},'scope':'All new instruments, guide and three immutable Lean versions, plus transitive local Python imports. The canonical Lean source is v3; earlier attempts are preserved failures.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/'run_recorded.py','exploration/run_recorded.py'),(Path(__file__),'packaging/'+Path(__file__).name)])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder before fresh final replay; not a success claim.'})
files={}
for p in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference. Preceding checkpoints are recursively verified.'})
index=OUT.parent/'README.md';text=index.read_text();marker='- [Current research queue]';assert marker in text
text=text.replace(marker,'- [14 September 2026 equal-population interior-count delta](2026-09-14-aggregate-equal-population-delta/README.md): equal total counts, a sharp interior count gate, actual common observations, independent matching/arithmetic audits and eight Lean lemmas.\n'+marker)
text=text.replace('[Current research queue](2026-09-14-aggregate-cardinality-delta/Research_Queue.json)','[Current research queue](2026-09-14-aggregate-equal-population-delta/Research_Queue.json)');index.write_text(text)
print(json.dumps({'status':'packaged','manifest_files':len(files),'recorded_commands':8,'successes':6,'failures':2,'branches':117,'events':sequence,'archives':{p.name:p.stat().st_size for p in OUT.glob('*.zip')}}))
