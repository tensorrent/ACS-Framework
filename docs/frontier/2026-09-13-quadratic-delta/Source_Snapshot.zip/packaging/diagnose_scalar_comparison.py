import json,sys,time
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0,str(Path(sys.argv[1])/'code/frontier_verification'))
import mpmath as mp
from flint import arb,ctx
import dedekind_quadratic_ordinate as q
import dedekind_coupled_recovery as c
import dedekind_quadratic_numeric as numeric
root=Path(sys.argv[1]);folder=Path(sys.argv[2]);result=json.loads((folder/'Quadratic_160.json').read_text())
data,powers,rows,seeds,previous,provenance=q.load(root/'docs/frontier/2026-09-13-shared-delta',160)
basis,metadata=q.prepare(data,rows,160)
mp.mp.dps=80;ctx.prec=256
def fraction(x):
 m,e=map(int,x.man_exp());return F(m)*F(2)**e
visited=set()
for step in result['rounds']:
 for check in step['checks']:
  for proposal in check['certificates']:
   key=proposal['combination_sha256']
   if key in visited or not proposal['multipliers']:continue
   visited.add(key);alpha=[F(0)]*len(rows)
   for i,v in proposal['multipliers']:alpha[i]=F(v)
   combo=q.combine(rows,basis,alpha)
   for j,(d,e) in enumerate(zip(combo['noise'],combo['curve'])):
    support,independent,kind=q.scalar_support(d,e)
    if kind!='interior_vertex' or not e>0:continue
    vertex=-d/(2*e)
    if not(vertex.lower()>-1 and vertex.upper()<1):continue
    value=-d*vertex-e*vertex*vertex
    endpoint=max(arb(0),(-d-e).upper(),(d-e).upper());excess=value-endpoint
    if not excess>0:continue
    dd,ee=numeric.mp_exact(d.mid()),numeric.mp_exact(e.mid());vv=-dd/(2*ee)
    maximum=max(mp.mpf(0),-dd-ee,dd-ee,-dd*vv-ee*vv)
    D,E=fraction(d.mid()),fraction(e.mid());exact=D*D/(4*E)
    upper=fraction(support.upper())
    out={'root_index':j,'combination':key,'d':c.encode(d),'e':c.encode(e),'support':c.encode(support),
     'mp_maximum':mp.nstr(maximum,100),'mp_support_upper':mp.nstr(numeric.mp_exact(support.upper()),100),
     'mp_comparison_passed':maximum<=numeric.mp_exact(support.upper()),
     'exact_midpoint_maximum':str(exact),'exact_support_upper':str(upper),
     'exact_comparison_passed':exact<=upper,'relative_gap_exact':str((upper-exact)/exact)}
    (folder/'Scalar_Diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['exact_midpoint_maximum','exact_support_upper','relative_gap_exact']}))
    raise SystemExit(0)
raise AssertionError('No witness')

