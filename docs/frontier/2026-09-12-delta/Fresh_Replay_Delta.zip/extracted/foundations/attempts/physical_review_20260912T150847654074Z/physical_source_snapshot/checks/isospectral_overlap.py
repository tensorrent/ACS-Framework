"""Local smooth Dirichlet-isospectral potentials do not fix cluster overlap."""
import json,math
import numpy as np
import sympy as s
from scipy.integrate import quad
from scipy.linalg import eigh_tridiagonal

# Algebraic intertwining verification for every eigenvalue, independent of
# discretization and of the special sine basis used for numerical checks.
u,p,v,q,w,J,t,lam,mu=s.symbols('u p v q w J t lam mu')
xs=[u,p,v,q,w,J]
dx=[p,-lam*u,q,-mu*v,t*u*u,u*v]
def D(f):return sum(s.diff(f,x)*d for x,d in zip(xs,dx))
potential=-2*(2*t*u*p*w-t*t*u**4)/w**2
f=v-t*u*J/w
res=s.factor(-D(D(f))+potential*f-mu*f)
assert s.factor(res.subs(J,(p*v-u*q)/(mu-lam)))==0
ground=u/w
assert s.factor(-D(D(ground))+potential*ground-lam*ground)==0

# Normalization and overlap have exact elementary integrals in z=I(x).
z,tt=s.symbols('z tt',real=True,positive=True)
norm=s.integrate((1+tt)/(1+tt*z)**2,(z,0,1))
assert s.simplify(norm-1)==0
amp=s.integrate(s.sqrt(1+tt)/(1+tt*z),(z,0,1))
assert s.simplify(amp-s.sqrt(1+tt)*s.log(1+tt)/tt)==0

def I(x):return (x-math.sin(2*x)/2)/math.pi
def U(x):return math.sqrt(2/math.pi)*math.sin(x)
def V(x,t):
    uu=U(x);up=math.sqrt(2/math.pi)*math.cos(x);ww=1+t*I(x)
    return -4*t*uu*up/ww+2*t*t*uu**4/ww**2
rows=[]
sigma=.65
cluster_norm=math.sqrt(quad(lambda xx:xx*xx*math.exp(-xx*xx/(sigma*sigma)),0,math.pi,epsabs=1e-13)[0])
def cluster(xx):return xx*math.exp(-xx*xx/(2*sigma*sigma))/cluster_norm
for tau in [-.9,-.5,0.,1.,10.,100.,10000.]:
    def transformed(x):return math.sqrt(1+tau)*U(x)/(1+tau*I(x))
    norm_numeric=quad(lambda xx:transformed(xx)**2,0,math.pi,epsabs=1e-11,epsrel=1e-11)[0]
    overlap=quad(lambda xx:U(xx)*transformed(xx),0,math.pi,epsabs=1e-11,epsrel=1e-11)[0]**2
    closed=1. if tau==0 else (1+tau)*(math.log1p(tau)/tau)**2
    gaussian_overlap=quad(lambda xx:cluster(xx)*transformed(xx),0,math.pi,epsabs=1e-11,epsrel=1e-11)[0]**2
    assert abs(norm_numeric-1)<1e-9
    assert abs(overlap-closed)<1e-10
    assert transformed(.2)>0 and transformed(2.9)>0
    rows.append({'deformation_t':tau,'exact_overlap_squared':closed,'quadrature_overlap_squared':overlap,'quadrature_norm':norm_numeric,
                 'fixed_gaussian_radial_trial_sigma':sigma,'fixed_gaussian_overlap_squared':gaussian_overlap})

# Independently solve the local deformed differential operators on two meshes.
spectra=[]
for tau in [-.5,1.,10.]:
    errors=[]
    for cells in [800,1600]:
        h=math.pi/cells;x=np.arange(1,cells)*h
        pot=np.array([V(xx,tau) for xx in x])
        vals=eigh_tridiagonal(2/h**2+pot,np.full(cells-2,-1/h**2),select='i',select_range=(0,4),eigvals_only=True)
        err=float(max(abs(vals-np.arange(1,6)**2)))
        errors.append(err)
        spectra.append({'deformation_t':tau,'cells':cells,'first_five_eigenvalues':vals.tolist(),'max_error_to_n_squared':err})
    assert errors[1]<errors[0]/3.8 and errors[1]<.001

print(json.dumps({'branches':['N03','N04','N07','N08','N09'],
 'theorem':'The complete Dirichlet eigenvalue list and radial node labels do not determine an overlap with a fixed normalized trial state, even within smooth local one-dimensional potentials.',
 'construction':{'domain':'0<x<pi with Dirichlet endpoints; hbar^2/(2mu)=1',
   'base':'V=0, eigenvalues n^2, normalized u=sqrt(2/pi) sin x',
   'I':'I(x)=integral_0^x u^2=(x-sin(2x)/2)/pi',
   'deformation':'V_t=-2 d_x^2 log(1+t I), t>-1',
   'ground':'u_t=sqrt(1+t) u/(1+t I)',
   'other_eigenfunctions':'v_t=v-t*u/(1+t I)*integral_0^x u v for each other base eigenfunction v',
   'exact_overlap':'P(t)=(1+t)*(log(1+t)/t)^2, P(0)=1; P(t) tends to 0 as t tends to infinity.',
   'any_fixed_trial':'For every fixed normalized alpha in L2(0,pi), <alpha,u_t> tends to 0 as t tends to infinity. I_t(delta) tends to 1 for every delta>0, so the normalized mass concentrates at the endpoint; split the scalar product at delta and use Cauchy-Schwarz and absolute continuity of the alpha L2 integral.',
   'inverse':'The normalized transformed cumulative norm is I_t=(1+t)I/(1+t I). Parameter -t/(1+t) reverses the deformation. The Volterra transformation is invertible; all Dirichlet eigenvalues are preserved and no extra spectrum is introduced.'},
 'verification_routes':{'symbolic':'Exact differential intertwining residual vanishes using u_second=-lambda*u, v_second=-mu*v and (u_prime*v-u*v_prime)=(mu-lambda)*integral u v. Ground residual checked separately. Normalization and overlap integrated symbolically.',
 'independent':'Direct quadrature checks the overlaps, while symmetric tridiagonal eigensolvers converge at second order to n^2 on two meshes for three deformations.'},
 'overlaps':rows,'independent_discrete_spectra':spectra,
 'scope':'This is a local smooth confined-potential counterfamily for the geometric standing-wave overlap proxy, not a claim that all outgoing scattering poles or nuclear observables remain fixed. The zero-node ground state stays zero-node. On rescaling x=pi*r/R it applies to any fixed confinement radius R. It strengthens the need for eigenfunction/norming or microscopic input and does not replace prospective branch-aware validation.'},indent=2))
