from pathlib import Path
import hashlib,json,os,subprocess
BASE=Path(__file__).absolute().parent;RESEARCH=BASE.parent;project=RESEARCH/'lean-audit/withMathlib';binary=RESEARCH/'runtime/lean-4.34.0-rc2-darwin_aarch64/bin'
module=project/'.lake/packages/mathlib/Mathlib/Topology/MetricSpace/Contracting.lean';manifest=project/'lake-manifest.json';before=manifest.read_bytes()
command=[str(binary/'lake'),'exe','cache','get','Mathlib.Topology.MetricSpace.Contracting']
p=subprocess.run(command,cwd=project,capture_output=True,text=True,env={**os.environ,'PATH':str(binary)+os.pathsep+os.environ.get('PATH','')},timeout=600)
assert manifest.read_bytes()==before
artifact=project/'.lake/packages/mathlib/.lake/build/lib/lean/Mathlib/Topology/MetricSpace/Contracting.olean'
out={'status':'passed' if p.returncode==0 and artifact.exists() else 'failed','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'lake_manifest_sha256':hashlib.sha256(before).hexdigest(),'module_source_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),'module_olean_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest() if artifact.exists() else None,'scope':'Acquire the missing compiled Banach fixed-point module and its dependencies from the pinned mathlib cache; no toolchain, package manifest or theorem source change.'}
(BASE/'Runtime_Acquisition.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['status']=='passed' else 1)
