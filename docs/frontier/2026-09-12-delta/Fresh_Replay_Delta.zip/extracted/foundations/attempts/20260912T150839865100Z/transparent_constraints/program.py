"""A minimal *reference instrument*, not the unavailable AISO implementation.

The ACS glossary expands CDCL as Constraint-Driven Consensus Layer. This file
tests a deliberately narrower exact Boolean proof sublanguage inside a scoped,
append-only provenance ledger. It makes no SAT/performance claim about AISO.
"""
import copy, hashlib, itertools, json, os, random
from pathlib import Path


def reject_floats(x):
    if isinstance(x,float):raise ValueError('floating-point value violates exact-json-v1')
    if isinstance(x,dict):
        if any(not isinstance(k,str) for k in x):raise ValueError('non-string key')
        for v in x.values():reject_floats(v)
    elif isinstance(x,list):
        for v in x:reject_floats(v)
    elif x is not None and type(x) not in (str,int,bool):raise ValueError('noncanonical type')


def digest(body):
    reject_floats(body)
    return hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()


def clause(c):
    if any(type(x)!=int or x==0 for x in c):raise ValueError('invalid literal')
    if c!=sorted(set(c)):raise ValueError('clause must be sorted and duplicate-free')
    if any(-x in c for x in c):raise ValueError('tautological clause excluded by this instrument')
    return frozenset(c)


def resolve(a,b,pivot):
    if type(pivot)!=int or pivot==0:raise ValueError('invalid pivot')
    if pivot not in a or -pivot not in b:raise ValueError('pivot missing')
    c=(a-{pivot}) | (b-{-pivot})
    if any(-x in c for x in c):raise ValueError('tautological resolvent excluded')
    return c


class Ledger:
    """Primary path: resolution plus propagated root-support sets."""
    def __init__(self,scope='fixture-v1'):
        self.scope=scope;self.events=[];self.claims={};self.support={};self.active=set()

    def append(self,payload):
        body={'seq':len(self.events),'prev':self.events[-1]['hash'] if self.events else '0'*64,
              'scope':self.scope,'arithmetic':'exact-json-v1',**payload}
        event={'body':body,'hash':digest(body)}
        self.accept(event);return body.get('id')

    def accept(self,event):
        b=event['body'];kind=b['kind']
        if event['hash']!=digest(b):raise ValueError('content digest mismatch')
        if b['scope']!=self.scope:raise ValueError('scope mismatch')
        if b['arithmetic']!='exact-json-v1':raise ValueError('arithmetic mismatch')
        if b['seq']!=len(self.events):raise ValueError('sequence mismatch')
        if b['prev']!=(self.events[-1]['hash'] if self.events else '0'*64):raise ValueError('history mismatch')
        if kind in ('assert','resolve'):
            name=b['id']
            if name in self.claims:raise ValueError('claim identifiers immutable')
            c=clause(b['clause'])
            if b['grade']!='exact_boolean':raise ValueError('unsupported proof grade')
            if kind=='assert':
                if b['origin']!='declared_fixture_premise':raise ValueError('unspecified premise origin')
                support={name}
            else:
                if len(b['parents'])!=2:raise ValueError('two parents required')
                p,q=b['parents']
                if p not in self.claims or q not in self.claims:raise ValueError('forward/missing premise')
                if not self.live(p) or not self.live(q):raise ValueError('retired premise dependency')
                if resolve(self.claims[p],self.claims[q],b['pivot'])!=c:raise ValueError('incorrect resolvent')
                support=self.support[p]|self.support[q]
            self.claims[name]=c;self.support[name]=support
            if kind=='assert':self.active.add(name)
        elif kind=='retire':
            if b['id'] not in self.active:raise ValueError('not an active premise')
            self.active.remove(b['id'])
        else:raise ValueError('unsupported event kind')
        self.events.append(copy.deepcopy(event))

    def live(self,name):return self.support[name]<=self.active


def independent_oracle(events,nvars):
    """Independent path: recursion on proof ancestry + full truth assignments.

    It never calls resolve(), digest(), Ledger.live(), or the support propagator.
    Digest spec is independently encoded; logical entailment is evaluated by
    assignments, with no resolution rule involved.
    """
    roots={};retired=set();nodes={};checks=0;state=[];previous='0'*64
    for seq,event in enumerate(events):
        b=event['body']
        raw=json.dumps(b,ensure_ascii=True,separators=(',',':'),sort_keys=True).encode('utf-8')
        assert hashlib.sha256(raw).hexdigest()==event['hash']
        assert b['seq']==seq and b['prev']==previous
        previous=event['hash']
        if b['kind']=='assert':roots[b['id']]=b['clause'];nodes[b['id']]=b
        elif b['kind']=='resolve':nodes[b['id']]=b
        else:retired.add(b['id'])

        def live(name,seen=frozenset()):
            assert name not in seen
            r=nodes[name]
            if r['kind']=='assert':return name not in retired
            return all(live(p,seen|{name}) for p in r['parents'])

        def satisfies(c,bits):return any(bits[abs(lit)-1]==(lit>0) for lit in c)
        models=[bits for bits in itertools.product((False,True),repeat=nvars)
                if all(satisfies(c,bits) for key,c in roots.items() if key not in retired)]
        current={name:live(name) for name in nodes}
        for name,is_live in current.items():
            if is_live:
                assert all(satisfies(nodes[name]['clause'],bits) for bits in models)
                checks+=len(models)
        state.append({'seq':seq,'live':current,'models':len(models)})
    return {'states':state,'truth_assignment_entailment_checks':checks,'terminal_chain':previous}


def premise(name,c):return {'kind':'assert','id':name,'clause':sorted(c),'origin':'declared_fixture_premise','grade':'exact_boolean'}
def learned(name,c,parents,p):return {'kind':'resolve','id':name,'clause':sorted(c),'parents':parents,'pivot':p,'grade':'exact_boolean'}


L=Ledger()
L.append(premise('a',[1,2]));L.append(premise('b',[-1,3]));L.append(premise('c',[-2]));L.append(premise('d',[-3]))
L.append(learned('u',[2,3],['a','b'],1));L.append(learned('v',[3],['u','c'],2));L.append(learned('empty',[],['v','d'],3))
L.append({'kind':'retire','id':'b','reason':'original premise withdrawn; retain proof history'})
assert not L.live('u') and not L.live('v') and not L.live('empty')
# An independent valid derivation of the same clause remains available.
L.append(premise('e',[3]));L.append(learned('empty2',[],['e','d'],3))
L.append({'kind':'retire','id':'d','reason':'new fixture context'})
assert not L.live('empty2')
oracle=independent_oracle(L.events,3)
assert oracle['states'][-1]['live']=={n:L.live(n) for n in L.claims}
# Compare every prefix, including before and after retraction.
for k,expected in enumerate(oracle['states'],1):
    replay=Ledger()
    for event in L.events[:k]:replay.accept(event)
    assert expected['live']=={n:replay.live(n) for n in replay.claims}

# Exact exhaustion: all tautology-free clauses on three Boolean variables.
clauses=[]
for choices in itertools.product((-1,0,1),repeat=3):
    clauses.append(frozenset((i+1)*v for i,v in enumerate(choices) if v))
checked=0
for a,b in itertools.product(clauses,repeat=2):
 for pivot in a:
    if -pivot not in b:continue
    try:r=resolve(a,b,pivot)
    except ValueError:continue
    for bits in itertools.product((False,True),repeat=3):
        sat=lambda c:any(bits[abs(l)-1]==(l>0) for l in c)
        assert not (sat(a) and sat(b)) or sat(r)
    checked+=1

# Adversarial event mutation must fail even when the attacker recomputes a hash.
mutations=[]
def attempt(label,prefix,event,recompute=True):
    item=copy.deepcopy(event)
    if recompute:
        try:item['hash']=digest(item['body'])
        except ValueError as ex:
            mutations.append({'case':label,'rejected':True,'reason':str(ex)});return
    r=Ledger()
    for old in prefix:r.accept(old)
    try:r.accept(item)
    except ValueError as ex:mutations.append({'case':label,'rejected':True,'reason':str(ex)})
    else:raise AssertionError('mutation accepted: '+label)

event=copy.deepcopy(L.events[4]);event['body']['clause']=[2];attempt('wrong resolvent with recomputed digest',L.events[:4],event)
event=copy.deepcopy(L.events[4]);event['body']['parents']=['v','b'];attempt('forward dependency',L.events[:4],event)
event=copy.deepcopy(L.events[4]);event['body']['scope']='another-theory';attempt('cross-scope promotion',L.events[:4],event)
event=copy.deepcopy(L.events[4]);event['body']['clause']=[2];attempt('byte/content tamper',L.events[:4],event,False)
event=copy.deepcopy(L.events[4]);event['body']['arithmetic']='binary64';attempt('arithmetic mismatch',L.events[:4],event)
event=copy.deepcopy(L.events[4]);event['body']['grade']='empirical_consensus';attempt('unsupported evidence grade',L.events[:4],event)
event=copy.deepcopy(L.events[4]);event['body']['pivot']=1.0;attempt('float literal',L.events[:4],event)
event={'body':{'seq':8,'prev':L.events[7]['hash'],'scope':L.scope,'arithmetic':'exact-json-v1',**learned('bad',[2,3],['a','b'],1)}}
attempt('reuse retired root',L.events[:8],event)

# Replay speed is only reproducibility, never a performance result for AISO.
encoded='\n'.join(json.dumps(e,sort_keys=True) for e in L.events)+'\n'
roundtrip=[json.loads(x) for x in encoded.splitlines()]
fresh=Ledger()
for event in roundtrip:fresh.accept(event)
assert fresh.events==L.events
output=Path(os.environ.get('ACS_FOUNDATIONS_OUTPUT','.'))
output.mkdir(parents=True,exist_ok=True)
(output/'transparent_constraints_trace.jsonl').write_text(encoded)
(output/'transparent_constraints_prefix_oracle.json').write_text(json.dumps(oracle,indent=2))
print(json.dumps({'scope':'Minimal exact Boolean provenance instrument; NOT an AISO audit and NOT a claim that ACS CDCL is a SAT solver.',
 'contract':{'identity':'sha256 over canonical sorted exact JSON, sequence and previous digest included; hashes provide integrity only, not proof truth or author identity',
 'logical_grade':'exact_boolean; origin premises explicitly declared; empirical/consensus records cannot silently become proofs',
 'learning':'Exact two-parent resolution on earlier active same-scope nodes',
 'retraction':'Append retirement; retain original clause and proof. A proof is usable only while every leaf premise remains active.',
 'alternative_proofs':'Distinct proof nodes can conclude the same clause; each keeps its own support. One retired proof does not erase another live derivation.',
 'arithmetic':'integers and exact literal sets; floats excluded, not merely rounded',
 'necessary_bridge_to_ACS':'Define a semantic predicate for each production constraint, a sound inference rule for its evidence type, and the versioned replay/arithmetic contract. Then compare actual AISO events to this contract or a declared alternative.'},
 'routes':['Proof-local resolution and propagated support invariant','Independent complete truth-assignment enumeration plus recursive ancestor liveness at every ledger prefix'],
 'proof_of_general_soundness':'Induct on the append order: base clauses are assumptions; if both parent clauses hold, their resolvent holds by the pivot truth cases. Parent support union is sufficient. Retiring a root makes every dependent proof unusable; remaining proofs are still consequences of current roots.',
 'events':len(L.events),'retained_proof_nodes':len(L.claims),'truth_assignment_checks':oracle['truth_assignment_entailment_checks'],
 'all_three_variable_clauses':len(clauses),'exhaustive_resolution_instances':checked,'mutations':mutations,
 'terminal_chain_sha256':L.events[-1]['hash'],'replay_identical':True},indent=2))
