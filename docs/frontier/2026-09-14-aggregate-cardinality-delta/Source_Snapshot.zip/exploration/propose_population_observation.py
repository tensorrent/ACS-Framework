"""Propose actual-field common observations with one missing root; pending independent audit."""
import hashlib,json,zipfile
from fractions import Fraction as F
from pathlib import Path
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo'
ARCHIVE=ROOT/'docs/frontier/2026-09-13-aggregate-delta/Aggregate_Inputs.zip'
CLASS=ROOT/'docs/frontier/2026-09-14-aggregate-classification-delta/Full_Quartic_Class.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def intervals(data):
    result=[(F(r['lo']),F(r['hi'])) for r in data['positive_root_intervals']]
    assert all(0<lo<hi<20 for lo,hi in result)
    assert all(a[1]<b[0] for a,b in zip(result,result[1:]))
    return result
def proposed_match(a,b):
    assert len(a)==len(b)+1
    rows=[]
    for omit in range(len(a)):
        retained=[r for i,r in enumerate(a) if i!=omit];pairs=[]
        for ar,br in zip(retained,b):
            alo,ahi=ar;blo,bhi=br
            lo=min(alo,blo);hi=max(ahi,bhi);center=(lo+hi)/2
            lower=max(F(0),alo-bhi,blo-ahi)/2;upper=(hi-lo)/2
            assert all(abs(center-x)<=upper for x in [alo,ahi,blo,bhi])
            pairs.append({'a_interval':list(map(str,ar)),'b_interval':list(map(str,br)),
                          'common_ordinate':str(center),'radius_lower':str(lower),'radius_upper':str(upper)})
        lower=max(F(p['radius_lower']) for p in pairs);upper=max(F(p['radius_upper']) for p in pairs)
        centers=[F(p['common_ordinate']) for p in pairs]
        assert all(0<c<20 for c in centers) and all(x<y for x,y in zip(centers,centers[1:]))
        rows.append({'omitted_A_index_zero_based':omit,'radius_lower':str(lower),'radius_upper':str(upper),'pairs':pairs})
    best=min(rows,key=lambda r:(F(r['radius_upper']),r['omitted_A_index_zero_based']))
    return {'source_population_sizes':[len(a),len(b)],'all_single_deletion_cases':rows,
            'optimal_radius_lower':str(min(F(r['radius_lower']) for r in rows)),
            'constructive_radius_upper':best['radius_upper'],'best_omitted_A_index_zero_based':best['omitted_A_index_zero_based'],
            'common_observation':[p['common_ordinate'] for p in best['pairs']]}
def main():
    classified=json.loads(CLASS.read_text());assert classified['complete_quartic_candidate_count']==2 and classified['Galois_group_derived']=='V4'
    results=[]
    with zipfile.ZipFile(ARCHIVE) as z:
        for bits in [160,224]:
            data=[json.loads(z.read('S'+str(i)+'_'+str(bits)+'.json')) for i in [1,2]]
            assert all({k:d[k] for k in classified['metadata']}==classified['metadata'] for d in data)
            rows=[intervals(d) for d in data];r=proposed_match(*rows);r['precision_bits']=bits
            r['input_member_sha256']={n:hashlib.sha256(z.read(n)).hexdigest() for n in ['S1_'+str(bits)+'.json','S2_'+str(bits)+'.json']}
            results.append(r)
    out={'status':'proposal_pending_independent_audit','source_sha256':sha(Path(__file__)),
         'inputs_sha256':{str(p.relative_to(ROOT)):sha(p) for p in [ARCHIVE,CLASS]},
         'unchanged_population_observation_lengths':[23,22],
         'missing_root_contract':'Each source may lose at most one member of its complete positive-root population through 20. Retained roots receive independent absolute ordinate errors bounded by a common radius. No insertions are allowed. A common list must have22members, so A loses exactlyone and B losesnone.',
         'proof_obligations':['Derive the population-only classifier from metadata and certified counts without reading ordinates.','Prove unchanged population length invariance for the permitted observation maps.','Prove sorted matching is optimal for the one-dimensional maximum distance under a single deletion.','Independently replay all rational lower/upper bounds and every common observation against both certified root populations.'],
         'cases':results,
         'scope':'Exploratory exact interval proposal for a different missing-root model, not a published or independently verified result. The lower bound requires the ordered-matching argument; the explicit upper witness checks all source interval endpoints. The scalar classification from fixed population concerns a different error contract.'}
    (BASE/'Population_Observation_Proposal.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'cases':[{'precision_bits':r['precision_bits'],'omitted_index':r['best_omitted_A_index_zero_based'],'lower_decimal':str(float(F(r['optimal_radius_lower']))),'upper_decimal':str(float(F(r['constructive_radius_upper']))),'common_population':len(r['common_observation'])} for r in results]},indent=2))
if __name__=='__main__':main()
