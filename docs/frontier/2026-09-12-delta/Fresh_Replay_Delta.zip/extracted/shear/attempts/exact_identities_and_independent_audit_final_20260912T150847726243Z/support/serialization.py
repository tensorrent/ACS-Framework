"""Outward decimal serialization retaining full midpoint AND radius precision."""
def ball_string(x,digits=60):
    m,r,e=x.mid_rad_10exp(digits)
    return f'[{m}e{e} +/- {r}e{e}]'
