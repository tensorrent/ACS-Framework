from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-local-noise-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-quadratic-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,entry in entries:z.write(path,entry)

names=['Wide_Ranges160.json','Wide_Ranges224.json','Local_Noise160.json','Local_Noise224.json']
archive('Noise_Producers.zip',[(BASE/n,n) for n in names])
for name in ['Wide_Audit.json','Local_Audit.json','Local_Adversary.json']:(OUT/name).write_bytes((BASE/name).read_bytes())
wide=read(BASE/'Wide_Audit.json');audit=read(BASE/'Local_Audit.json');result=read(BASE/'Local_Noise160.json')
assert wide['status']==audit['status']==result['status']=='passed'
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==9 and sum(r['returncode']==0 for r in receipts.values())==7
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']]
        +[(BASE/'Arithmetic_Interruption.json','Arithmetic_Interruption.json')])
cases={(c['label'],c['delta'],c['top'],c['profile']):c for c in result['cases']}
profiles=['degree','degree_discriminant','galois','galois_discriminant']
qcase=cases['quadratic','5e-3',2000,'degree'];assert qcase['unique_target_coefficients']==91
local_models=cases['quadratic','5e-3',2000,'degree_discriminant']['local_models']
target_models=[m for m in local_models if m['prime']<=361];unresolved=[m for m in target_models if len(m['retained_model_ids'])>1]
assert len(target_models)==72 and len(unresolved)==48
comparisons=[{'label':c['label'],'radius':c['delta'],'height':c['top'],'profile':c['profile'],
 'seed':c['seed_unique_targets'],'local_only':c['local_only_unique_targets'],'after_spectral_feedback':c['unique_target_coefficients'],
 'unique_target_prime_local_models':c['unique_target_prime_local_models']} for c in result['cases']]
write('Local_Noise_Summary.json',{'recorded_utc':now,'assumption_profiles':result['assumption_profiles'],'target_count':91,'coefficient_support':604,
 'quadratic_seed_unique_targets':83,'quadratic_seed_degree_only_unique_targets':91,
 'quadratic_seed_degree_only_minimum_observations':qcase['minimal_quadratic_seed_observations'],
 'original_target_primes':72,'original_unresolved_local_factors':len(unresolved),'unresolved_local_models_with_discriminant':unresolved,
 'larger_radius_galois_discriminant_counts':{d:cases['wide_stationary',d,2000,'galois_discriminant']['unique_target_coefficients'] for d in ['1e-2','2e-2','3e-2']},
 'all_case_comparisons':comparisons,
 'remaining_wider_targets':[{'radius':d,'profile':p,'domains':[x for x in cases['wide_stationary',d,2000,p]['domains'] if x['n']<=361 and len(x['candidates'])>1]}
     for d in ['1e-2','2e-2','3e-2'] for p in profiles],
 'wide_exclusion_replays':10592,'strict_phase_brackets':560440,'independent_extrema_sums':12,
 'local_exclusion_replays':133128,'spectral_feedback_exclusion_replays':598,'minimum_observation_certificates':64,
 'largest_exact_common_denominator_bits':audit['largest_exact_common_denominator_bits'],
 'scope':'Assumptions are explicit and each profile starts independently from its declared domains. All 91 coefficients at radius 0.005 follow from the quadratic seed and general degree-four local relations. The radius 0.01 result adds Galois structure and local use of the discriminant. Neither result determines the original 48 ambiguous local factors or proves surviving domains jointly feasible.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':9,'successful_commands':7,'failed_commands':1,'deliberately_interrupted_commands':1,
 'failed_attempt':{'run':'local-independent-audit','result':'An exact dyadic gap expressed as a Fraction exceeded Python\'s 4300-digit integer-printing limit. The failed source and traceback are retained.'},
 'interrupted_attempt':{'run':'local-independent-audit2','result':'After replacing the diagnostic with a compact lower bound, full Fraction normalization remained costly. The observed child process was deliberately stopped by SIGTERM after 453.535648 seconds. The runner retained returncode -15 and both streams.'},
 'successful_replacement':'The final audit aligns each dyadic mantissa at the least exponent and sums shifted signed integers. This is the full exact sum with no dropped or rounded terms. All 598 spectral gaps exceed their positive fixed-grid lower bounds. The largest common denominator is 2^422955.',
 'independence':'The profile audit uses ordered compositions and separate Galois integer triples, symbolic rational identities, exact dyadic spectral sums and held-out arithmetic. The wider-range audit checks phase brackets and independent 80-digit extrema. The elementary non-Galois certificate avoids symbolic factorization. Analytic row reconstruction still shares the pinned loader.',
 'premise_boundary':'The four assumption profiles separate degree, ramification labels from the discriminant, and Galois structure. The discriminant remains an analytic invariant in all explicit-formula rows. No Galois property or prime residue-class splitting pattern is inferred from the spectrum.',
 'fixed_point_scope':'Local/spectral iteration reaches a finite exclusion fixed point. It does not establish joint feasibility, actual-field realization or optimal uncertainty tolerance.',
 'history_policy':'All earlier dated packages and pinned instruments remain byte-identical. All 116 branches persist; no global completion or exhaustion is asserted.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now
runtime['requirements']='code/frontier_verification/source_requirements.txt'
runtime['scope']='No new runtime packages. This pass uses the existing analytic and symbolic stack and exact Python integer arithmetic. No optimizer or new Lean compilation runs in this checkpoint.';write('Runtime.json',runtime)
sources=read(PRIOR/'Primary_Sources.json');sources['recorded_utc']=now
for item in sources['sources']:
    if item['url']=='https://www.jmilne.org/math/CourseNotes/ANT.pdf':
        item['locator']='Theorems 3.34-3.35 (printed pages 59-60); Theorem 3.41 and Remark 3.43 (printed pages 62-63)'
        item['use']='General degree sum, equal e/f for Galois extensions, ramification/discriminant criterion, and polynomial factorization away from the order index. New arithmetic premise comparisons and the non-Galois counterexample use these statements.'
sources['scope']='Inherited analytic sources and the explicit local arithmetic premises. Catalogue completeness, Euler rational identities, exact dyadic support and minimum-observation arguments are derived in LOCAL_NOISE_README.md.';write('Primary_Sources.json',sources)
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Local information and wider uncertainty delta 2026-09-13','recorded_utc':now,
 'parent_checkpoint':str((PRIOR/'Research_Queue.json').relative_to(ROOT)),
 'baseline_branches':116,'branches_total':116,'new_branches':[],'advanced_existing_branches':['R12','R13','R14','K04'],
 'replay_scope':'Three wider radii at two precisions, four explicit local-assumption profiles across 22 starting cases, exact local/spectral exclusions, minimum-observation hitting sets, independent extrema and elementary non-Galois counterexample.',
 'next_priority':['R12/R13: choose noise-aware measurements or linked nonlinear error/tail bounds for the nine surviving targets at radius 0.02',
 'R13/R14: distinguish exclusion survivors from independently certified feasible models, retaining every nuisance coefficient and inherited bound',
 'R14/P05: acquire or derive the missing square-power observations for the original 48 local factors; distinguish residue degrees from ramification',
 'R13/R07: independent statistical calibration and identification of which arithmetic premises can be obtained from spectral information',
 'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates',
 'K02/K05: private corpus and historical-run identities']})
updates={
 'R12':('wider_uncertainty_ranges_replayed_with_exact_phase_and_extrema_checks',
  'At added radii 0.01,0.02,0.03, retained stationary measurements identify 38,17,10 targets before local assumptions. The 160/224-bit runs agree on all 30 cases; 10592 exclusions, 560440 strict phase brackets and twelve independent 80-digit extrema sums are checked.',
  'Select measurements for the declared uncertainty and strengthen common nonlinear errors or tails. The tested sufficient bounds and fixed membership do not establish an optimal noise threshold.'),
 'R13':('all_targets_at_radius_001_with_explicit_local_premises',
  'General degree-four local relations resolve the eight quadratic-seed gaps at radius 0.005 without local discriminant labels or a Galois premise. At radius 0.01, the Galois-plus-discriminant model reaches all 91 targets through retained height 1000. At 0.02 and 0.03 it retains 82 and 62 targets. Every profile and local-only/feedback contribution is explicit.',
  'Test the nine wider-radius survivors with stronger measurements or exact feasible/separating witnesses, while keeping the added Galois and ramification premises explicit and separate from spectral inference.'),
 'R14':('local_premise_catalogues_minimal_observations_and_non_galois_control',
  'Eleven general local profiles and Galois triples are independently enumerated. Exact Euler identities and 64 minimum-observation certificates explain the eight earlier gaps. A quartic of discriminant -283 with residue degrees 1 and 3 at seven rejects unsupported Galois filtering, with a separate elementary certificate. All 91 target coefficients still leave 48 of the original 72 local factors ambiguous.',
  'Obtain the missing square-power observations and examine whether further global/local information follows from the allowed inputs. Local catalogue survivors need not be jointly realizable by a field.'),
 'K04':('ongoing_delta_with_local_assumptions_and_preserved_arithmetic_attempts',
  'Preserve all 116 branches and the 369-event prefix, adding four events to reach 373. Nine command receipts retain seven successes, one printing failure and one deliberate arithmetic interruption. Exact shifted-integer sums finish 133128 local and 598 spectral exclusion replays at two precisions without discarding terms.',
  'Continue evidence-backed deltas and independent challenges across the full queue without global completion or exhaustion.')}
evidence={'R12':['Noise_Producers.zip','Wide_Audit.json','Local_Noise_Summary.json'],
 'R13':['Noise_Producers.zip','Local_Audit.json','Local_Noise_Summary.json'],
 'R14':['Local_Audit.json','Local_Adversary.json','Local_Noise_Summary.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-local-noise-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result_text,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result_text,continuation_condition=gate,assessment_this_pass='fresh_local_information_and_wider_uncertainty_audit')
        b['new_evidence']=[prefix+n for n in evidence[b['id']]]
        b['verification_routes']+=['Independent local profile catalogues and symbolic Euler identities','Exact dyadic spectral gaps and model-exclusion witnesses',
            'Two-precision wider-range and local-domain comparisons','Minimum-observation hitting sets and elementary non-Galois counterexample']
        if b['id'] in ['R12','R13','R14']:
            b['shared_assumptions_and_scope']='Inherited field invariants, finite root certificates, explicit formula, unconditional tails and certified domains. Degree, local discriminant labels and Galois structure are compared explicitly. No prime residue-class oracle enters inference; local and integer survivors are not feasibility or field-realization certificates.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=369
for bid in ['R12','R13','R14','K04']:
    b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
    event={'sequence':sequence,'utc':now,'release':q['release'],'kind':'local_information_and_noise_evidence_advanced','branch_id':bid,
        'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(event,sort_keys=True,separators=(',',':')).encode());event['event_sha256']=last;events+=(json.dumps(event,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dedekind_local_profiles.py','dedekind_local_noise.py','dedekind_local_noise_audit.py','dedekind_wide_audit.py',
 'dedekind_local_adversary.py','verify_local_noise_delta.py','LOCAL_NOISE_README.md']
deps=['dedekind_ordinate_ranges.py','dedekind_coupled_recovery.py','dedekind_coupled_audit.py','dedekind_recovery_audit.py',
 'dedekind_local_identifiability.py','verify_quadratic_delta.py','source_requirements.txt','QUADRATIC_README.md','ORDINATE_README.md','RECOVERY_README.md']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
 'scope':'New local-information and wider-grid audits. Earlier pinned sources remain unchanged; failed and interrupted audit variants are retained.'}
write('Source_Inventory.json',inventory)
entries=[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]
entries += [(p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',Path(__file__).absolute()]]
entries += [(p,str(p.relative_to(BASE))) for p in sorted((BASE/'source-versions').rglob('*')) if p.is_file()]
archive('Source_Snapshot.zip',entries)
files={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for name in new_names:
    path=CODE/name;raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,
 'scope':'Manifest and verification output excluded to avoid self-reference; preceding checkpoint checked recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':len(q['branches']),'events':sequence,
 'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
