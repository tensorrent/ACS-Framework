from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

BASE=Path(__file__).absolute().parent
WORK=BASE/'explicit-audit'
REPO=BASE.parent/'acs-repo'
OUT=REPO/'docs/frontier/2026-09-13-explicit-delta'
PRIOR=REPO/'docs/frontier/2026-09-13-dedekind-delta'
PREFIX=OUT.relative_to(REPO).as_posix()+'/'
NOW=datetime.now(timezone.utc).isoformat()
BASELINE='ff1559fdd7656f7c814970ddceb42d96888f0b2e'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,files):
 with zipfile.ZipFile(OUT/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for arc,p in files:z.write(p,arc)
 print(name,(OUT/name).stat().st_size,flush=True)

archive('Gaussian_Audits.zip',[(f'Gaussian_{bits}.json',WORK/f'Gaussian_{bits}.json') for bits in [160,224]])
for name in ['Cross_Method.json','Algebra_Audit.json']:(OUT/name).write_bytes((WORK/name).read_bytes())
(OUT/'Download_Receipts.json').write_bytes((WORK/'primary/Download_Receipts.json').read_bytes())
data=json.loads((WORK/'Gaussian_224.json').read_text())
summary=[]
for c in data['configurations']:
 summary.append({k:c[k] for k in ['a','frequency_label','frequency','pole','conductor']}|{
  'gamma':c['gamma']['enclosure'],'prime':c['prime_cutoffs']['100000']['enclosure'],
  'zero':c['zero_cutoffs']['220']['enclosure'],'residual':c['zero_cutoffs']['220']['residual'],
  'zero_tail':c['zero_cutoffs']['220']['tail_bound'],'prime_tail':c['prime_cutoffs']['100000']['tail_bound'],
  'gamma_lower_tail':c['gamma']['lower_tail_bound'],'gamma_upper_tail':c['gamma']['upper_tail_bound']})
dump('Gaussian_Summary.json',{'producer_224_sha256':sha((WORK/'Gaussian_224.json').read_bytes()),'configurations':summary,
 'moment_bounds':data['moment_bounds'],'scope':data['scope']})
receipts={d.name:json.loads((d/'receipt.json').read_text()) for d in sorted(WORK.iterdir()) if d.is_dir() and (d/'receipt.json').exists()}
assert len(receipts)==9 and sum(r['returncode']==0 for r in receipts.values())==5
files=[(n+'/'+f,WORK/n/f) for n in receipts for f in ['receipt.json','stdout.txt','stderr.txt']]
files += [('runner.py',WORK/'run_recorded.py'),('packaging/package_explicit_delta.py',Path(__file__).absolute())]
files += [('development/'+p.name,p) for p in sorted((WORK/'development').iterdir()) if p.is_file()]
archive('Execution_Artifacts.zip',files)
dump('Execution_Receipts.json',receipts)
dump('Development_Notes.json',{'retained_recorded_attempts':{
 'cross-method':'Rejected because the alternate digamma route initially omitted the -4 log(2 pi) g(0) gamma normalization. Primary producer unchanged.',
 'cross-method-corrected':'Gamma fixed; prime-value comparison failed because the independently computed value was rounded to 57 digits before checking a tightly printed interval.',
 'cross-method-diagnostic':'Same comparison failure retained with exact expected/actual diagnostic. Final check uses 60 digits and higher interval parsing precision; no producer interval was widened.',
 'cross-method-full-precision':'Dispatch error: the interpreter binary was accidentally supplied as the script. It failed before running mathematics.',
 'cross-method-final':'All 30 independent configurations and nine alternate gamma integrals passed; preliminary nine-mutation result retained before conservative altered-weight tail allowances were added.',
 'cross-method-tail-aware':'Final ten-mutation run with explicit tail allowances for altered zero weights passed.'},
 'development_probes':{'gaussian_probe.py':'Initial interactive probe produced a non-finite prime sum when generic real exponentiation squared a straddling interval.',
 'gaussian_probe_debug.py':'Localized the failure at n=11 when log(n)-u straddled zero.',
 'gaussian_probe_multiply.py':'Using multiplication for the square gave a finite prime sum and residual interval containing zero. The algebra audit records the runtime behavior as a reproducible control.'},
 'probe_receipt_scope':'The three development probe descriptions summarize observed interactive tool output; they are not represented as recorded-run receipts.',
 'development_files_sha256':{p.name:sha(p.read_bytes()) for p in sorted((WORK/'development').iterdir()) if p.is_file()}})

instruments=['code/frontier_verification/'+p for p in ['dedekind_explicit_formula.py','dedekind_explicit_crosscheck.py','dedekind_explicit_algebra.py','verify_explicit_delta.py','EXPLICIT_README.md']]
dependencies=['code/frontier_verification/'+p for p in ['dedekind_inputs.py','verify_dedekind_delta.py','source_requirements.txt']]
archive('Source_Snapshot.zip',[(kind+'/'+p,REPO/p) for kind,paths in [('instruments',instruments),('dependencies',dependencies)] for p in paths])
dump('Source_Inventory.json',{'baseline_commit':BASELINE,'instruments':{p:sha((REPO/p).read_bytes()) for p in instruments},
 'dependencies':{p:sha((REPO/p).read_bytes()) for p in dependencies},
 'scope':'New explicit-formula instruments; all prior dated evidence, pinned instruments and application data remain unchanged.'})
runtime=json.loads(subprocess.check_output([str(BASE/'.venv/bin/python'),'-c',
 'import sys,platform,json,flint,numpy,mpmath,sympy;print(json.dumps(dict(python=sys.version,platform=platform.platform(),python_flint=flint.__version__,flint=flint.__FLINT_VERSION__,numpy=numpy.__version__,mpmath=mpmath.__version__,sympy=sympy.__version__)))'],text=True))
dump('Runtime.json',runtime)
dump('Primary_Sources.json',{'retrieved_utc':NOW,'sources':[
 {'url':'https://arxiv.org/pdf/1305.0035','title':'Belabas and Friedman, Computing the residue of the Dedekind zeta function','location':'Section 2, equations (1)-(2), page 3','supports':'Weil-Poitou explicit identity and test-function admissibility, including potentially complex zero parameters. The separate residue-estimation theorem assumes GRH; it is not used here.'},
 {'url':'https://arxiv.org/pdf/1407.1375','title':'Grenie and Molteni, Zeros of Dedekind zeta functions under GRH','location':'Section 2, equations (2.1)-(2.7), page 4','supports':'Unconditional coefficient bound, functional equation and logarithmic-derivative/Hadamard identities. Its later GRH estimates inside the critical strip are not used.'},
 {'url':'https://dlmf.nist.gov/5.5#E5','title':'NIST DLMF gamma duplication','supports':'Completed-factor normalization and equivalent gamma derivatives.'},
 {'url':'https://dlmf.nist.gov/5.7#E6','title':'NIST DLMF digamma series','supports':'Positive series difference used to derive the alternate-integral tail bound.'},
 {'url':'https://python-flint.readthedocs.io/en/latest/acb.html#flint.acb.integral','title':'python-flint interval integration API','supports':'Analytic callback contract and interval quadrature semantics.'}]})
dump('Scope_Corrections.json',{'corrections':[
 {'claim':'Finite raw zero amplitudes directly equal local Euler coefficients.','result':'At a=1/400 and u=log2, the prime contribution is about 1.40e-36 but the zero sum is about -0.736822760644. Pole and gamma terms explain the difference. Smoothing leakage also separates the prime sum from an individual coefficient.'},
 {'claim':'Unknown-zero tails require assuming all unknown zeros are on the critical line.','result':'For these Gaussian tests, the positive moment at s=2 bounds unknown zeros using only 0<Re(rho)<1. This does not establish global GRH.'},
 {'claim':'Two higher-precision arithmetic runs remove uncertainty in inherited root brackets.','result':'Both runs reuse the same finite root intervals. Their uncertainty dominates the final residual width; new root refinement is required to reduce it.'},
 {'claim':'Fixed finite height supports the limit of arbitrarily narrow arithmetic smoothing.','result':'The bound requires a*(4+T^2)>=1 and explicit tail/precision control. A joint height-width-precision budget is a remaining gate.'},
 {'claim':'The alternate digamma integral needs no elementary gamma normalization.','result':'The -4 log(2 pi) g(0) term is necessary; the zero-frequency control rejected its initial omission.'}]})

queue=json.loads((PRIOR/'Research_Queue.json').read_text())
queue.update(release='Gaussian explicit-formula delta 2026-09-13',recorded_utc=NOW,
 parent_checkpoint=PRIOR.relative_to(REPO).as_posix()+'/Research_Queue.json',baseline_branches=115,branches_total=115,
 new_branches=[],advanced_existing_branches=['P05','R12','R13','K04'],metadata_corrected_branches=[],
 replay_scope='Thirty Gaussian explicit-formula cases at two interval precisions, separate zero/prime/gamma tails, all-case independent mpmath, nine alternate gamma integrals, exact algebra and ten deliberate variants. Prior certificates and mathematics are integrity checked, not rerun.',
 next_priority=['R13/P05: isolate individual arithmetic coefficients with certified smoothing leakage and joint height/width/root-precision budgets; separately declare statistical calibration',
 'R12/R11: refine certified roots and extend height only as required by explicit error budgets',
 'R04/R05/R06/R08/R10: natural-operator and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23: coupled Yukawa/scalar RG branches with mapped assumptions',
 'C05/C07: geometric orientation-cover and homology/isotopy bridge',
 'K02/K05: private corpus and historical run identities'])
for b in queue['branches']:
 b['assessment_this_pass']='carried_forward_not_newly_audited'
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b.get('new_evidence',[])
 b['new_evidence']=[]
ids={b['id']:b for b in queue['branches']}
updates={
 'P05':('gaussian_dedekind_explicit_formula_verified_with_all_terms',
 'Specialize the sourced Weil-Poitou formula to Q(zeta_5), verify discriminant and completed-factor normalization, and include the exact ramified and residue-degree prime coefficients. Thirty cases include pole, gamma, discriminant and prime terms with explicit error bounds.',
 'Recover individual coefficients with quantified Gaussian leakage and height/precision budgets. Other field extensions, natural operators and physical identifications require their own arguments.',
 ['Gaussian_Audits.zip','Algebra_Audit.json','Cross_Method.json','Primary_Sources.json']),
 'R12':('gaussian_observable_errors_and_unconditional_unknown_zero_tail_bounded',
 'The inherited 528 finite roots support thirty Gaussian tests with three zero cutoffs. A positive moment at s=2 bounds unknown zeros even off the critical line. Final zero tails are below 6.6e-49 while every residual enclosure lies within +/-7e-24; inherited root intervals dominate the error.',
 'Refine root intervals and extend certified heights according to frequency and smoothing requirements. Do not replace the finite brackets with point data or extrapolate fixed-height results to an unsmoothed limit.',
 ['Gaussian_Audits.zip','Gaussian_Summary.json','Cross_Method.json']),
 'R13':('finite_spectral_arithmetic_bridge_with_background_and_tail_control',
 'Both precision runs and independent numeric routes confirm the full Gaussian explicit formula for all thirty declared cases. At log2 the nonzero raw zero sum is explained by pole and gamma terms despite a tiny prime contribution. Ten deliberately incorrect variants are detected, with every case and inconclusive mutation comparison retained.',
 'Isolate local arithmetic coefficients with explicit smoothing-leakage bounds and joint a/T/root-precision control. Specify a separate statistical comparison; this deterministic identity does not restore historical ratios or establish a natural operator.',
 ['Gaussian_Audits.zip','Cross_Method.json','Gaussian_Summary.json','Scope_Corrections.json']),
 'K04':('ongoing_delta_with_explicit_formula_and_adversarial_evidence',
 'All 115 branches and the 346-event prefix remain. Four scoped advances extend the ledger to 350. Two-precision results, all-case independent values, alternate integrals, exact identities, failed attempts and development corrections are preserved.',
 'Continue append-only evidence-backed research and independent challenges with exact gates. No global completion or exhaustion claim.',
 ['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip'])}
for bid,(status,result,gate,evidence) in updates.items():
 ids[bid].update(current_status=status,assessment_this_pass='fresh_gaussian_explicit_formula_audit',latest_scoped_result=result,
  continuation_condition=gate,new_evidence=[PREFIX+p for p in evidence])
 ids[bid]['verification_routes']+=['Sourced explicit formula with derived unconditional moment and Gaussian tail bounds',
  'Two interval precisions and different gamma quadrature partitions','All-case independent mpmath and alternate digamma integrals',
  'Exact algebra and ten tail-aware deliberate variants']
ids['R13']['shared_assumptions_and_scope']='Gaussian test functions with specified Fourier convention, all four certified finite factors and bounded unknown tails. Analytic premises are sourced and derived in writing, not Lean formalized. Interval routes share FLINT; mpmath checks numeric values. Smoothing leakage, statistical calibration and operator identification remain distinct.'
dump('Research_Queue.json',queue)
prior=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(prior.splitlines()[-1]);appended=[]
for bid in ['P05','R12','R13','K04']:
 b=ids[bid]
 e={'branch_id':bid,'kind':'explicit_formula_evidence_advanced','result':b['latest_scoped_result'],'evidence':b['new_evidence'],
  'release':queue['release'],'sequence':last['sequence']+1,'previous_event_sha256':last['event_sha256'],'utc':NOW}
 e['event_sha256']=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());appended.append(json.dumps(e,sort_keys=True)+'\n');last=e
(OUT/'Branch_Events.jsonl').write_bytes(prior+''.join(appended).encode())
paths=[p for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['Manifest.json','Verification.json']]
paths+=[REPO/p for p in instruments+dependencies]
dump('Manifest.json',{'recorded_utc':NOW,'baseline_commit':BASELINE,'scope':'Immutable dated evidence and new instruments, plus pinned dependencies.',
 'files':{p.relative_to(REPO).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths}})
print(json.dumps({'branches':len(queue['branches']),'events':last['sequence'],'receipts':len(receipts),'manifest_files':len(paths)}),flush=True)
