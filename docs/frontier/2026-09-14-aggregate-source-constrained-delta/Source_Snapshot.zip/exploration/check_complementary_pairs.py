"""Unpublished interval and complex audits of mixed A/B corner-pair proposals."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES
from dedekind_augmented_feature_certificate_v2 import kernel
from dedekind_augmented_feature_audit import jets,modular_det
from dedekind_feature_certificate import coordinate_audit
from dedekind_weighted_region_certificate import av,enc
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    proposal=BASE/'Complementary_Pair_Proposals.json';p=json.loads(proposal.read_text());src=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text());c=list(map(F,next(x for x in src['matching_cases'] if x['precision_bits']==224)['common_observation']))
    r=F(p['root_coordinate_error_radius']);rho=F('1e-120');v=p['feature_direction'];results=[]
    for case in p['cases']:
        assert case['status']=='feasible_numerical_candidate';free=case['free_indices'];sides=case['free_coordinate_sides'];assert free==[i for i in range(22) if i!=1] and len(sides)==21 and set(sides)=={'A','B'}
        A=list(map(F,case['rational_A_coordinates']));B=list(map(F,case['rational_B_coordinates']));w=list(map(F,case['variable_center']));scale=F(case['tau_scale']);assert scale==F('1e-10') and len(w)==22
        fixedA=list(map(F,case['fixed_A_coordinates']));fixedB=list(map(F,case['fixed_B_coordinates']));eps=F(p['critical_epsilon']);assert A[1]==c[1]+eps and B[1]==c[1]-eps and eps==F('1e-8')+F('1e-24')
        freeA={i for i,side in zip(free,sides) if side=='A'};freeB=set(free)-freeA
        for k,(i,side) in enumerate(zip(free,sides)):
            assert (A if side=='A' else B)[i]==w[k] and (B if side=='A' else A)[i]==(fixedB if side=='A' else fixedA)[i]
        boxesA=[(x-rho,x+rho) if i in freeA else (x,x) for i,x in enumerate(A)]
        boxesB=[(x-rho,x+rho) if i in freeB else (x,x) for i,x in enumerate(B)]
        assert all(abs(x-z)<F(1,100) for boxes in [boxesA,boxesB] for box,z in zip(boxes,c) for x in box)
        assert all(x[1]<y[0] for boxes in [boxesA,boxesB] for x,y in zip(boxes,boxes[1:]))
        tau=(scale*(w[21]-rho),scale*(w[21]+rho));assert tau[0]>0
        R=[list(map(F,row)) for row in case['preconditioner']];mod=modular_det(R);checks=[]
        for bits in [768,1024]:
            ctx.prec=bits;RR=arb_mat([[av(x) for x in row] for row in R])
            J=arb_mat([[(1 if side=='A' else -1)*kernel(spec,av((A if side=='A' else B)[i])+arb(0,av(rho).upper()),True) for i,side in zip(free,sides)]+[-2*av(scale)*v[k]] for k,spec in enumerate(FEATURES)])
            E=arb_mat([[int(i==j) for j in range(22)] for i in range(22)])-RR*J
            f=arb_mat([[sum((kernel(spec,av(x)) for x in A),arb(0))-sum((kernel(spec,av(x)) for x in B),arb(0))-2*av(scale)*av(w[21])*v[k]] for k,spec in enumerate(FEATURES)]);rf=RR*f;rows=[]
            for i in range(22):
                q=sum((abs(E[i,j]) for j in range(22)),arb(0));budget=abs(rf[i,0])+av(rho)*q;assert q<1 and budget<av(rho)
                rows.append({'index':i,'defect_bound':enc(q),'preconditioned_residual':enc(rf[i,0]),'self_map_bound':enc(budget)})
            checks.append({'precision_bits':bits,'rows':rows})
        independent=[]
        for bits in [896,1152]:
            ctx.prec=bits;F0=[];J0=[];H=[]
            for k,spec in enumerate(FEATURES):
                F0.append(sum((jets(spec,av(x))[0] for x in A),arb(0))-sum((jets(spec,av(x))[0] for x in B),arb(0))-2*av(scale)*av(w[21])*v[k])
                J0.append([(1 if side=='A' else -1)*jets(spec,av((A if side=='A' else B)[i]))[1] for i,side in zip(free,sides)]+[-2*av(scale)*v[k]])
                H.append([abs(jets(spec,av((A if side=='A' else B)[i])+arb(0,av(rho).upper()))[2]) for i,side in zip(free,sides)]+[arb(0)])
            rows=[]
            for i in range(22):
                residual=sum((av(R[i][k])*F0[k] for k in range(22)),arb(0))
                center=sum((abs(arb(int(i==j))-sum((av(R[i][k])*J0[k][j] for k in range(22)),arb(0))) for j in range(22)),arb(0))
                variation=av(rho)*sum((abs(av(R[i][k]))*sum(H[k],arb(0)) for k in range(22)),arb(0));q=center+variation;budget=abs(residual)+av(rho)*q
                assert q<1 and budget<av(rho);rows.append({'index':i,'complex_residual':enc(residual),'center_defect':enc(center),'variation':enc(variation),'self_map_bound':enc(budget)})
            independent.append({'precision_bits':bits,'rows':rows})
        constraints=coordinate_audit({'radius':r,'boxes_A':boxesA,'boxes_B':boxesB},src,SOURCE/'Equal_Population_Inputs.zip');assert all(x['within_radius'] for x in constraints)
        results.append({'status':'mixed_system_interval_checks_passed_not_published','margin':case['margin'],'free_A_indices':sorted(freeA),'free_B_indices':sorted(freeB),
            'A_observation_boxes':[list(map(str,x)) for x in boxesA],'B_observation_boxes':[list(map(str,x)) for x in boxesB],'variable_radius':str(rho),'tau_interval':list(map(str,tau)),
            'tau_upper_display':float(tau[1]),'modular_preconditioner':mod,'real_checks':checks,'independent_complex_checks':independent,'source_coordinate_checks':constraints})
    return {'status':'exploratory_interval_checks_passed_not_published','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [proposal,SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_certificate_v2.py',CODE/'dedekind_augmented_feature_audit.py',CODE/'dedekind_feature_certificate.py',CODE/'dedekind_weighted_region_certificate.py']},'cases':results,
        'scope':'Two mixed-A/B variable-noise systems have self-mapping contraction checks at 768/1024 bits and independent complex checks at 896/1152 bits, with correction boxes inside the source-error and coordinate-region bounds. Both numerical routes share FLINT. Canonical audit, updated mixed-coordinate proof, adversaries and recursive provenance verification are still needed. No new published bound or sharpness claim; checkpoint 31 remains frozen.'}
r=run();(BASE/'Complementary_Pair_Checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'cases':[{'margin':x['margin'],'tau_upper_display':x['tau_upper_display']} for x in r['cases']]},indent=2))
