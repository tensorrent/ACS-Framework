from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).absolute().parent
name=sys.argv[1];cwd=Path(sys.argv[2]).absolute();command=sys.argv[3:]
out=root/name;out.mkdir(exist_ok=False)
start=datetime.now(timezone.utc)
proc=subprocess.run(command,cwd=cwd,text=True,capture_output=True,timeout=300,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider'})
(out/'stdout.txt').write_text(proc.stdout);(out/'stderr.txt').write_text(proc.stderr)
r={'started_utc':start.isoformat(),'elapsed_seconds':(datetime.now(timezone.utc)-start).total_seconds(),'cwd':str(cwd),'command':command,'returncode':proc.returncode,'stdout_sha256':hashlib.sha256(proc.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(proc.stderr.encode()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print(proc.stdout[-3000:]);print(proc.stderr[-1500:]);raise SystemExit(proc.returncode)
