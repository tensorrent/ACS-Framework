import PerZero
import PerZeroIntegral
import PerZeroError
import PerZeroSums
import PerZeroMean
import PerZeroCounterfamily
#print axioms PerZero.imag_cancels
#print axioms PerZero.real_doubles
#print axioms PerZero.contribution_lt_two_pi
#print axioms PerZero.contribution_tendsto
#print axioms PerZero.per_zero_two_pi
#print axioms PerZeroIntegral.real_integral
#print axioms PerZeroIntegral.translated_integral
#print axioms PerZeroIntegral.paired_identity
#print axioms PerZeroIntegral.complex_integral
#print axioms PerZeroError.kernel_continuous
#print axioms PerZeroError.arctan_upper
#print axioms PerZeroError.arctan_lower
#print axioms PerZeroError.arctan_cubic
#print axioms PerZeroError.deficit_identity
#print axioms PerZeroError.deficit_positive
#print axioms PerZeroError.deficit_bounds
#print axioms PerZeroError.deficit_cubic
#print axioms PerZeroSums.half_le_arctan
#print axioms PerZeroSums.sum_upper
#print axioms PerZeroSums.sum_lower_when_small
#print axioms PerZeroSums.total_tendsto_iff
#print axioms PerZeroSums.endpoint_sum_identity
#print axioms PerZeroSums.endpoint_ratio_sum
#print axioms PerZeroSums.deficit_sum_tendsto_iff
#print axioms PerZeroMean.indicator_nonneg
#print axioms PerZeroMean.deficit_lt_two_pi
#print axioms PerZeroMean.point_bounds
#print axioms PerZeroMean.fraction_nonneg
#print axioms PerZeroMean.mean_nonneg
#print axioms PerZeroMean.mean_bounds
#print axioms PerZeroMean.mean_tendsto_iff
#print axioms PerZeroMean.fraction_eq_count
#print axioms PerZeroMean.point_bounds_sharp
#print axioms PerZeroMean.mean_bounds_sharp
#print axioms PerZeroCounterfamily.remainder_bounds
#print axioms PerZeroCounterfamily.value_tendsto
#print axioms PerZeroCounterfamily.value_div_tendsto
#print axioms PerZeroCounterfamily.resolution_bounds
#print axioms PerZeroCounterfamily.ordinate_interior
#print axioms PerZeroCounterfamily.boundary_deficit
#print axioms PerZeroCounterfamily.midpoint_deficit
#print axioms PerZeroCounterfamily.total_eq_value
#print axioms PerZeroCounterfamily.total_tendsto
#print axioms PerZeroCounterfamily.mean_tendsto
#print axioms PerZeroCounterfamily.total_not_tendsto_zero
#print axioms PerZeroCounterfamily.configuration_mean_eq
#print axioms PerZeroCounterfamily.single_cutoff_failure
