from pathlib import Path
base=Path(__file__).absolute().parent
code=base.parents[1]/'acs-repo/code/frontier_verification'
old=(code/'dirichlet_folded_count.py').read_text()
source=old.split("if __name__=='__main__':")[0]
source=source.replace('import argparse,hashlib,json','import argparse,hashlib,json\nfrom datetime import datetime,timezone\nfrom sympy import kronecker_symbol\nimport dirichlet_strip_certificate as refinement')
source=source.replace('def count(number,top,bits):','CHARACTERS = {-3:2, 8:5, -8:3, 24:11, -24:5}\n\n\ndef count(discriminant,top,bits):')
source=source.replace('chi=dirichlet_char(5,number);conjugate=dirichlet_char(5,pow(number,-1,5))','q=abs(discriminant);number=CHARACTERS[discriminant]\n    chi=dirichlet_char(q,number);conjugate=dirichlet_char(q,pow(number,-1,q))')
source=source.replace('    logs={1:0,2:1,3:3,4:2}\n    assert all(int(chi.chi_exponent(r))==(logs[number]*logs[r])%4 for r in range(1,5))','    assert chi.is_real() and int(chi.conductor())==q and int(chi.order())==2\n    assert all(chi(r)==int(kronecker_symbol(discriminant,r)) for r in range(q))')
source=source.replace('(5/arb.pi())','(q/arb.pi())')
source += '''
def generate(bits,top):
    ctx.prec=bits;result={}
    for D,number in CHARACTERS.items():
        q=abs(D);chi=dirichlet_char(q,number)
        counted=count(D,top,bits)
        lo=F(0);slo=core.sign(core.hardy(chi,lo));assert slo
        brackets=[]
        for j in range(1,10*top+1):
            hi=F(j,10);shi=core.sign(core.hardy(chi,hi));assert shi
            if shi!=slo:brackets.append((lo,hi))
            lo,slo=hi,shi
        assert len(brackets)==counted['zero_count'],(D,len(brackets),counted['zero_count'])
        roots=[refinement.refine(chi,lo,hi) for lo,hi in brackets]
        assert all(F(a['hi'])<F(b['lo']) for a,b in zip(roots,roots[1:]))
        result[str(D)]={'discriminant':D,'modulus':q,'conrey_number':number,'parity':int(chi.parity()),
                        'character_values':[int(kronecker_symbol(D,r)) for r in range(q)],
                        'contour':counted,'root_intervals':roots}
        print(json.dumps({'event':'factor_complete','D':D,'roots':len(roots)}),flush=True)
    n=arb(top).zeta_nzeros().unique_fmpz();assert n is not None
    zr=[];allroots=list(acb.zeta_zeros(1,int(n)+1))
    for z in allroots[:-1]:
        assert z.real==arb('0.5') and 0<z.imag<top
        zr.append({'lo':str(refinement.dyadic(z.imag.lower())),'hi':str(refinement.dyadic(z.imag.upper()))})
    assert allroots[-1].imag>top
    aggregate={}
    for name,Ds in {'A':[8,-3,-24],'B':[-8,-3,24]}.items():
        roots=[{'lo':r['lo'],'hi':r['hi']} for D in Ds for r in result[str(D)]['root_intervals']]+zr
        roots.sort(key=lambda r:F(r['lo']))
        assert all(F(a['hi'])<F(b['lo']) for a,b in zip(roots,roots[1:]))
        counts=[]
        for t in range(1,top+1):
            assert all(F(r['hi'])<t or F(r['lo'])>t for r in roots)
            counts.append({'height':t,'positive_zero_count':sum(F(r['hi'])<t for r in roots)})
        aggregate[name]={'unlabelled_ordinate_intervals':roots,'integer_height_counts':counts}
    return {'status':'passed','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'dependencies_sha256':{Path(m.__file__).name:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in [core,refinement]},
            'recorded_utc':datetime.now(timezone.utc).isoformat(),'precision_bits':bits,'top':top,
            'factors':result,'zeta':{'count':int(n),'root_intervals':zr,'next_zero':allroots[-1].str(60)},
            'aggregate':aggregate,
            'scope':'Five primitive quadratic factors and Riemann zeta through the declared height. Labelled factors certify generation; inference receives only the aggregate intervals and common invariants. No global GRH assumption or claim.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--precision',type=int,choices=[160,224],required=True)
    p.add_argument('--top',type=int,default=20);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    r=generate(a.precision,a.top);a.output.write_text(json.dumps(r,indent=2)+'\\n')
    print(json.dumps({'status':r['status'],'factor_counts':{D:len(v['root_intervals']) for D,v in r['factors'].items()},
                      'aggregate_counts':{k:len(v['unlabelled_ordinate_intervals']) for k,v in r['aggregate'].items()}}))
'''
assert 'dirichlet_char(5,' not in source and '(5/arb.pi())' not in source
(code/'dedekind_biquadratic_spectrum.py').write_text(source)
