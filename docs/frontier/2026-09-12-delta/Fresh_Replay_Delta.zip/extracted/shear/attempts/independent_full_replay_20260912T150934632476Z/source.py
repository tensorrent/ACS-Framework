"""Recompute all 93 final cells from scratch; only the rational grid is input."""
import os,sys,json,time
from pathlib import Path
from fractions import Fraction as Q
root=Path(os.environ.get('ACS_SHEAR_ROOT',Path(__file__).resolve().parents[1]));sys.path.insert(0,str(root/'support'))
from frobenius_taylor_v4 import determinant_interval
from serialization import ball_string
from flint import arb
grid=json.loads((root/'support/final_frobenius_cover_grid.json').read_text());dest=Path(os.environ['ACS_ATTEMPT_DIR'])
assert Q(grid[0]['lo'])==Q(19,100) and Q(grid[-1]['hi'])==Q(49,50)
assert all(Q(a['hi'])==Q(b['lo']) for a,b in zip(grid,grid[1:]))
rows=[];start=time.monotonic()
for cell in grid:
    d,detail=determinant_interval(Q(cell['lo']),Q(cell['hi']),Q(19,100),degree=16,radius=Q(cell['radius']),bits=4096)
    assert d>0
    row={**cell,'D':ball_string(d),'D_lower':ball_string(d.lower()),'D_upper':ball_string(d.upper()),'details':detail}
    assert arb(row['D'])>0 and arb(row['D_lower'])>0
    rows.append(row);(dest/f'cell_{len(rows):04d}.json').write_text(json.dumps(row,indent=2))
out={'status':'passed_independent_full_frobenius_recomputation','cells':len(rows),'all_saved_balls_roundtrip_positive':True,'seconds':time.monotonic()-start,'accepted_cover':rows,'dependence':'Only rational grid endpoints and radii are read. No old determinant, Taylor coefficient, ODE solution, or Cauchy bound is reused.'}
(dest/'result.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='accepted_cover'},indent=2))
