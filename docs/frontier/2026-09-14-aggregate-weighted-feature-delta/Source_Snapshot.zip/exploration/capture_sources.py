from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

base=Path(__file__).absolute().parent
mathlib=base.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip()
assert revision=='be865aa50cc0364be66c3941a6dc0c845a2c2ceb'
records=[]
for relative in ['Mathlib/Analysis/Calculus/Taylor.lean','Mathlib/Data/Finset/Max.lean']:
    raw=(mathlib/relative).read_bytes()
    assert raw==subprocess.check_output(['git','show','HEAD:'+relative],cwd=mathlib)
    records.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'matches_pinned_git_object':True})
out={'status':'passed','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
     'mathlib_revision':revision,'pinned_sources':records,
     'retrieved_primary_documentation':{'url':'https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Calculus/Taylor.html',
         'retrieval':'Successfully opened with the web tool on 14 September 2026.',
         'relevant_results':['taylor_mean_remainder_lagrange_iteratedDeriv','taylor_mean_remainder_bound','taylor_integral_remainder'],
         'use':'Primary documentation for scalar Taylor expansions with bounded remainders. The current web page is not asserted to be the exact pinned runtime revision.'},
     'Arb_constructor_documentation':{'url':'https://python-flint.readthedocs.io/en/latest/arb.html','retrieval':'Successfully opened with the web tool on 14 September 2026; the page identifies python-flint 0.9.0.','verified_behavior':'The documentation says a nonzero radius can be rounded upward by the constructor. It describes a fixed 30-bit radius precision and exact dyadic tuple inputs. The observed 108 reconstruction false rejections and zero exact endpoint violations are separately recorded computational evidence.'},
     'runtime_change':'No package acquisition or version changes. The new generic Lean lemmas use already available normed-group, finite maximum and tactic modules; the Taylor and mean-value applications remain written derivations.',
     'scope':'Exact local reference sources are compared to their pinned Git objects and archived with the existing mathlib license. Current primary documentation supplements, rather than replaces, the pinned source evidence.'}
(base/'Source_Acquisition.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
