from pathlib import Path
import hashlib,json,subprocess
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';OLD=BASE.parent/'explicit-audit/primary'
OUT=BASE/'primary';OUT.mkdir(exist_ok=True)
receipts=json.loads((ROOT/'docs/frontier/2026-09-13-explicit-delta/Download_Receipts.json').read_text());sources=[]
for record,page in zip(receipts,[3,4]):
    path=OLD/record['filename'];raw=path.read_bytes();assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    stem=OUT/path.stem
    subprocess.run(['/opt/homebrew/bin/pdftoppm','-f',str(page),'-l',str(page),'-scale-to','1600','-png','-singlefile',str(path),str(stem)],check=True)
    sources.append({k:record[k] for k in ['filename','url','retrieved_utc','bytes','sha256']}|{'one_based_pdf_page':page,'rendered_page_sha256':hashlib.sha256(Path(str(stem)+'.png').read_bytes()).hexdigest()})
(BASE/'Source_Recheck.json').write_text(json.dumps({'status':'passed','sources':sources,'scope':'Previously acquired primary PDFs rehashed against the preserved download receipts and relevant pages freshly rendered. This is reuse of verified sources, not a new download.'},indent=2)+'\n')
print(json.dumps({'status':'passed','sources_rehashed':len(sources),'pages_rendered':len(sources)}))
