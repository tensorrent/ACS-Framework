from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile

BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-aggregate-adaptive-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-aggregate-moment-delta';INPUTS=ROOT/'docs/frontier/2026-09-13-aggregate-delta'
sys.path.insert(0,str(CODE))
from verify_aggregate_adaptive_delta import summarize
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def archive(name,entries):
    with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in entries:z.write(p,n)

for n in ['Adaptive_Audit.json','Audit_Closure.json','Adversary_Audit.json']:(OUT/n).write_bytes((BASE/n).read_bytes())
archive('Adaptive_Feedback.zip',[(BASE/'Adaptive_Feedback.json','Adaptive_Feedback.json')])
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))};assert len(receipts)==4 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
summary=summarize(*[read(BASE/n) for n in ['Adaptive_Feedback.json','Adaptive_Audit.json','Audit_Closure.json']])
write('Adaptive_Summary.json',{'recorded_utc':now,
    'result':'Re-optimizing measurement multipliers after validated local-domain reductions recovers all seventeen targets in both observations at radii 0, 0.005 and 0.02, and fifteen/eleven at radius 0.1 with discriminant ramification.',
    'input_contract':['degree four','signature (0,2)','discriminant 576','complete aggregate finite critical-line spectra through 20','generic coefficient boxes 0..4','prior same-radius/profile domains with recursively verified deductions'],
    'local_deduction_profiles':['degree-only local models','degree plus ramification from the supplied discriminant'],
    'not_inference_inputs':['Galois group','candidate field catalogue','defining polynomials','subfields','conductor-parity assignment','held-out arithmetic coefficients','zero-noise domains reused as noisy premises'],
    'new_roots_computed':0,'measurement_rows':17,'target_count':17,'generic_coefficients':604,'derived_results':summary,
    'stored_midpoints_checked':80976,'fresh_quadratic_interval_leaves':161952,'exact_domain_objectives':288,'independent_displaced_controls':356,
    'actual_component_mutations_rejected':10,'exact_general_domain_support_checks':604,
    'scope':'All positive-radius gains use the same fixed finite spectra and measurement family. Every changed multiplier gets a fresh uncertainty certificate. Eight repeated stronger audit findings become two actual supplemental exclusions. The final update is a sufficient deduction method, not an optimality or surviving-field certificate. Earlier exact-input full-row support results remain intact.',
    'full_proof_formalized':False,'next_gate':'Re-optimize from the audit-strengthened domains, bracket all-target recovery beyond radius 0.02, compare noisy standalone-row propagation, and test constructive or global feasibility of remaining domains.'})
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':4,'successful_commands':4,'failed_commands':0,
    'recording_scope':'Adaptive proposal/certification feedback, independent continuum/domain audit, audit-strengthened exact closure and lineage adversary. Packaging and recursive verification are separate. Earlier failures remain intact.',
    'freeze_boundary':'Each scientific source was written and frozen before its recorded run; no executed instrument was revised. Within the adaptive run, every round fixes its premise domains before proposing and certifying new vectors; all producer output was frozen before independent replay.',
    'new_derivation':'The support over an integer domain equals lower*r plus domain-width*max(r,0). This changes both the residual slack cost and the nominal multiplier objective; it remains valid for domains with holes.',
    'independence':'Real first-derivative covers versus complex quadratic covers; exact rational moment bounds; independent local catalogue; integer/Fraction replay versus Arb residual supports; 356 mpmath displaced controls. Transcendental interval calculations share FLINT.',
    'input_boundary':'The producer reads validated prior status and fingerprints, not arithmetic coefficients. Downstream audits check the held-out vectors. This is not a blinded experiment or formal noninterference proof.',
    'audit_delta':'Eight stricter findings are the same B coefficient-31 candidate 2 in four rounds under two profiles at radius 0.1. Supplemental closure removes it once per profile and makes no further local or singleton gains. No re-optimization is performed after this supplemental closure.',
    'baseline_limit':'The new exact-input target counts match the older 17/17 full-row closure; some support counts remain weaker. The positive-radius all-target recovery and radius-0.1 target gains are the new result.',
    'counterexample_scope':'A ninefold multiplier change with a stale old budget fails on explicit permitted root displacements by more than 0.383 in the finite-sum change alone. It does not assert tail saturation or an alternate field.',
    'history_policy':'Preserve all 117 branches and the 403-event byte prefix; append five events. Continue the wider ACS investigation without global completion.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Inherited Python 3.12.14 and pinned libraries. Floating sampled domain-aware LP proposals; 224-bit/48-leaf real certificates; 256-bit producer domain support; 384-bit/96-leaf complex quadratic audit; rational moment endpoints and 192-bit integer/Fraction domain deductions; 85-digit mpmath controls. No new packages or Lean modules.'
write('Runtime.json',runtime)
input_paths=[INPUTS/n for n in ['Aggregate_Inputs.zip','Measurements_Recovery.zip','Integer_Audit.json','Input_Provenance.json']]+[PRIOR/n for n in ['Local_Feedback.zip','Moment_Local_Audit.json','Moment_Audit.json']]
write('Inherited_Inputs.json',{'recorded_utc':now,'files_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in input_paths},
    'scope':'The fixed spectra, measurements and exact same-radius/profile initial domains are inherited and recursively verified. Arithmetic remains a downstream check.'})
write('Primary_Sources.json',{'recorded_utc':now,'new_downloads':0,'inherited_record':str((INPUTS/'Primary_Sources.json').relative_to(ROOT)),
    'inherited_record_sha256':sha((INPUTS/'Primary_Sources.json').read_bytes()),'sources':read(INPUTS/'Primary_Sources.json')['sources'],
    'scope':'Reuses the previously verified explicit-formula, coefficient and moment sources. The new support identity and adaptive dependency rule are derived in the instrument guide. No new download or page inspection is claimed.'})
q=read(PRIOR/'Research_Queue.json');q.update(release='Adaptive multiplier and audit-closure delta 2026-09-13',recorded_utc=now,
    parent_checkpoint=str((PRIOR/'Research_Queue.json').relative_to(ROOT)),baseline_branches=117,branches_total=117,new_branches=[],advanced_existing_branches=['R12','R13','R14','R15','K04'],
    replay_scope='Adaptive sampled multipliers with fresh continuum certificates, independent complex/rational/integer replay, audit-strengthened closure, lineage mutations and a stale-budget counterexample.',
    next_priority=['R12/R13: re-optimize from audit-strengthened domains and bracket all-target recovery beyond radius 0.02',
      'R13/R14: compare noisy standalone-row propagation and investigate constructive/global feasibility of the remaining two A and six B targets at radius 0.1',
      'R15: extend actual-field benchmarks with matched metadata, completeness and uncertainty contracts',
      'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
      'S18/S19/S21/S23 and C05/C07: coupled RG and geometric-topology gates','K02/K05: private corpus and historical-run identities'])
updates={
 'R12':('adaptive_domain_support_and_fresh_error_budgets',
   'The exact support identity min(D)*r + (max(D)-min(D))*max(r,0) adapts the multiplier LP to validated domains. Every changed vector receives a fresh shared finite/moment certificate. A ninefold-vector interval witness exceeds a stale old budget by more than 0.383 in its finite-sum change.',
   'Re-optimize from independently strengthened domains and compare sufficient noise margins without treating sampled LP scores as bounds or optima.'),
 'R13':('all_seventeen_targets_at_positive_tested_radius',
   'Both local profiles recover all seventeen targets for both aggregate spectra at radii 0, 0.005 and 0.02 using 288 adaptive vectors. At radius 0.1, degree/discriminant recovery improves from 13/10 to 15/11; degree-only recovery improves from 11/10 to 14/11. No new zeros or arithmetic seeds enter inference.',
   'Bracket all-target recovery beyond radius 0.02, compare noisy standalone-row propagation, and retain the remaining radius-0.1 target domains without asserting realizability.'),
 'R14':('adaptive_feedback_and_stronger_audit_closure',
   'Independent exact replay validates 109 adaptive dual exclusions and 87 consequent local exclusions. Eight repeated stronger audit findings become two actual coefficient-31 exclusions, one per local profile, without extra singleton gains. All 604 held-out coefficients survive every adaptive round and final closure.',
   'Study the two unresolved A and six B targets under the stronger radius-0.1 profile; re-optimize after the supplemental audit domain reduction and separate relaxation fixed points from global-field feasibility.'),
 'R15':('adaptive_lineage_and_stale_budget_boundaries_tested',
   'Ten mutations challenge radius/profile lineage, future-domain premises, budget/vector matching, signed objectives, nonnegative multipliers, continuum coverage, local enumeration and residual supports. All 604 actual support coordinates pass direct enumeration. A permitted-displacement witness proves stale budgets can fail after multiplier changes.',
   'Preserve the exact benchmark inputs and causal proof dependencies when extending fields, solver proposals, robustness margins and constructive ambiguity studies.'),
 'K04':('ongoing_delta_with_adaptive_certificates_and_audits',
   'Preserve 117 branches and 403 events; append five. Four scientific commands succeed. New independent work checks 80976 stored midpoints, 161952 quadratic leaves, 288 exact domain objectives, 356 displaced controls and all adaptive/local exclusions. Stronger older results and the broader queue remain intact.',
   'Continue evidence-backed deltas with original artifacts, failures, assumptions and exact gates; no global completion or exhaustion is asserted.')}
prefix='docs/frontier/2026-09-13-aggregate-adaptive-delta/'
for b in q['branches']:
    b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
    if b['id'] in updates:
        status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_adaptive_multiplier_and_closure_audit')
        b['new_evidence']=[prefix+n for n in ['Adaptive_Summary.json','Adaptive_Feedback.zip','Adaptive_Audit.json','Audit_Closure.json','Adversary_Audit.json']]
        b['verification_routes']+=['Domain-aware sampled proposals with fresh real continuum certificates','Independent complex quadratic and rational moment enclosures','Exact causal domain replay with independent local catalogue','Audit-strengthened exact closure and real interval support checks','Ten adaptive component mutations and a stale-budget interval witness']
        b['shared_assumptions_and_scope']='Degree four, signature (0,2), discriminant 576 and complete finite critical-line spectra through 20. Noise preserves finite population and cutoff; unknown-zero tails remain unconditional. Same-radius/profile prior domains have recursively checked proof histories. No field catalogue, Galois group or arithmetic coefficient seed is supplied. Stalled sampled updates and surviving domains do not establish optimality, global realizability or ambiguity.'
write('Research_Queue.json',q)
events=(PRIOR/'Branch_Events.jsonl').read_bytes();last=json.loads(events.splitlines()[-1])['event_sha256'];sequence=403
for bid in q['advanced_existing_branches']:
    b=next(x for x in q['branches'] if x['id']==bid);sequence+=1
    e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'adaptive_multiplier_and_closure_evidence_advanced','branch_id':bid,'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
    last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
(OUT/'README.md').write_text('''# Adaptive multiplier and audit-closure delta — 13 September 2026

Both aggregate spectra now have all seventeen target coefficients recovered at tested ordinate radii 0, 0.005 and 0.02 under either generic local profile. At radius 0.1, recovery rises from 13/10 to 15/11 targets under degree/discriminant rules, and from 11/10 to 14/11 under degree-only rules. The change re-optimizes measurement combinations after valid domain reductions and freshly certifies each changed uncertainty budget. No new zeros, measurement rows, field templates or arithmetic seeds enter inference.

The [derivation and reproduction guide](../../../code/frontier_verification/AGGREGATE_ADAPTIVE_README.md) explains the general-domain support identity, ordered premises, interval certificates and remaining limits. The earlier exact-input full-row result already recovered all seventeen targets and remains stronger on some support statistics. The new result concerns positive-radius recovery; no optimal robustness threshold or global feasibility is asserted.

- [Results and remaining target domains](Adaptive_Summary.json).
- [Adaptive feedback and all 288 continuum certificates](Adaptive_Feedback.zip), including every proposal, premise hash, local model and round.
- [Independent audit](Adaptive_Audit.json): 80,976 stored midpoint checks, 161,952 fresh complex quadratic leaves, 288 exact domain objectives, 356 mpmath displaced controls, 109 dual exclusions and 87 local exclusions. All 604 held-out coefficients survive every round.
- [Supplemental audit closure](Audit_Closure.json): two actual exclusions consume eight repeated audit findings, removing candidate 2 from B's coefficient at 31 at radius 0.1 under both profiles. No further local or singleton gain follows.
- [Ten component mutations and a stale-budget counterexample](Adversary_Audit.json). Permitted displaced roots make a ninefold measurement combination exceed its unscaled old budget by more than 0.383 in the finite-sum change alone. Unknown-tail saturation and alternate fields are not asserted.
- [Four scientific execution receipts](Execution_Receipts.json), [full outputs](Execution_Artifacts.zip), [development notes](Development_Notes.json), [runtime](Runtime.json), [inherited inputs](Inherited_Inputs.json) and [reused sources](Primary_Sources.json).
- [Source inventory](Source_Inventory.json), [snapshot](Source_Snapshot.zip), [manifest](Manifest.json) and [fresh recursive verification](Verification.json).
- [All 117 research branches](Research_Queue.json) and the [408-event ledger](Branch_Events.jsonl), preserving the prior 403 events byte for byte.

At radius 0.1 under the stronger profile, two A targets and six B targets remain unresolved. Their candidate domains are preserved, without a claim that they are globally realizable. The transcendental interval routes share FLINT; exact moment and integer calculations provide additional checks. The full analytic proof is not formalized. Earlier failures, input contracts and stronger scoped results remain intact in the [preceding checkpoint](../2026-09-13-aggregate-moment-delta/README.md) and its history.

Next, re-optimize from audit-strengthened domains, bracket all-target recovery beyond radius 0.02, compare noisy standalone-row propagation and investigate constructive or global feasibility. Additional matched-invariant fields and the wider ACS questions remain open.
''')
names=['dedekind_aggregate_adaptive.py','dedekind_aggregate_adaptive_audit.py','dedekind_aggregate_adaptive_closure.py','dedekind_aggregate_adaptive_adversary.py','verify_aggregate_adaptive_delta.py','AGGREGATE_ADAPTIVE_README.md']
deps=['dedekind_aggregate_moment_certificate.py','dedekind_aggregate_moment_audit.py','dedekind_aggregate_moment_local_audit.py','dedekind_aggregate_shared.py','dedekind_aggregate_shared_audit.py','dedekind_aggregate_noise_certificate.py','dedekind_aggregate_noise_audit.py','dedekind_aggregate_integer_audit.py','dedekind_aggregate_local_audit.py','dedekind_coefficient_recovery.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','verify_aggregate_moment_delta.py','source_requirements.txt']
inventory={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in names},'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
    'scope':'New adaptive instruments and direct dependencies; executed source versions are unchanged and preceding packages are verified recursively.'}
write('Source_Inventory.json',inventory)
archive('Source_Snapshot.zip',[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inventory[kind]]+[(BASE/n,'packaging/'+n) for n in ['run_recorded.py',Path(__file__).name]])
write('Verification.json',{'status':'verification_in_progress','scope':'Placeholder for the fresh recursive verification output; not a success claim.'})
files={}
for path in list(sorted(OUT.iterdir()))+[CODE/n for n in names]:
    if path.is_file() and path.name not in ['Manifest.json','Verification.json']:
        raw=path.read_bytes();files[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inventory['baseline_commit'],'files':files,'scope':'Manifest and Verification excluded from self-reference; preceding checkpoint verified recursively.'})
print(json.dumps({'status':'packaged','manifest_files':len(files),'receipts':len(receipts),'branches':117,'events':sequence}))
