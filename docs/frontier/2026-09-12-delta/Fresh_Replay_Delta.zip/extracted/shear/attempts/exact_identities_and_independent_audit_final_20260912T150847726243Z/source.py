"""Exact symbolic identities and independent rigorous cross-method values."""
import os,sys,json,hashlib
from pathlib import Path
root=Path(os.environ.get('ACS_SHEAR_ROOT',Path(__file__).resolve().parents[1]));sys.path.insert(0,str(root/'support'))
import sympy as S
from flint import arb,ctx
from frobenius_jost_v3 import determinant as fj
from prior_validated_jost_hardened import determinant as oj
from curvature_jost_v2 import determinant_kk
k,s,u,A,n,t=S.symbols('k s u A n t');I=S.I
W=(-2*u*(1-u*u))*k/(k*u-I*s)
assert S.simplify(S.diff(W,k)-(-I*s*(-2*u*(1-u*u))/(k*u-I*s)**2))==0
assert S.simplify(S.diff(W,k,2)/2-I*s*u*(-2*u*(1-u*u))/(k*u-I*s)**3)==0
f=S.Function('f')(t)
# t=1+tanh(y), dt/dy=t(2-t), W=-2(t-1)t(2-t)/(t-A).
dy=t*(2-t);lhs=dy*S.diff(dy*S.diff(f,t),t)+2*k*dy*S.diff(f,t)+2*(t-1)*dy/(t-A)*f
poly=t*(2-t)*(t-A)*S.diff(f,t,2)+2*(1+k-t)*(t-A)*S.diff(f,t)+2*(t-1)*f
assert S.simplify(lhs*(t-A)/dy-poly)==0
p=((A+2)*n*n+(A+2*k)*n-2)/(2*A*(n+1)*(n+1+k));q=(-n*n+n+2)/(2*A*(n+1)*(n+1+k))
lam=1/A;gap=lam-S.Rational(1,2);P=S.Matrix([[lam,S.Rational(1,2)],[1,1]])
T=S.Matrix([[p,q],[1,0]])
e1=-2/(A*(n+1+k))-k*lam/(A*(n+1)*(n+1+k)*gap)
e2=(1+k)/(2*(n+1+k))-k/(2*A*(n+1)*(n+1+k)*gap)
assert (P.inv()*T*P-S.Matrix([[lam+e1,e2],[-e1,S.Rational(1,2)-e2]])).applyfunc(S.simplify)==S.zeros(2)
for j in range(7):
    cs=S.symbols('b0:'+str(j+2));pol=sum(cs[l]*t**l for l in range(j+2));expr=S.expand(poly.subs(f,pol).doit()).coeff(t,j)
    formula=-2*A*(j+1)*(j+1+k)*cs[j+1]+((A+2)*j*j+(A+2*k)*j-2)*cs[j]+((-j*j+j+2)*cs[j-1] if j else 0)
    assert S.simplify(expr-formula)==0
ctx.prec=128;rows=[]
for ks,ss,terms in [('0.19','0.19',400),('0.4','0.1897',700),('0.445','0.1897',700),('0.445','0.18971',700),('0.5','0.19',900),('0.98','0.19',3000)]:
    kv=arb(ks);sv=arb(ss);d1,detail1=fj(kv,sv/kv,n=terms);d2,detail2=oj(kv,sv/kv,tail=18,steps=360,bits=112)
    assert d1.overlaps(d2)
    rows.append({'k':ks,'s':ss,'Frobenius_D':str(d1),'Taylor_ODE_D':str(d2),'overlap':True,'Frobenius_details':detail1,'ODE_details':detail2})
prior=json.loads((root/'support/prior_global_enclosure.json').read_text());cover=prior['accepted_cover']
from fractions import Fraction as Q
assert len(cover)==557 and Q(cover[0]['lo'])==Q(19,100) and Q(cover[-1]['hi'])==Q(49,50)
archive_positive=sum(bool(arb(r['determinant'])>0) for r in cover)
archive_inconclusive=[j for j,r in enumerate(cover) if not arb(r['determinant'])>0]
assert not any(arb(r['determinant'])<0 for r in cover)
assert all(Q(a['hi'])==Q(b['lo']) for a,b in zip(cover,cover[1:]))
out={'exact_symbolic_checks':['rescaled full-half-line ODE','three-term coefficient recurrence through degree six','diagonalized transfer matrix identity for symbolic n','first fixed-growth k derivative of potential','second normalized fixed-growth k derivative of potential'],'cross_method_interval_values':rows,'prior_archive_audit':{'accepted_cells':557,'gap_free':True,'positive_after_default_string_roundtrip':archive_positive,'inconclusive_after_default_string_roundtrip':archive_inconclusive,'archival_limitation':'Default Arb string conversion can widen a positive live ball to include zero. The old recorded text alone is insufficient to replay every sign; independent continuum recomputation is required.','source_sha256':hashlib.sha256((root/'support/prior_validated_jost.py').read_bytes()).hexdigest()},'prior_algorithm_audit':'The Volterra tail majorant and Taylor integral remainder are mathematically valid. The hardened replay explicitly takes upper endpoints before maxima of bound balls, eliminating reliance on Python ordering of overlapping balls. The original source remains unchanged.'}
(Path(os.environ['ACS_ATTEMPT_DIR'])/'result.json').write_text(json.dumps(out,indent=2));print(json.dumps({'symbolic_identities':len(out['exact_symbolic_checks']),'cross_method_values':len(rows),'prior_cover':out['prior_archive_audit']},indent=2))
