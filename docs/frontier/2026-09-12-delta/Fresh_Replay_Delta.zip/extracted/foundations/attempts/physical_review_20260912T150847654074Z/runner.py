"""Append a portable receipt for the independent physical pole recertification."""
import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
physical=ROOT.parent/'physical'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out=ROOT/'attempts'/('physical_review_'+stamp)
out.mkdir(parents=True,exist_ok=False)
script=ROOT/'checks/physical_review_certificate.py'
shutil.copyfile(script,out/'program.py');shutil.copyfile(__file__,out/'runner.py')
reviewed=[]
for rel in ['report.md','checks/isospectral_overlap.py','checks/flavor_boundaries.py','checks/outgoing_certificate.py','checks/nuclear_identifiability.py','checks/moment_capacitance.py']:
    path=physical/rel
    dest=out/'physical_source_snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,dest)
    reviewed.append({'path':'../physical/'+rel,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'snapshot':str(dest.relative_to(out))})
proc=subprocess.run([sys.executable,str(script)],cwd=ROOT,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
(out/'stdout.log').write_text(proc.stdout);(out/'stderr.log').write_text(proc.stderr)
receipt={'attempt':str(out.relative_to(ROOT)),'command':[sys.executable,str(script)],'returncode':proc.returncode,
 'program_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'reviewed_physical_sources':reviewed,
 'scope':'Recertifies only the outgoing benchmark with the hyperbolic transfer/explicit derivative/Cauchy tail. Other physical sources are pinned for the accompanying bounded human-readable review, not automatically proved by this runner.',
 'shared_trusted_component':'Arb via python-flint; distinct analytic certificate construction, not an independent interval arithmetic implementation.'}
if proc.returncode==0:(out/'result.json').write_text(json.dumps(json.loads(proc.stdout),indent=2))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2));sys.exit(proc.returncode)
