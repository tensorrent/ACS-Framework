"""Float64 planning only: no recovered coefficient or rigorous guarantee claimed."""
from pathlib import Path
import json,sys,math
import numpy as np
from sympy import primerange
sys.path.insert(0,str(Path(__file__).absolute().parents[3]/'acs-repo/code/frontier_verification'))
from dedekind_inputs import load_factors
from flint import arb,ctx
ctx.prec=160
repo=Path(__file__).absolute().parents[3]/'acs-repo'
factors,_=load_factors(repo/'docs/frontier/2026-09-13-dedekind-delta/Factor_Certificates.zip',repo/'docs/frontier/2026-09-13-lfunction-delta/Certificates.zip')
C=float(arb(3)/2+arb(125).log()/2-2*(2*arb.pi()).log()+2*arb(2).digamma())
known=sum(3/(2.25+float(r['rounded'])**2) for rows in factors.values() for r in rows)
U=C-known
powers=[]
for pp in primerange(2,4097):
 p=int(pp);n=p;k=1
 while n<=4096:
  powers.append((n,p,k));n*=p;k+=1
powers.sort();targets=[r for r in powers if r[0]<=361]
ns=np.array([r[0] for r in powers]);logs=np.log(ns);weights=4*np.log([r[1] for r in powers])/np.sqrt(ns)
denominators=[25,50,100,200,400,800,1200,1600,2000,3000,4000,6000,8000,10000,16000,24000,32000,48000,64000,96000,128000,192000,256000,384000,512000,768000,1024000]
heights=[220,400,600,800,1000,1500,2000,2500,3000]
output=[]
for n,p,k in targets:
 u=math.log(n);mask=ns!=n;scale0=math.sqrt(n)/math.log(p)
 byheight={T:[] for T in heights}
 for d in denominators:
  a=1/d;scale=2*math.sqrt(math.pi*a)*scale0
  leak=scale0*np.sum(weights[mask]*(np.exp(-(logs[mask]-u)**2/(4*a))+np.exp(-(logs[mask]+u)**2/(4*a))))
  y=math.log(4096)-u-a
  tailprime=scale*8*math.sqrt(a/math.pi)*math.exp(u/2+a/4-y*y/(4*a))*(1+(u+a)/y)
  for T in heights:
   phi=(4+T*T)*math.exp(-a*T*T) if a*(4+T*T)>=1 else math.exp(4*a-1)/a
   zero=scale*U*phi*math.exp(a/4)*math.cosh(u/2)
   byheight[T].append((2*zero+leak+tailprime,d,zero,leak+tailprime))
 best={T:min(rows) for T,rows in byheight.items()}
 output.append({'n':n,'prime':p,'power':k,'best_by_height':best})
for T in heights:
 values=[r['best_by_height'][T][0] for r in output]
 print(T,'targets',len(targets),'planned_width_below_1',sum(v<1 for v in values),'worst_width',max(values))
out=Path(__file__).absolute().parent/'Resolution_Budget_Probe.json'
out.write_text(json.dumps({'scope':'Float64 planning, not a rigorous guarantee or coefficient recovery','C':C,'known_220':known,'U':U,'targets':output},indent=2)+'\n')
