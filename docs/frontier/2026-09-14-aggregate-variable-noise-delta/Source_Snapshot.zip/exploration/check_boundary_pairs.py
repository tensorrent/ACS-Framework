"""Exploratory interval and complex checks for variable-noise boundary pairs."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
from flint import arb,arb_mat,ctx
BASE=Path(__file__).absolute().parent;ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification';sys.path.insert(0,str(CODE))
from dedekind_augmented_feature_proposal import FEATURES
from dedekind_augmented_feature_certificate_v2 import kernel
from dedekind_augmented_feature_audit import jets,modular_det
from dedekind_feature_certificate import coordinate_audit
SOURCE=ROOT/'docs/frontier/2026-09-14-aggregate-equal-population-delta'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def av(x):
 q=F(x);return arb(q.numerator)/arb(q.denominator)
def enc(x):return {'mid':list(map(int,x.mid().man_exp())),'rad':list(map(int,x.rad().man_exp()))}
def run():
 p=json.loads((BASE/'Boundary_Pair_Proposals.json').read_text());s=json.loads((SOURCE/'Equal_Population_Decoder.json').read_text());src=next(x for x in s['matching_cases'] if x['precision_bits']==224);common=list(map(F,src['common_observation']));r=F(p['root_coordinate_error_radius']);rho=F('1e-120');cases=[]
 assert r==F(src['radius_upper'])-F('1e-8')<F(src['radius_lower'])
 for case in p['cases']:
  free=case['free_A_indices'];assert free==[i for i in range(22) if i!=1] and case['numerically_converged']
  A=list(common);A[1]=F(case['fixed_A_critical_coordinate']);B=list(map(F,case['fixed_B_coordinates']));alpha=F(case['scaled_tau']);scale=F(case['tau_scale']);v=case['feature_difference_direction'];R=[list(map(F,row)) for row in case['preconditioner']]
  assert len(v)==22 and all(abs(x)==1 for x in v) and scale==F('1e-10')
  for i,x in zip(free,case['A_coordinate_corrections']):A[i]+=F(x)
  boxes=[(x-rho,x+rho) if i!=1 else (x,x) for i,x in enumerate(A)];tau_interval=(scale*(alpha-rho),scale*(alpha+rho));assert tau_interval[0]>0
  assert all(abs(x-c)<F(1,100) for box,c in zip(boxes,common) for x in box) and all(abs(x-c)<F(1,100) for x,c in zip(B,common))
  assert all(x[1]<y[0] for x,y in zip(boxes,boxes[1:])) and all(x<y for x,y in zip(B,B[1:]))
  determinant=modular_det(R);direct=[]
  for bits in [768,1024]:
   ctx.prec=bits;RR=arb_mat([[av(x) for x in row] for row in R]);X=[av(A[i])+arb(0,av(rho).upper()) for i in free]
   J=arb_mat([[kernel(spec,x,True) for x in X]+[-2*av(scale)*v[k]] for k,spec in enumerate(FEATURES)])
   E=arb_mat([[int(i==j) for j in range(22)] for i in range(22)])-RR*J
   f=arb_mat([[sum((kernel(spec,av(x)) for x in A),arb(0))-sum((kernel(spec,av(x)) for x in B),arb(0))-2*av(scale)*av(alpha)*v[k]] for k,spec in enumerate(FEATURES)]);rf=RR*f;rows=[]
   for i in range(22):
    q=sum((abs(E[i,j]) for j in range(22)),arb(0));budget=abs(rf[i,0])+av(rho)*q;assert q<1 and budget<av(rho)
    rows.append({'index':i,'derivative_defect':enc(q),'residual':enc(rf[i,0]),'self_map_bound':enc(budget)})
   direct.append({'precision_bits':bits,'rows':rows})
  ctx.prec=896;F0=[];J0=[];M=[]
  for k,spec in enumerate(FEATURES):
   F0.append(sum((jets(spec,av(x))[0] for x in A),arb(0))-sum((jets(spec,av(x))[0] for x in B),arb(0))-2*av(scale)*av(alpha)*v[k])
   J0.append([jets(spec,av(A[i]))[1] for i in free]+[-2*av(scale)*v[k]])
   M.append([abs(jets(spec,av(A[i])+arb(0,av(rho).upper()))[2]) for i in free]+[arb(0)])
  independent=[]
  for i in range(22):
   res=sum((av(R[i][k])*F0[k] for k in range(22)),arb(0));center=sum((abs(arb(int(i==j))-sum((av(R[i][k])*J0[k][j] for k in range(22)),arb(0))) for j in range(22)),arb(0));variation=av(rho)*sum((abs(av(R[i][k]))*sum(M[k],arb(0)) for k in range(22)),arb(0));q=center+variation;budget=abs(res)+av(rho)*q;assert q<1 and budget<av(rho)
   independent.append({'index':i,'complex_residual':enc(res),'center_inverse_defect':enc(center),'second_derivative_variation':enc(variation),'contraction_bound':enc(q),'self_map_bound':enc(budget)})
  records=coordinate_audit({'radius':r,'boxes_A':boxes,'boxes_B':[(x,x) for x in B]},s,SOURCE/'Equal_Population_Inputs.zip');assert all(x['within_radius'] for x in records)
  cases.append({'B_correction_scale':case['B_correction_scale'],'status':'interval_and_complex_checks_passed_pending_complete_audit','A_observation_boxes':[list(map(str,x)) for x in boxes],'fixed_B_coordinates':list(map(str,B)),
   'variable_box_radius':str(rho),'tau_interval':list(map(str,tau_interval)),'tau_upper_display':float(tau_interval[1]),'source_coordinate_checks':records,'modular_preconditioner':determinant,
   'real_interval_checks':direct,'independent_complex_precision':896,'independent_complex_checks':independent,'common_release':'The exact feature midpoint (Phi(y_A)+Phi(y_B))/2, with component errors bounded by the certified positive tau upper endpoint.'})
 return {'status':'exploratory_checks_passed_not_published','source_sha256':sha(Path(__file__)),'inputs_sha256':{x.name:sha(x) for x in [BASE/'Boundary_Pair_Proposals.json',SOURCE/'Equal_Population_Decoder.json',SOURCE/'Equal_Population_Inputs.zip',CODE/'dedekind_augmented_feature_certificate_v2.py',CODE/'dedekind_augmented_feature_audit.py',CODE/'dedekind_feature_certificate.py']},'cases':cases,
  'scope':'Actual small self-mapping contractions and source-box checks support the three candidate pairs. Both analytic routes share FLINT and inherited source premises. A canonical independent audit, adversaries, explicit variable-tau/midpoint proof, complete provenance and recursive verification are required for the next published checkpoint. No optimality or new published threshold claim.'}
r=run();(BASE/'Boundary_Pair_Checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'cases':[{'B_scale':x['B_correction_scale'],'tau_upper_display':x['tau_upper_display']} for x in r['cases']]},indent=2))
