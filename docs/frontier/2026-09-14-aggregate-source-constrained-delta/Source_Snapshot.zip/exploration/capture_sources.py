from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
base=Path(__file__).absolute().parent;mathlib=base.parent/'lean-audit/withMathlib/.lake/packages/mathlib'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip();assert revision=='be865aa50cc0364be66c3941a6dc0c845a2c2ceb'
records=[]
for path in ['Mathlib/Analysis/Calculus/Deriv/Add.lean','Mathlib/Analysis/Calculus/FDeriv/Add.lean','Mathlib/Order/Interval/Set/Basic.lean']:
    raw=(mathlib/path).read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+path],cwd=mathlib)
    records.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'matches_pinned_git_object':True})
result={'status':'passed','recorded_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mathlib_revision':revision,'pinned_sources':records,
    'retrieved_primary_documentation':{'url':'https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Calculus/Deriv/Add.html','retrieval':'Successfully opened with the web tool on14September2026.','relevant_results':['HasDerivAt.sub_const','HasDerivAt.const_sub'],'scope':'Current primary documentation is distinct from the pinned runtime sources.'},
    'runtime_change':'No package acquisition, version change or new source roots. Existing pinned numerical and Lean/mathlib runtimes are reused.',
    'scope':'Three pinned derivative/interval source files match local Git objects and are archived with the mathlib license. New scalar source and conditional-budget implications are explicitly derived and generic forms are compiled in Lean. The complete concrete analytic assembly remains partly written or computational.'}
(base/'Source_Acquisition.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
