"""Exact block decomposition, discrepancy bounds, balanced sharp-rate families."""
import json, math
from collections import Counter
import numpy as np
import sympy as sp
from scipy.linalg import hadamard

def from_epsilon(e):
    k=e.shape[0]
    p=np.zeros((k*k,k*k)); blocks=[]
    for b in range(k):
        block=np.empty((k,k))
        for a in range(k):
            values=1+e[a,b,:]
            block[:,a]=values/values.sum()-1/k
            p[b*k:(b+1)*k,a*k+b]=block[:,a]
        blocks.append(block)
    return p,blocks

rng=np.random.default_rng(20260911)
random_checks=[]
renormalized_checks=[]
for k in [2,3,4,6,8]:
    for delta in [.01,.2,.7]:
        e=rng.uniform(-delta,delta,(k,k,k))
        p,blocks=from_epsilon(e)
        ss=np.linalg.svd(p,compute_uv=False)
        bs=np.sort(np.concatenate([np.linalg.svd(b,compute_uv=False) for b in blocks]))[::-1]
        assert np.max(abs(ss-bs))<1e-13
        coefficient=delta/math.sqrt(1-delta**2)
        assert ss[0]<=coefficient+1e-13
        assert np.linalg.norm(p,'fro')<=math.sqrt(k)*coefficient+1e-13
        assert ss.sum()<=k*math.sqrt(k-1)*coefficient+1e-13
        row_indices=np.arange(k*k)
        column_indices=np.array([a*k+b for b in range(k) for a in range(k)])
        independently_permuted=p[np.ix_(row_indices,column_indices)]
        expected=np.zeros_like(p)
        for b in range(k):expected[b*k:(b+1)*k,b*k:(b+1)*k]=blocks[b]
        assert np.array_equal(independently_permuted,expected)
        random_checks.append({'k':k,'delta':delta,'operator_norm':float(ss[0]),'HS_norm':float(np.linalg.norm(p,'fro')),'trace_norm':float(ss.sum()),'block_singular_error':float(np.max(abs(ss-bs)))})
    h=.03;eta=.005;M=1.
    C=rng.uniform(-M,M,(k,k,k));r=rng.uniform(-eta,eta,(k,k,k))
    e=h*C+r;P,_=from_epsilon(e)
    L=np.zeros_like(P)
    for a in range(k):
        for b in range(k):L[b*k:(b+1)*k,a*k+b]=(C[a,b,:]-C[a,b,:].mean())/k
    delta=h*M+eta;E=(eta/h+M*delta)/(1-delta)
    error=P/h-L;ss=np.linalg.svd(error,compute_uv=False)
    assert ss[0]<=E and np.linalg.norm(error,'fro')<=math.sqrt(k)*E
    assert ss.sum()<=k*math.sqrt(k-1)*E
    renormalized_checks.append({'k':k,'h':h,'eta':eta,'operator_error':float(ss[0]),'operator_error_bound':E})

# Pointwise proof of the sharpened scalar variance inequality:
# (delta^2-mu^2)/(1+mu)^2 <= delta^2/(1-delta^2).
d,mu=sp.symbols('d mu',real=True)
identity=sp.factor(d*d*(1+mu)**2-(d*d-mu*mu)*(1-d*d))
assert identity==(d*d+mu)**2

# Double-centered symmetric Sylvester Hadamard matrices. All entries rational,
# both marginals exactly zero. Their singular spectrum has an exact proof.
families=[]
for k in [4,8,16,32]:
    H=hadamard(k).astype(float)
    Q=np.eye(k)-np.ones((k,k))/k
    D=k/(k+1)*(Q@H@Q)
    assert np.max(abs(D.sum(axis=0)))<1e-12
    assert np.max(abs(D.sum(axis=1)))<1e-12
    assert np.max(abs(D))<=1+1e-13
    sigma=np.linalg.svd(D,compute_uv=False)
    expected=np.array([k*math.sqrt(k)/(k+1)]*(k-2)+[k/(k+1),0])
    assert np.max(abs(sigma-expected))<1e-12
    # delta=k^-3/2 exhibits trace norm -> 1 while op and HS -> 0.
    delta=k**-1.5
    B=delta/k*D
    eig=np.linalg.eigvalsh(B)
    nonzero=abs(eig[abs(eig)>1e-13])
    exact_eff=((k-2)*k**.25+1)**4/((k-2)*math.sqrt(k)+1)**2
    measured_eff=np.sum(np.sqrt(nonzero))**4/np.sum(nonzero)**2
    assert abs(exact_eff-measured_eff)<1e-8
    report={'k':k,'delta':delta,'operator_norm':delta*math.sqrt(k)/(k+1),'HS_norm':delta*math.sqrt(k)*(k-1)/(k+1),'trace_norm':delta*k*((k-2)*math.sqrt(k)+1)/(k+1),'effective_eigenvalue_rank':exact_eff,'algebraic_rank':k*(k-1),'nonzero_eigenvalue_count':(k-1)**2}
    if k<=8:
        e=np.empty((k,k,k))
        for a in range(k):
            for b in range(k):e[a,b,:]=delta*D[:,a]
        p,blocks=from_epsilon(e)
        actual=np.linalg.svd(p,compute_uv=False)
        assert abs(actual[0]-report['operator_norm'])<1e-12
        assert abs(actual.sum()-report['trace_norm'])<1e-12
        # Matrix square is B tensor B, checked independently by direct assembly.
        assert np.max(abs(p@p-np.kron(B,B)))<1e-14
    families.append(report)

# Exact rational construction and Euler circuit: k=4, delta=1/3.
k=4; H=sp.Matrix(hadamard(k)); Q=sp.eye(k)-sp.ones(k)/k
D=sp.Rational(k,k+1)*Q*H*Q
assert D*sp.ones(k,1)==sp.zeros(k,1)
assert sp.ones(1,k)*D==sp.zeros(1,k)
C={}
for a in range(k):
    for b in range(k):
        for c in range(k):C[a,b,c]=45*(1+D[c,a]/3)
assert all(v.is_Integer and v>0 for v in C.values())
adj={a*k+b:[] for a in range(k) for b in range(k)}
for (a,b,c),count in C.items():adj[a*k+b].extend([b*k+c]*int(count))
stack=[0];walk=[]
while stack:
    v=stack[-1]
    if adj[v]:stack.append(adj[v].pop())
    else:walk.append(stack.pop())
walk=walk[::-1]
assert walk[0]==walk[-1] and len(walk)==sum(C.values())+1
observed=Counter()
for x,y in zip(walk,walk[1:]):
    a,b=divmod(x,k);bb,c=divmod(y,k)
    assert b==bb
    observed[a,b,c]+=1
assert all(observed[t]==v for t,v in C.items())

print(json.dumps({'status':'passed','universal_bound':'||P||op <= delta/sqrt(1-delta^2), ||P||HS <= sqrt(k)*delta/sqrt(1-delta^2), ||P||S1 <= k*sqrt(k-1)*delta/sqrt(1-delta^2)','random_block_checks':random_checks,'renormalized_checks':renormalized_checks,'balanced_hadamard_families':families,'exact_sequence_realization':{'k':k,'edge_count':int(sum(C.values())),'exact_triple_count_reconstruction':True},'scope':'The balanced families are exact surrogate residue sequences, not sequences of actual primes. Full-matrix floating-point checks confirm formulas; symbolic identities and the written universal proof do the mathematical work.'},indent=2))
