from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile
BASE=Path(__file__).absolute().parent
ROOT=BASE.parents[1]/'acs-repo';CODE=ROOT/'code/frontier_verification'
OUT=ROOT/'docs/frontier/2026-09-13-coupled-delta';PRIOR=ROOT/'docs/frontier/2026-09-13-recovery-delta'
OUT.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def archive(name,entries):
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p,n in entries:z.write(p,n)
archive('Measurements.zip',[(BASE/'Measurements.json','Measurements.json')])
archive('Coupled_Audits.zip',[(BASE/n,n) for n in ['Coupled_160.json','Coupled_224.json','Uncertainty_Grid.json']])
archive('Dual_Audits.zip',[(BASE/n,n) for n in ['Dual_224.json','Dual_Refined.json']])
for n in ['Exact_Audit.json','Target_Branches.json','Integer_Witnesses.json','Branch_Audit.json','Local_Bridge.json']:(OUT/n).write_bytes((BASE/n).read_bytes())
receipts={p.parent.name:read(p) for p in sorted(BASE.glob('*/receipt.json'))}
assert len(receipts)==11 and all(r['returncode']==0 for r in receipts.values())
write('Execution_Receipts.json',receipts)
archive('Execution_Artifacts.zip',[(BASE/name/f,name+'/'+f) for name in receipts for f in ['receipt.json','stdout.txt','stderr.txt']])
coupled=read(BASE/'Coupled_224.json');dual=read(BASE/'Dual_224.json');refined=read(BASE/'Dual_Refined.json');noise=read(BASE/'Uncertainty_Grid.json')
summary={'recorded_utc':now,'target_prime_power_limit':361,'target_count':91,'generic_coefficient_support':604,'prime_cutoff':4096,
 'height_comparisons':[{'height':c['settings']['top'],'certified_positive_roots_used':c['settings']['count'],
  'coupled_integer_exclusion_unique':c['unique_target_coefficients'],'initial_dual_unique':d['unique_targets'],
  'integer_refined_dual_unique':r['unique_targets'],'coupled_rounds':len(c['rounds']),
  'incidental_unique_coefficients':[v for v in c['domains'] if v['n']>361 and len(v['candidates'])==1]} for c,d,r in zip(coupled['cases'],dual['cases'],refined['cases'])],
 'uncertainty_cases':[{'height':c['settings']['top'],'additional_radius':c['additional_radius'],'unique_targets':c['unique_target_coefficients'],
  'unresolved_targets':[r for r in c['domains'] if r['n']<=361 and len(r['candidates'])>1]} for c in noise['cases']],
 'at_220_without_local_relations':{'unique_targets_before_branching':89,'candidate_pairs':8,'excluded_pairs':6,'feasible_pairs':[{'359':0,'361':4},{'359':1,'361':1}]},
 'optional_local_bridge_at_220':{'prime':19,'square':361,'retained_residue_degrees':[2,2],'unique_targets':91},
 'original_local_factor_cohort':{'rational_primes':72,'unresolved_local_factors':48},
 'incidental_367_scope':'The coefficient at 367 is recovered as zero at height 600; adding this prime to the local-factor cohort adds the unresolved square 134689.',
 'scope':'Finite inequalities with explicit inference tiers, not an unknown-field or operator identification. Height-dependent width choices and the coarse uncertainty bound prevent interpreting the noise counts as optimal thresholds.'}
write('Coupled_Summary.json',summary)
write('Development_Notes.json',{'recorded_utc':now,'recorded_commands':11,'unsuccessful_recorded_commands':0,
 'retained_noncertified_trials':'Exact_Audit.json retains seven attempted target pairs whose nuisance coordinates were held at independent arithmetic values. Only the correct target pair passed this restricted construction; this did not establish infeasibility. The later MILP search found two strict feasible models after nuisance coordinates were allowed to vary.',
 'precision_method':'Exact dyadic midpoint/radius serialization is used for critical intervals. Independent replay rounds outward to 2^-192 and uses integer arithmetic.',
 'solver_scope':'HiGHS results propose rational multipliers or integer vectors. Strict interval or integer checks decide every published bound, exclusion and feasible witness.',
 'noise_scope':'The added-radius test widens already certified root enclosures, preserving cutoff membership. It uses a conservative global derivative bound and recomputes the zero moment with enlarged intervals; it does not model zeros of a perturbed field.'})
runtime=read(PRIOR/'Runtime.json');runtime['recorded_utc']=now;runtime['scope']='Same pinned runtime as the preceding checkpoint; SciPy HiGHS proposes solutions and all claimed certificates receive interval/integer validation.';write('Runtime.json',runtime)
write('Primary_Sources.json',{'recorded_utc':now,'sources':[
 {'url':'https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html','use':'HiGHS interface, inequality marginals, integrality option and solver status. The installed runtime version is recorded separately; the certification argument does not trust float solver output.'},
 {'url':'https://www.jmilne.org/math/CourseNotes/ANT.pdf','locator':'Theorems 3.34-3.35','use':'Previously sourced degree sum and discriminant criterion, used only in the explicitly separate local bridge.'},
 {'url':'https://arxiv.org/pdf/1305.0035','locator':'Section 2, equations (1)-(2)','use':'Inherited Gaussian Weil-Poitou identity, with conventions and admissibility already derived in the explicit-formula checkpoint.'},
 {'url':'https://arxiv.org/pdf/1407.1375','locator':'Section 2, equations (2.1)-(2.7)','use':'Inherited unconditional Euler/Hadamard moment argument at s=2; later GRH-dependent bounds are not used.'}],
 'scope':'New exclusion, dual, separation and derivative arguments are derived directly in COUPLED_README.md. Source documents remain linked rather than redistributed.'})
q=read(PRIOR/'Research_Queue.json');q.update({'release':'Coupled spectral-recovery delta 2026-09-13','recorded_utc':now,'baseline_branches':116,'branches_total':116,'new_branches':[],
 'advanced_existing_branches':['P05','R12','R13','R14','K04'],
 'replay_scope':'Measurement extraction from immutable prior data; two interval precisions, five cutoffs, fourteen uncertainty cases, validated continuous dual/integer refinement, exact integer replay, target-pair separation and feasible witnesses, optional local bridge.',
 'next_priority':['R12/R13: sharpen the global ordinate-error bound with per-root derivatives, noise-aware widths and retained lower-cutoff measurements',
 'R13/R14: add or optimize measurements and linked-tail constraints; quantify when the height-220 relaxed ambiguity disappears without local relations',
 'R14/P05: acquire or infer the 48 unresolved square coefficients for the original cohort, and distinguish residue degrees from ramification information',
 'R13/R07: specify statistical calibration independently of deterministic coefficient recovery',
 'R04/R05/R06/R08/R10: natural operators and independent real-part/infinite arithmetic bridges',
 'S18/S19/S21/S23 and C05/C07: retain coupled RG and geometric-topology gates',
 'K02/K05: private corpus and historical-run identities']})
updates={
 'P05':('coupled_finite_coefficients_recovered_with_explicit_inference_tiers','Coupled Gaussian inequalities identify all 91 coefficients through 361 at height 600 using only integer 0..4 coefficient bounds. Independent rational dual certificates and integer box refinement agree. The optional general prime/square relation at 19 gives all 91 at height 220.','Extend target bands or field models with declared invariants. Keep spectral coefficient boxes, optional local relations and field/operator interpretation distinct.'),
 'R12':('finite_resolution_and_added_ordinate_uncertainty_certified','Reusing existing root certificates, the coupled calculation needs only 1822 positive roots through height 600 for all targets. At heights 1000 and 2000 all 91 survive added ordinate radii through 5e-6 on the tested grid; at 5e-4 the conservative counts are 67 and 55. Moments are recomputed on enlarged intervals.','Replace the global N-times-derivative estimate with justified per-root bounds and noise-aware measurement selection. Preserve cutoff membership and distinguish sufficient bounds from optimal noise thresholds.'),
 'R13':('coupled_spectral_recovery_validated_by_integer_and_dual_certificates','Positive interval exclusion and iterated continuous dual bounds identify all 91 targets at height 600 without local power relations. Exact fixed-grid integer replay verifies 8601 exclusions and 970 dual certificates. At height 220, six target pairs are excluded and two integer models satisfy all retained inequalities.','Add measurement or tail-correlation information to shrink the relaxed ambiguity without arithmetic seeds; extend the target/frequency band and keep statistical and natural-operator claims separate.'),
 'R14':('relaxed_measurement_nonidentifiability_and_local_bridge_certified','The height-220 coefficient-box relaxation admits both (c359,c361)=(0,4) and (1,1), with full integer witnesses and six separating certificates for the other pairs. The optional unramified prime/square relation at 19 selects (0,4). The original 48 local-factor ambiguities and generic ramification obstruction remain.','Distinguish ambiguity of a chosen finite inequality relaxation from actual-field nonidentifiability. Test additional measurements and local information explicitly; pursue the original square-power gates and the incidental 367 square 134689 if its cohort is expanded.'),
 'K04':('ongoing_delta_with_coupled_recovery_and_verified_ambiguity','Preserve all 116 branches and the unchanged 355-event prefix, adding five scoped events to reach 360. Eleven successful commands, exact certificate replays, seven noncertified restricted trials, two feasible relaxed models and uncertainty limits remain linked.','Continue append-only evidence-backed deltas and independent challenges across the full research queue, without a global completion or exhaustion claim.')}
evidence={
 'P05':['Coupled_Audits.zip','Dual_Audits.zip','Local_Bridge.json'],
 'R12':['Coupled_Audits.zip','Measurements.zip','Coupled_Summary.json'],
 'R13':['Coupled_Audits.zip','Dual_Audits.zip','Exact_Audit.json','Branch_Audit.json'],
 'R14':['Target_Branches.json','Integer_Witnesses.json','Branch_Audit.json','Local_Bridge.json'],
 'K04':['Research_Queue.json','Branch_Events.jsonl','Execution_Artifacts.zip','Source_Snapshot.zip']}
prefix='docs/frontier/2026-09-13-coupled-delta/'
for b in q['branches']:
 b['prior_delta_evidence']=b.get('prior_delta_evidence',[])+b['new_evidence'];b['new_evidence']=[];b['assessment_this_pass']='carried_forward_not_newly_audited'
 if b['id'] in updates:
  status,result,gate=updates[b['id']];b.update(current_status=status,latest_scoped_result=result,continuation_condition=gate,assessment_this_pass='fresh_coupled_recovery_and_information_boundary_audit')
  b['new_evidence']=[prefix+n for n in evidence[b['id']]]
  b['verification_routes']+=['Synchronous positive interval-domain exclusions with prerequisite hashes','Rational dual multipliers and integer box tightening','Independent outward fixed-grid integer replay','Exact target-pair separators and strict feasible integer models','Separate general local prime/square relation']
  if b['id'] in ['R12','R13','R14']:b['shared_assumptions_and_scope']='Given quartic field invariants, inherited finite certificates and explicit formula with unconditional omitted-zero bounds. Main coefficient-box algorithms omit local power relations; the local bridge is separate. Feasible alternate vectors belong to the relaxed inequalities and are not alternate number fields. Added-radius results are sufficient conservative bounds.'
write('Research_Queue.json',q)
old=(PRIOR/'Branch_Events.jsonl').read_bytes();events=old;last=json.loads(old.splitlines()[-1])['event_sha256'];sequence=355
for bid in ['P05','R12','R13','R14','K04']:
 b=next(b for b in q['branches'] if b['id']==bid);sequence+=1
 e={'sequence':sequence,'utc':now,'release':q['release'],'kind':'coupled_recovery_evidence_advanced','branch_id':bid,
    'result':b['latest_scoped_result'],'evidence':b['new_evidence'],'previous_event_sha256':last}
 last=sha(json.dumps(e,sort_keys=True,separators=(',',':')).encode());e['event_sha256']=last;events+=(json.dumps(e,sort_keys=True)+'\n').encode()
(OUT/'Branch_Events.jsonl').write_bytes(events)
new_names=['dedekind_coupled_inputs.py','dedekind_coupled_recovery.py','dedekind_coupled_dual.py','dedekind_coupled_dual_refine.py',
 'dedekind_coupled_audit.py','dedekind_coupled_branch_certificate.py','dedekind_coupled_branch_witness.py','dedekind_coupled_branch_audit.py',
 'dedekind_coupled_local_bridge.py','verify_coupled_delta.py','COUPLED_README.md']
deps=['verify_recovery_delta.py','source_requirements.txt','RECOVERY_README.md']
inv={'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'instruments':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in new_names},
 'dependencies':{str((CODE/n).relative_to(ROOT)):sha((CODE/n).read_bytes()) for n in deps},
 'scope':'New coupled-recovery instruments; earlier source and dated evidence bytes preserved.'}
write('Source_Inventory.json',inv)
entries=[(ROOT/p,kind+'/'+p) for kind in ['instruments','dependencies'] for p in inv[kind]]
entries.extend((p,'packaging/'+p.name) for p in [BASE/'run_recorded.py',Path(__file__).absolute()])
archive('Source_Snapshot.zip',entries)
files={}
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name not in ['Manifest.json','Verification.json']:
  raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
for n in new_names:
 p=CODE/n;raw=p.read_bytes();files[str(p.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}
write('Manifest.json',{'recorded_utc':now,'baseline_commit':inv['baseline_commit'],'files':files,
 'scope':'Verification result and manifest excluded to avoid self-reference; preceding checkpoint verified recursively.'})
print(json.dumps({'status':'packaged','files':len(files),'receipts':len(receipts),'branches':len(q['branches']),'events':sequence,
 'bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())},indent=2))
