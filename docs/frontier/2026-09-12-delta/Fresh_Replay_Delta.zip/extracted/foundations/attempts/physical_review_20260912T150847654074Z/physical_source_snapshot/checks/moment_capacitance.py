"""Framed-curve magnetic moments and electrostatic variational obstruction."""
import json,math
import numpy as np
import sympy as s
from scipy.integrate import quad

# Same (2,1) centerline and framing; only normalized mass/charge weights vary.
t,R,a,c,d=s.symbols('t R a c d',real=True)
moment=s.integrate((R+a*s.cos(t))**2*(1+c*s.cos(t)),(t,0,2*s.pi))/(2*s.pi)
assert s.simplify(moment-(R*R+a*a/2+R*a*c))==0
threshold=s.simplify((s.sqrt(2)-1)/(s.sqrt(2)+1))
assert s.simplify(threshold-(3-2*s.sqrt(2)))==0
rows=[]
for eta in [.05,.2,.5]:
    for charge,mass in [(-.9,.9),(0.,0.),(.9,-.9),(.2,.2)]:
        Rc=1.;aa=eta;omega=.7;Q=2.;M=3.
        base=1+eta*eta/2
        exact=(base+eta*charge)/(base+eta*mass)
        def curve(tt):return np.array([(1+aa*math.cos(tt))*math.cos(2*tt),(1+aa*math.cos(tt))*math.sin(2*tt),aa*math.sin(tt)])
        def cross_z(tt):
            r=curve(tt);v=omega*np.cross([0,0,1],r)
            return np.cross(r,v)[2]
        mu=quad(lambda tt:Q*(1+charge*math.cos(tt))/(2*math.pi)*cross_z(tt)/2,0,2*math.pi,epsabs=1e-12)[0]
        L=quad(lambda tt:M*(1+mass*math.cos(tt))/(2*math.pi)*cross_z(tt),0,2*math.pi,epsabs=1e-12)[0]
        numerical=2*M*mu/(Q*L)
        lower=((1-eta)/(1+eta))**2;upper=1/lower
        assert abs(exact-numerical)<1e-13
        assert lower<=exact<=upper
        if charge==mass:assert abs(exact-1)<1e-14
        rows.append({'a_over_R':eta,'charge_density_cosine':charge,'mass_density_cosine':mass,
                     'g_exact':exact,'g_direct_vector_integral':numerical,'support_bound':[lower,upper]})

# Sharp support bounds are approached by positive normalized densities
# exp(k cos t) and exp(-k cos t), still on precisely the same framed curve.
sharp=[];eta=.2
for k in [1.,4.,16.,64.]:
    def weighted(sign):
        # Remove e^k from numerator and denominator for numerical stability.
        den=quad(lambda tt:math.exp(sign*k*math.cos(tt)-k),0,2*math.pi,epsabs=1e-12)[0]
        return quad(lambda tt:(1+eta*math.cos(tt))**2*math.exp(sign*k*math.cos(tt)-k),0,2*math.pi,epsabs=1e-12)[0]/den
    g=weighted(1)/weighted(-1)
    assert g<((1+eta)/(1-eta))**2
    sharp.append({'concentration':k,'g':g,'limiting_upper':((1+eta)/(1-eta))**2})
assert sharp[-1]['g']>sharp[0]['g']

# Electrostatic sphere: independent field-energy and surface-charge derivations
# verify constants in C = 4*pi*eps*r; no torus/sphere topology identification.
capacities=[]
for eps,rad,Q in [(1.,1.,1.),(.7,2.,3.),(2.,.3,.2)]:
    C=4*math.pi*eps*rad
    V=Q/(4*math.pi*eps*rad)
    field_energy=quad(lambda rr:eps/2*(Q/(4*math.pi*eps*rr*rr))**2*4*math.pi*rr*rr,rad,np.inf,epsabs=1e-12)[0]
    assert abs(Q/V-C)<1e-12
    assert abs(field_energy-Q*Q/(2*C))<1e-12
    capacities.append({'eps':eps,'radius':rad,'C':C,'energy_integral':field_energy,'charge_energy':Q*Q/(2*C)})

# Annulus scheme is exactly invertible in an arbitrary target, hence a fit
# absent a separate aspect-ratio/charge-fraction selection.
annulus=[]
for frac,target in [(.5,3.),(.5,10.),(.5,137.036),(.7,10.)]:
    log_eta=math.log(8)+1-target/(2*frac*frac)
    reconstructed=2*frac*frac*(math.log(8)-log_eta+1)
    assert abs(reconstructed-target)<2e-13
    annulus.append({'charge_fraction_f':frac,'selected_target':target,'implied_log_a_over_R':log_eta,
                     'implied_a_over_R':math.exp(log_eta),'reconstructed_target':reconstructed})
print(json.dumps({'branches':['M02'],
 'magnetic_moment':{'assumptions':'Localized classical rigid rotation about z with one angular velocity, positive normalized charge distribution of one sign and positive mass distribution. This is a kinematic calculation, not a QED or stable electron model.',
  'formula':'g=2M mu_z/(Q L_z)=<s^2>charge/<s^2>mass, with cylindrical radius s. Equal normalized charge and mass distributions imply g=1 for every geometry.',
  'same_framing_family':'r(t)=((R+a cos t)cos(2t),(R+a cos t)sin(2t),a sin t); probability densities (1+c cos t)/(2pi) and (1+d cos t)/(2pi), |c|,|d|<1. Geometry and chosen framing are unchanged.',
  'exact_family':'g=(R^2+a^2/2+Ra*c)/(R^2+a^2/2+Ra*d)',
  'sharp_support_bounds':'((R-a)/(R+a))^2 <= g <= ((R+a)/(R-a))^2; extrema are limiting for concentrated positive densities.',
  'g2_necessary_aspect':'a/R >= 3-2 sqrt(2)', 'g2_necessary_aspect_numeric':float(threshold),
  'independent_vector_integrals':rows,'sharpness_sequence':sharp,
  'boundary':'Different rotation laws, signed charge distributions, spin fields or stresses can evade these hypotheses; framing alone supplies none of them.'},
 'capacitance':{'variational_theorem':'For compact conductors K1 subset K2 in R^3, electrostatic capacity C(K1)<=C(K2). Strict for nested smooth conductors with positive separation and positive capacity. Uniform scaling gives C(sK)=s C(K).',
 'proof_1':'Dirichlet principle C/eps=inf integral |grad u|^2 over u>=1 on K, u tending to zero at infinity. Enlarging K restricts admissible u; strictness follows uniqueness and the maximum principle.',
 'proof_2':'Thomson principle 1/C=min over unit-charge measures supported on K of Coulomb energy integral; enlarging K enlarges this admissible class. Sphere charge/field-energy calculations independently fix normalization.',
 'fixed_topology_counterfamily':'Solid circular tubes K_a={distance(x,circle_R)<=a}, 0<a<R, have the same torus topology and may retain one chosen centerline framing, yet their capacities increase strictly with a. These are counterexamples to capacity being selected by topology; they are not asserted to be the manuscript zero-thickness ribbon conductor.',
 'radius_bounds':'A tube K_a contains a ball of radius a and lies within a ball of radius R+a. Therefore 4pi eps a <= C(K_a) <= 4pi eps (R+a).',
 'self_stress_relation':'With charge f e, R=hbar/(2mc), C=eps R*c(shape), alpha_inverse=4pi f^2/c(shape). Uniform scale cancels after the Compton-radius input, but aspect ratio and charge fraction remain.',
 'annulus_scheme':'alpha_inverse=2 f^2*(log(8R/a)+1); log(a/R)=log 8+1-alpha_inverse/(2 f^2). Derivative with respect to log(a/R) is -2f^2; logarithmic charge-fraction sensitivity is 2.',
 'independent_sphere_normalization':capacities,'arbitrary_annulus_target_reconstructions':annulus,
 'boundary':'137.036 is used only as the manuscript target, not as a newly retrieved physical constant. No unresolved thin-ribbon BIE is extrapolated to an extremely small cutoff, and neither geometry nor electrostatics establishes a quantum spectrum.'}},indent=2))
