"""Normalize detailed endpoint evidence into roundtrip-verifiable Arb balls."""
import os,sys,json
from pathlib import Path
root=Path(os.environ.get('ACS_SHEAR_ROOT',Path(__file__).resolve().parents[1]));sys.path.insert(0,str(root/'support'))
from serialization import ball_string
from flint import arb,ctx
ctx.prec=192
stage=sorted((root/'attempts').glob('uniqueness_certificate_final_*'))[-1]
outer=json.loads((stage/'outer_exclusion.json').read_text())['accepted'];curve=json.loads((stage/'curvature_cover.json').read_text())
records=[]
for kind,rows,key in [('outer',outer,'D'),('curvature',curve,'D_kk')]:
    for row in rows:
        lo=arb(row[key+'_lower']);hi=arb(row[key+'_upper']);assert lo>0
        x=arb((lo+hi)/2,(hi-lo)/2);s=ball_string(x)
        assert arb(s)>0
        records.append({'kind':kind,'lo':row['lo'],'hi':row['hi'],'bound':s,'lower':ball_string(lo.lower()),'upper':ball_string(hi.upper())})
# Every Frobenius point used in uniqueness/refinement has 0<eta<=1, where
# the earlier restricted rho formula agrees with max(|lambda|,1/2)+epsilon.
assert arb(1)/arb(2).sqrt()>arb('0.5')
# Full complex-disk family: this exact polynomial inequality proves the
# same premise independently, although the final API now uses max anyway.
from fractions import Fraction as Q
c=Q(19,100);R=Q(1,50);s=Q(19,100)
assert 4*(c-R)**2>(c+R)**2+(s+R)**2
out={'status':'passed','outer_cells':len(outer),'curvature_cells':len(curve),'all_normalized_balls_roundtrip_strictly_positive':True,'records':records,'tail_domain_gate':'All accepted real points have eta<=1. For the entire complex-disk family, |lambda| >= (c-r)/sqrt((c+r)^2+(s+r)^2)>1/2 at c>=.19,r<=.02,s=.19. Final generalized API uses max(|lambda|,1/2) regardless.'}
(Path(os.environ['ACS_ATTEMPT_DIR'])/'result.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
